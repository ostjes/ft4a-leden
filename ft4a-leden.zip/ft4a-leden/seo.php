<?php
/* FT4A: zoekmachine-optimalisatie (titels, meta, Open Graph, structured data, sitemap, robots). */
if (!defined('ABSPATH')) exit;

const FT4A_PUBLIC_KEYS = ['home','oefeningen','software','prijzen','vragen','handleiding','reviews','contact','ledenoefeningen'];
const FT4A_NOINDEX_KEYS = ['account','inloggen','oefening-toevoegen','404'];
const FT4A_OG_LOCALE = ['nl'=>'nl_NL','en'=>'en_GB','en-us'=>'en_US','fr'=>'fr_FR','de'=>'de_DE','es'=>'es_ES','it'=>'it_IT','pt'=>'pt_PT','pt-br'=>'pt_BR','da'=>'da_DK','sv'=>'sv_SE','fi'=>'fi_FI','no'=>'nb_NO','pl'=>'pl_PL','tr'=>'tr_TR','ru'=>'ru_RU','ro'=>'ro_RO','ar'=>'ar_AR'];
const FT4A_SOCIAL = ['https://www.facebook.com/FT4A.nl','https://www.instagram.com/coach_ft4a_com','https://www.youtube.com/channel/UC63EkVOzetzmmh7QVK10sYw','https://twitter.com/FT4_all'];

function ft4a_seo() {
	static $d = [];
	$l = ft4a_lang();
	if (!isset($d[$l])) $d[$l] = json_decode((string) @file_get_contents(ft4a_site_dir() . 'seo.json'), true) ?: ['pages' => [], 'faq' => []];
	return $d[$l];
}
function ft4a_asset($f) { return plugins_url('assets/' . $f, __FILE__); }
function ft4a_is_shop_page() { return function_exists('is_cart') && (is_cart() || is_checkout() || is_account_page()); }

function ft4a_seo_title() {
	$key = ft4a_current_key();
	if ($key === null) return '';
	if ($key === 'home') return ft4a_t('Software en voetbaloefeningen voor de moderne voetbaltrainer');
	if ($key === '404') return ft4a_t('Deze pagina bestaat niet');
	$p = ft4a_seo()['pages'][$key] ?? [];
	$t = $p['title'] ?? ft4a_page_title($key);
	$h = $p['h1'] ?? '';
	if (in_array($key, FT4A_NOINDEX_KEYS, true) || $h === '') return $t;
	$long = $t . ': ' . $h;
	if (mb_stripos($h, $t) === false && mb_strlen($long) <= 60) return $long;
	return $h;
}
add_filter('pre_get_document_title', function ($t) { return ft4a_seo_title() ?: $t; }, 20);
// Geen sitenaam of slogan achter de titel (ook niet op de winkelpagina's)
add_filter('document_title_parts', function ($p) {
	if (is_admin()) return $p;
	unset($p['site'], $p['tagline']);
	if (ft4a_is_shop_page()) $p['title'] = ft4a_t(is_checkout() ? 'Afrekenen' : (is_cart() ? 'Winkelmand' : 'Mijn account'));
	return $p;
}, 99);

/* Geen dubbele of overbodige tags van WordPress */
add_filter('wp_sitemaps_enabled', '__return_false');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
add_action('template_redirect', function () { if (ft4a_current_key() !== null) remove_action('wp_head', 'rel_canonical'); }, 2);

/* Robots: privé- en winkelpagina's niet indexeren */
add_filter('wp_robots', function ($r) {
	$key = ft4a_current_key();
	$noindex = in_array($key, FT4A_NOINDEX_KEYS, true) || ft4a_is_shop_page() || isset($_GET['ft4a_koop']) || !empty($_GET['q']);
	if ($noindex) { unset($r['max-image-preview']); $r['noindex'] = true; $r['follow'] = true; }
	elseif ($key !== null) { $r['max-image-preview'] = 'large'; $r['max-snippet'] = '-1'; }
	return $r;
});

/* Meta, Open Graph, Twitter, canonical, favicon, structured data */
add_action('wp_head', function () {
	$key = ft4a_current_key();
	if (!has_site_icon()) {
		echo '<link rel="icon" href="' . esc_url(ft4a_asset('logo.svg')) . '" type="image/svg+xml">' . "\n";
		echo '<link rel="icon" href="' . esc_url(ft4a_asset('logo-32.png')) . '" sizes="32x32">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url(ft4a_asset('logo-180.png')) . '">' . "\n";
	}
	echo '<meta name="theme-color" content="#435149">' . "\n";
	if ($key === null || $key === '404') return;
	$lang = ft4a_lang();
	$p = ft4a_seo()['pages'][$key] ?? [];
	$desc = $p['desc'] ?? '';
	$url = ft4a_url($key);
	$title = ft4a_seo_title();
	if ($desc) echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
	echo '<link rel="canonical" href="' . esc_url($url) . '">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:site_name" content="FT4A.com">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
	if ($desc) echo '<meta property="og:description" content="' . esc_attr($desc) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url(ft4a_asset('og.png')) . '">' . "\n";
	echo '<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">' . "\n";
	echo '<meta property="og:locale" content="' . esc_attr(FT4A_OG_LOCALE[$lang]) . '">' . "\n";
	foreach (FT4A_OG_LOCALE as $c => $loc) if ($c !== $lang) echo '<meta property="og:locale:alternate" content="' . esc_attr($loc) . '">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:site" content="@FT4_all">' . "\n";
	if (in_array($key, FT4A_NOINDEX_KEYS, true)) return;

	$home = ft4a_url('home');
	$org = ['@type' => 'Organization', '@id' => home_url('/#org'), 'name' => 'FT4A.com', 'url' => home_url('/'), 'logo' => ft4a_asset('logo-512.png'),
		'sameAs' => FT4A_SOCIAL, 'contactPoint' => ['@type' => 'ContactPoint', 'telephone' => '+32456411184', 'contactType' => 'customer support', 'availableLanguage' => ['nl','en','fr']]];
	$app = ['@type' => 'SoftwareApplication', '@id' => home_url('/#software'), 'name' => 'FT4A', 'applicationCategory' => 'SportsApplication',
		'operatingSystem' => 'Windows, macOS, Web', 'url' => $home, 'image' => ft4a_asset('og.png'), 'publisher' => ['@id' => home_url('/#org')],
		'description' => ft4a_seo()['pages']['home']['desc'] ?? '', 'inLanguage' => FT4A_LANGS[$lang][2]];
	$graph = [];
	if ($key === 'home') {
		$app['offers'] = ['@type' => 'AggregateOffer', 'priceCurrency' => 'EUR', 'lowPrice' => 28, 'highPrice' => 204, 'offerCount' => 6, 'url' => ft4a_url('prijzen')];
		$graph = [$org, ['@type' => 'WebSite', '@id' => home_url('/#website'), 'url' => home_url('/'), 'name' => 'FT4A.com', 'inLanguage' => FT4A_LANGS[$lang][2], 'publisher' => ['@id' => home_url('/#org')]], $app];
	} else {
		$graph[] = ['@type' => 'WebPage', '@id' => $url, 'url' => $url, 'name' => $title, 'description' => $desc, 'inLanguage' => FT4A_LANGS[$lang][2], 'isPartOf' => ['@id' => home_url('/#website')],
			'breadcrumb' => ['@type' => 'BreadcrumbList', 'itemListElement' => [
				['@type' => 'ListItem', 'position' => 1, 'name' => ft4a_t('Home'), 'item' => $home],
				['@type' => 'ListItem', 'position' => 2, 'name' => $p['title'] ?? ft4a_page_title($key), 'item' => $url]]]];
		if ($key === 'prijzen' || $key === 'software') {
			$offers = [];
			foreach (FT4A_PAKKETTEN as $code => $pk) {
				if ($code === 'TRIAL') continue;
				$offers[] = ['@type' => 'Offer', 'name' => ft4a_t($pk[0]) . ' (' . ft4a_t($pk[1]) . ')', 'price' => $pk[2], 'priceCurrency' => 'EUR', 'availability' => 'https://schema.org/InStock', 'url' => ft4a_url('prijzen')];
			}
			$app['offers'] = $offers;
			$graph[] = $app;
		}
		if ($key === 'vragen' && ($faq = ft4a_seo()['faq'])) {
			$graph[] = ['@type' => 'FAQPage', '@id' => $url . '#faq', 'mainEntity' => array_map(function ($qa) {
				return ['@type' => 'Question', 'name' => $qa[0], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $qa[1]]];
			}, $faq)];
		}
	}
	echo '<script type="application/ld+json">' . wp_json_encode(['@context' => 'https://schema.org', '@graph' => $graph], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>' . "\n";
}, 1);

/* Sitemap met alle talen en hreflang-verwijzingen: /sitemap.xml
   lastmod = de dag waarop de inhoud van die pagina in die taal echt veranderde (niet elke plug-in-update). */
function ft4a_sitemap_lastmod($key, $code) {
	static $map = null, $dirty = false;
	if ($map === null) {
		$map = get_option('ft4a_sitemap_mod', []);
		if (!is_array($map)) $map = [];
		register_shutdown_function(function () use (&$map, &$dirty) { if ($dirty) update_option('ft4a_sitemap_mod', $map, false); });
	}
	if ($key === 'ledenoefeningen') {
		global $wpdb;
		$m = $wpdb->get_var("SELECT MAX(post_modified_gmt) FROM $wpdb->posts WHERE post_type='ft4a_oefening' AND post_status='publish'");
		if ($m) return gmdate('Y-m-d', strtotime($m . ' UTC'));
	}
	$d = ft4a_site_dir($code);
	$f = $key === 'home' ? $d . 'home.html' : $d . 'pages/' . $key . '.html';
	$h = is_readable($f) ? md5_file($f) . md5((string) @file_get_contents($d . 'seo.json')) : '';
	$id = $key . '|' . $code;
	if (!isset($map[$id]) || $map[$id][0] !== $h) { $map[$id] = [$h, gmdate('Y-m-d')]; $dirty = true; }
	return $map[$id][1];
}
add_action('init', function () {
	$path = ft4a_path();
	if (!in_array($path, ['sitemap.xml', 'wp-sitemap.xml', 'sitemap_index.xml', 'page-sitemap.xml', 'post-sitemap.xml'], true)) return;
	if ($path !== 'sitemap.xml') { wp_safe_redirect(home_url('/sitemap.xml'), 301); exit; }
	header('Content-Type: application/xml; charset=UTF-8');
	header('X-Robots-Tag: noindex, follow');
	header('Cache-Control: public, max-age=3600');
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";
	foreach (FT4A_PUBLIC_KEYS as $key) {
		$alt = '';
		foreach (FT4A_LANGS as $c2 => $l2) $alt .= '<xhtml:link rel="alternate" hreflang="' . esc_attr($l2[2]) . '" href="' . esc_url(ft4a_url($key, $c2)) . '"/>';
		$alt .= '<xhtml:link rel="alternate" hreflang="x-default" href="' . esc_url(ft4a_url($key, 'nl')) . '"/>';
		foreach (FT4A_LANGS as $code => $l) echo '<url><loc>' . esc_url(ft4a_url($key, $code)) . '</loc><lastmod>' . ft4a_sitemap_lastmod($key, $code) . '</lastmod>' . $alt . '</url>' . "\n";
	}
	echo '</urlset>';
	exit;
}, 0);

/* Yoast SEO: niet dubbel met de eigen tags op de FT4A-pagina's (Yoast zette daar een verkeerde canonical naar de homepage) */
add_action('wp', function () {
	if (ft4a_current_key() === null) return;
	add_filter('wpseo_frontend_presenters', '__return_empty_array', 99);
	add_filter('wpseo_json_ld_output', '__return_false', 99);
	add_filter('wpseo_debug_markers', '__return_false', 99);
}, 1);
add_filter('wpseo_enable_xml_sitemap', '__return_false');

/* robots.txt: één duidelijke groep, zonder het tweede blok van Yoast */
add_action('do_robotstxt', function () {
	ob_start(function ($out) { return trim(preg_replace('/\n*# START YOAST BLOCK.*?# END YOAST BLOCK\n*/s', "\n", $out)) . "\n"; });
}, 0);
add_filter('robots_txt', function ($out, $public) {
	if (!$public) return $out;
	$out = preg_replace('/\n*Sitemap:[^\n]*/i', '', rtrim($out)) . "\n";
	$out .= "Disallow: /online/\nDisallow: /app/\nDisallow: /updates/\nDisallow: /wp-content/uploads/ft4a-bib-\n"
		. "Disallow: /*?ft4a_koop=\nDisallow: /*?*ft4a_download=\nDisallow: /*?*redirect_to=\n"
		. "Disallow: /*?s=\nDisallow: /*?*&s=\nDisallow: /*?q=\nDisallow: /*?*&q=\nDisallow: /*?pg=\nDisallow: /*?*&pg=\nDisallow: /*?cat=\nDisallow: /*?*&cat=\nDisallow: /*?anim=\nDisallow: /*?*&anim=\n"
		. "Allow: /wp-content/uploads/ft4a-voorbeelden/\n\nSitemap: " . home_url('/sitemap.xml') . "\n";
	return $out;
}, 99, 2);

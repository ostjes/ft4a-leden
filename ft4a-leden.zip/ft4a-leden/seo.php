<?php
/* FT4A: zoekmachine-optimalisatie (titels, meta, Open Graph, structured data, sitemap, robots). */
if (!defined('ABSPATH')) exit;

const FT4A_PUBLIC_KEYS = ['home','oefeningen','software','prijzen','vragen','handleiding','reviews','contact','ledenoefeningen','privacy','voorwaarden'];
const FT4A_NOINDEX_KEYS = ['account','inloggen','oefening-toevoegen','404'];
const FT4A_OG_LOCALE = ['nl'=>'nl_NL','en'=>'en_GB','en-us'=>'en_US','fr'=>'fr_FR','de'=>'de_DE','es'=>'es_ES','it'=>'it_IT','pt'=>'pt_PT','pt-br'=>'pt_BR','da'=>'da_DK','sv'=>'sv_SE','fi'=>'fi_FI','no'=>'nb_NO','pl'=>'pl_PL','tr'=>'tr_TR','ru'=>'ru_RU','ro'=>'ro_RO','ar'=>'ar_AR'];
const FT4A_SOCIAL = ['https://www.facebook.com/FT4A.nl','https://www.instagram.com/coach_ft4a_com','https://www.youtube.com/channel/UC63EkVOzetzmmh7QVK10sYw','https://twitter.com/FT4_all'];

function ft4a_seo() {
	static $d = [];
	$l = ft4a_lang();
	if (!isset($d[$l])) { $d[$l] = json_decode((string) @file_get_contents(ft4a_site_dir() . 'seo.json'), true) ?: ['pages' => [], 'faq' => []];
		if (function_exists('ft4a_fix_counts')) array_walk_recursive($d[$l], function (&$v) { $v = ft4a_fix_counts($v); }); }
	return $d[$l];
}
function ft4a_asset($f) { return plugins_url('assets/' . $f, __FILE__); }
function ft4a_is_shop_page() { return function_exists('is_cart') && (is_cart() || is_checkout() || is_account_page()); }

function ft4a_seo_title() {
	$key = ft4a_current_key();
	if ($key === null) return '';
	if ($key === 'home') return ft4a_t('Software en voetbaloefeningen voor de moderne voetbaltrainer');
	if ($key === '404') return ft4a_t('Deze pagina bestaat niet');
	$p = ft4a_seo()['pages'][$key] ?? [];
	$t = $p['title'] ?? ft4a_page_title($key);
	$h = $p['h1'] ?? '';
	if (in_array($key, FT4A_NOINDEX_KEYS, true) || $h === '') return $t;
	$long = $t . ': ' . $h;
	if (mb_stripos($h, $t) === false && mb_strlen($long) <= 60) return $long;
	return $h;
}
add_filter('pre_get_document_title', function ($t) { return ft4a_seo_title() ?: $t; }, 20);
// Geen sitenaam of slogan achter de titel (ook niet op de winkelpagina's)
add_filter('document_title_parts', function ($p) {
	if (is_admin()) return $p;
	unset($p['site'], $p['tagline']);
	if (ft4a_is_shop_page()) $p['title'] = ft4a_t(is_checkout() ? 'Afrekenen' : (is_cart() ? 'Winkelmand' : 'Mijn account'));
	return $p;
}, 99);

/* Geen dubbele of overbodige tags van WordPress */
add_filter('wp_sitemaps_enabled', '__return_false');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
add_action('template_redirect', function () { if (ft4a_current_key() !== null) remove_action('wp_head', 'rel_canonical'); }, 2);

/* Robots: privé- en winkelpagina's niet indexeren */
add_filter('wp_robots', function ($r) {
	$key = ft4a_current_key();
	$noindex = in_array($key, FT4A_NOINDEX_KEYS, true) || ft4a_is_shop_page() || isset($_GET['ft4a_koop']) || !empty($_GET['q']);
	if ($noindex) { unset($r['max-image-preview']); $r['noindex'] = true; $r['follow'] = true; }
	elseif ($key !== null) { $r['max-image-preview'] = 'large'; $r['max-snippet'] = '-1'; }
	return $r;
});

/* Meta, Open Graph, Twitter, canonical, favicon, structured data */
add_action('wp_head', function () {
	$key = ft4a_current_key();
	if (!has_site_icon()) {
		echo '<link rel="icon" href="' . esc_url(ft4a_asset('logo.svg')) . '" type="image/svg+xml">' . "\n";
		echo '<link rel="icon" href="' . esc_url(ft4a_asset('logo-32.png')) . '" sizes="32x32">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url(ft4a_asset('logo-180.png')) . '">' . "\n";
	}
	echo '<meta name="theme-color" content="#435149">' . "\n";
	if ($key === null || $key === '404') return;
	$lang = ft4a_lang();
	$p = ft4a_seo()['pages'][$key] ?? [];
	$desc = $p['desc'] ?? '';
	$url = ft4a_url($key);
	$title = ft4a_seo_title();
	if ($desc) echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
	echo '<link rel="canonical" href="' . esc_url($url) . '">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:site_name" content="FT4A.com">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
	if ($desc) echo '<meta property="og:description" content="' . esc_attr($desc) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url(ft4a_asset('og.png')) . '">' . "\n";
	echo '<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">' . "\n";
	echo '<meta property="og:locale" content="' . esc_attr(FT4A_OG_LOCALE[$lang]) . '">' . "\n";
	foreach (FT4A_OG_LOCALE as $c => $loc) if ($c !== $lang) echo '<meta property="og:locale:alternate" content="' . esc_attr($loc) . '">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:site" content="@FT4_all">' . "\n";
	if (in_array($key, FT4A_NOINDEX_KEYS, true)) return;

	$home = ft4a_url('home');
	$org = ['@type' => 'Organization', '@id' => home_url('/#org'), 'name' => 'FT4A.com', 'url' => home_url('/'), 'logo' => ft4a_asset('logo-512.png'),
		'sameAs' => FT4A_SOCIAL, 'contactPoint' => ['@type' => 'ContactPoint', 'telephone' => '+32456411184', 'contactType' => 'customer support', 'availableLanguage' => ['nl','en','fr']]];
	$app = ['@type' => 'SoftwareApplication', '@id' => home_url('/#software'), 'name' => 'FT4A', 'applicationCategory' => 'SportsApplication',
		'operatingSystem' => 'Windows, macOS, Web', 'url' => $home, 'image' => ft4a_asset('og.png'), 'publisher' => ['@id' => home_url('/#org')],
		'description' => ft4a_seo()['pages']['home']['desc'] ?? '', 'inLanguage' => FT4A_LANGS[$lang][2]];
	$graph = [];
	if ($key === 'home') {
		$app['offers'] = ['@type' => 'AggregateOffer', 'priceCurrency' => 'EUR', 'lowPrice' => 28, 'highPrice' => 204, 'offerCount' => 6, 'url' => ft4a_url('prijzen')];
		$graph = [$org, ['@type' => 'WebSite', '@id' => home_url('/#website'), 'url' => home_url('/'), 'name' => 'FT4A.com', 'inLanguage' => FT4A_LANGS[$lang][2], 'publisher' => ['@id' => home_url('/#org')]], $app];
	} else {
		$graph[] = ['@type' => 'WebPage', '@id' => $url, 'url' => $url, 'name' => $title, 'description' => $desc, 'inLanguage' => FT4A_LANGS[$lang][2], 'isPartOf' => ['@id' => home_url('/#website')],
			'breadcrumb' => ['@type' => 'BreadcrumbList', 'itemListElement' => [
				['@type' => 'ListItem', 'position' => 1, 'name' => ft4a_t('Home'), 'item' => $home],
				['@type' => 'ListItem', 'position' => 2, 'name' => $p['title'] ?? ft4a_page_title($key), 'item' => $url]]]];
		if ($key === 'prijzen' || $key === 'software') {
			$offers = [];
			foreach (FT4A_PAKKETTEN as $code => $pk) {
				if ($code === 'TRIAL') continue;
				$offers[] = ['@type' => 'Offer', 'name' => ft4a_t($pk[0]) . ' (' . ft4a_t($pk[1]) . ')', 'price' => $pk[2], 'priceCurrency' => 'EUR', 'availability' => 'https://schema.org/InStock', 'url' => ft4a_url('prijzen')];
			}
			$app['offers'] = $offers;
			$graph[] = $app;
		}
		if (in_array($key, ['oefeningen', 'handleiding', 'vragen'], true)) foreach (ft4a_video_objects($key, $url, $desc) as $v) $graph[] = $v;
		if ($key === 'vragen' && ($faq = ft4a_seo()['faq'])) {
			$graph[] = ['@type' => 'FAQPage', '@id' => $url . '#faq', 'mainEntity' => array_map(function ($qa) {
				return ['@type' => 'Question', 'name' => $qa[0], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $qa[1]]];
			}, $faq)];
		}
	}
	echo '<script type="application/ld+json">' . wp_json_encode(['@context' => 'https://schema.org', '@graph' => $graph], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>' . "\n";
}, 1);

/* Video's (Vimeo) als VideoObject, met de titel en uitleg in de taal van de pagina.
   Gegevens van Vimeo (miniatuur, datum, duur) staan in assets/videos.json; een nieuw video-nummer wordt één keer via oEmbed opgehaald en bewaard. */
function ft4a_video_meta($id) {
	static $base = null, $extra = null, $fetched = 0;
	if ($base === null) { $base = json_decode((string) @file_get_contents(__DIR__ . '/assets/videos.json'), true) ?: []; $extra = get_option('ft4a_vmeta', []); if (!is_array($extra)) $extra = []; }
	if (isset($base[$id])) return $base[$id];
	if (isset($extra[$id]) && (!empty($extra[$id][0]) || (time() - (int) ($extra[$id][3] ?? 0)) < DAY_IN_SECONDS)) return !empty($extra[$id][0]) ? $extra[$id] : null;
	if ($fetched++ >= 3) return null;
	$r = wp_remote_get('https://vimeo.com/api/oembed.json?url=' . rawurlencode('https://vimeo.com/' . $id), ['timeout' => 4]);
	$j = is_wp_error($r) ? null : json_decode(wp_remote_retrieve_body($r), true);
	$m = !empty($j['thumbnail_url']) ? [preg_replace(['#-d_\d+x\d+#', '#\?region=\w+$#'], ['-d_1280x720', ''], $j['thumbnail_url']), substr((string) ($j['upload_date'] ?? ''), 0, 10), (int) ($j['duration'] ?? 0), time()] : ['', '', 0, time()];
	$extra[$id] = $m;
	update_option('ft4a_vmeta', $extra, false);
	return $m[0] ? $m : null;
}
function ft4a_video_objects($key, $url, $pagedesc) {
	$html = function_exists('ft4a_page_html') ? ft4a_page_html($key) : '';
	if (!$html || strpos($html, 'data-v=') === false || !class_exists('DOMDocument')) return [];
	$dom = new DOMDocument();
	libxml_use_internal_errors(true);
	$dom->loadHTML('<?xml encoding="utf-8"?><div>' . $html . '</div>');
	libxml_clear_errors();
	$x = new DOMXPath($dom);
	$txt = function ($n) { return $n ? trim(preg_replace('/\s+/u', ' ', $n->textContent)) : ''; };
	$one = function ($q, $ctx) use ($x) { $l = $x->query($q, $ctx); return $l && $l->length ? $l->item(0) : null; };
	$lang = ft4a_lang();
	$out = []; $seen = [];
	foreach ($x->query('//button[contains(concat(" ", normalize-space(@class), " "), " vf ")][@data-v]') as $b) {
		$id = preg_replace('/\D/', '', $b->getAttribute('data-v'));
		if (!$id || isset($seen[$id])) continue;
		$m = ft4a_video_meta($id);
		if (!$m || empty($m[1])) continue;
		$seen[$id] = 1;
		$name = $txt($one('.//span[contains(@class,"vf-t")]', $b));
		if ($name === '') { $a = $b->getAttribute('aria-label'); $name = trim(strpos($a, ':') !== false ? substr($a, strpos($a, ':') + 1) : $a); }
		$parts = [];
		if ($fa = $one('ancestor::details[1]', $b)) {                      // vragen: antwoord bij de vraag
			$s = $txt($one('.//summary', $fa)); if ($s !== '') $name = $s;
			$parts[] = $txt($one('.//div[contains(@class,"fa")]/div', $fa));
		} else {
			$card = $one('ancestor::article[1]', $b);
			if ($card) $parts[] = $txt($one('.//div[contains(@class,"vc-b")]/p', $card));
			if ($cs = $one('ancestor::div[contains(@class,"catsec")][1]', $b)) $parts[] = $txt($one('.//div[contains(@class,"cs-h")]/p', $cs));
			elseif ($hg = $one('ancestor::div[contains(@class,"hgroup")][1]', $b)) { $h2 = $txt($one('.//h2', $hg)); if ($h2 !== '') $parts[] = $h2 . ': ' . $name . '.'; $parts[] = $pagedesc; }
		}
		$d = ''; foreach (array_filter(array_unique($parts)) as $pt) $d .= ($d === '' ? '' : (preg_match('/[.!?؟。]$/u', $d) ? ' ' : '. ')) . $pt; $d = trim($d);
		if ($d === '') $d = $pagedesc ?: $name;
		$o = ['@type' => 'VideoObject', '@id' => $url . '#video-' . $id, 'name' => $name, 'description' => mb_substr($d, 0, 1000), 'thumbnailUrl' => $m[0],
			'uploadDate' => $m[1], 'embedUrl' => 'https://player.vimeo.com/video/' . $id, 'inLanguage' => FT4A_LANGS[$lang][2],
			'isPartOf' => ['@id' => $url], 'publisher' => ['@id' => home_url('/#org')]];
		if (!empty($m[2])) $o['duration'] = 'PT' . ((int) floor($m[2] / 60) ? floor($m[2] / 60) . 'M' : '') . ($m[2] % 60) . 'S';
		$out[] = $o;
	}
	return $out;
}

/* Sitemap met alle talen en hreflang-verwijzingen: /sitemap.xml
   lastmod = de dag waarop de inhoud van die pagina in die taal echt veranderde (niet elke plug-in-update). */
function ft4a_sitemap_lastmod($key, $code) {
	static $map = null, $dirty = false;
	if ($map === null) {
		$map = get_option('ft4a_sitemap_mod', []);
		if (!is_array($map)) $map = [];
		register_shutdown_function(function () use (&$map, &$dirty) { if ($dirty) update_option('ft4a_sitemap_mod', $map, false); });
	}
	if ($key === 'ledenoefeningen') {
		global $wpdb;
		$m = $wpdb->get_var("SELECT MAX(post_modified_gmt) FROM $wpdb->posts WHERE post_type='ft4a_oefening' AND post_status='publish'");
		if ($m) return gmdate('Y-m-d', strtotime($m . ' UTC'));
	}
	// pagina bewerkt in WordPress: de datum van de laatste wijziging daar
	if (function_exists('ft4a_page_post') && ($p = ft4a_page_post($key, $code))) return gmdate('Y-m-d', strtotime($p->post_modified_gmt . ' UTC'));
	$d = ft4a_site_dir($code);
	$f = $key === 'home' ? $d . 'home.html' : $d . 'pages/' . $key . '.html';
	$h = is_readable($f) ? md5_file($f) . md5((string) @file_get_contents($d . 'seo.json')) : '';
	$id = $key . '|' . $code;
	if (!isset($map[$id]) || $map[$id][0] !== $h) { $map[$id] = [$h, gmdate('Y-m-d')]; $dirty = true; }
	return $map[$id][1];
}
/* Dynamische sitemap: /sitemap.xml is een index die zichzelf opbouwt uit wat er op de site staat.
   - sitemap-paginas.xml: alle FT4A-pagina's in alle talen, met hreflang, lastmod en afbeeldingen
   - sitemap-oefeningen.xml: de afbeeldingen van de gepubliceerde oefeningen (bij de ledenoefeningen)
   - sitemap-extra.xml: andere gepubliceerde WordPress-pagina's en berichten (alleen als die er zijn) */
function ft4a_sitemap_extra_posts() {
	$skip = [];
	foreach (['cart', 'checkout', 'myaccount', 'shop', 'terms'] as $w) if (function_exists('wc_get_page_id') && ($id = wc_get_page_id($w)) > 0) $skip[] = $id;
	$skip[] = (int) get_option('page_on_front');
	$q = new WP_Query(['post_type' => ['post', 'page'], 'post_status' => 'publish', 'posts_per_page' => 500, 'post__not_in' => array_filter($skip), 'no_found_rows' => true,
		'meta_query' => [['key' => '_ft4a_key', 'compare' => 'NOT EXISTS']], 'has_password' => false, 'orderby' => 'modified', 'order' => 'DESC']);
	$out = [];
	foreach ($q->posts as $p) {
		if (get_post_meta($p->ID, '_ft4a_lang', true) !== '' || get_post_meta($p->ID, '_ft4a_hash', true) !== '' || get_post_meta($p->ID, '_ft4a_page', true) !== '') continue;   // FT4A-pagina's staan al in sitemap-paginas.xml
		$out[] = $p;
	}
	return $out;
}
function ft4a_sitemap_oef_images() {
	$q = new WP_Query(['post_type' => 'ft4a_oefening', 'post_status' => 'publish', 'posts_per_page' => 1000, 'no_found_rows' => true, 'orderby' => ['menu_order' => 'ASC', 'date' => 'DESC']]);
	$out = [];
	foreach ($q->posts as $p) {
		$img = get_the_post_thumbnail_url($p, 'large');
		if (!$img && ($nr = get_post_meta($p->ID, '_ft4a_bron_nr', true)) && is_readable(ft4a_prev_dir() . $nr . '.webp')) $img = ft4a_prev_url() . $nr . '.webp';
		if ($img) $out[] = [$img, function_exists('ft4a_oef_title') ? ft4a_oef_title($p) : get_the_title($p), $p->post_modified_gmt];
	}
	return $out;
}
function ft4a_sitemap_out($xml) {
	header('Content-Type: application/xml; charset=UTF-8');
	header('X-Robots-Tag: noindex, follow');
	header('Cache-Control: public, max-age=3600');
	if (function_exists('do_action')) do_action('litespeed_control_set_ttl', 3600);
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . $xml;
	exit;
}
add_action('init', function () {
	$path = ft4a_path();
	$old = ['wp-sitemap.xml', 'sitemap_index.xml', 'page-sitemap.xml', 'post-sitemap.xml', 'sitemap.xml.gz'];
	if (in_array($path, $old, true)) { wp_safe_redirect(home_url('/sitemap.xml'), 301); exit; }
	if (!in_array($path, ['sitemap.xml', 'sitemap-paginas.xml', 'sitemap-oefeningen.xml', 'sitemap-extra.xml'], true)) return;
	$e = function ($s) { return htmlspecialchars((string) $s, ENT_XML1 | ENT_QUOTES, 'UTF-8'); };
	$d = function ($gmt) { return $gmt ? gmdate('Y-m-d', strtotime($gmt . ' UTC')) : gmdate('Y-m-d'); };
	$shot = ft4a_asset('shots/software.webp');
	$img_pages = ['home' => 1, 'software' => 1, 'prijzen' => 1, 'vragen' => 1, 'handleiding' => 1, 'reviews' => 1];

	if ($path === 'sitemap-paginas.xml') {
		$x = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
		foreach (FT4A_PUBLIC_KEYS as $key) {
			$alt = '';
			foreach (FT4A_LANGS as $c2 => $l2) $alt .= '<xhtml:link rel="alternate" hreflang="' . $e($l2[2]) . '" href="' . $e(ft4a_url($key, $c2)) . '"/>';
			$alt .= '<xhtml:link rel="alternate" hreflang="x-default" href="' . $e(ft4a_url($key, 'nl')) . '"/>';
			$img = isset($img_pages[$key]) ? '<image:image><image:loc>' . $e($shot) . '</image:loc></image:image>' : '';
			foreach (FT4A_LANGS as $code => $l) $x .= '<url><loc>' . $e(ft4a_url($key, $code)) . '</loc><lastmod>' . ft4a_sitemap_lastmod($key, $code) . '</lastmod>' . $alt . $img . '</url>' . "\n";
		}
		ft4a_sitemap_out($x . '</urlset>');
	}
	if ($path === 'sitemap-oefeningen.xml') {
		$imgs = ft4a_sitemap_oef_images();
		$x = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
		$last = $imgs ? max(array_map(function ($i) { return $i[2]; }, $imgs)) : '';
		$x .= '<url><loc>' . $e(ft4a_url('ledenoefeningen', 'nl')) . '</loc><lastmod>' . $d($last) . '</lastmod>';
		foreach ($imgs as $i) $x .= '<image:image><image:loc>' . $e($i[0]) . '</image:loc></image:image>';
		ft4a_sitemap_out($x . '</url>' . "\n" . '</urlset>');
	}
	if ($path === 'sitemap-extra.xml') {
		$x = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		foreach (ft4a_sitemap_extra_posts() as $p) $x .= '<url><loc>' . $e(get_permalink($p)) . '</loc><lastmod>' . $d($p->post_modified_gmt) . '</lastmod></url>' . "\n";
		ft4a_sitemap_out($x . '</urlset>');
	}
	// de index
	$mods = [];
	foreach (FT4A_PUBLIC_KEYS as $key) foreach (FT4A_LANGS as $code => $l) $mods[] = ft4a_sitemap_lastmod($key, $code);
	$x = '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
	$x .= '<sitemap><loc>' . $e(home_url('/sitemap-paginas.xml')) . '</loc><lastmod>' . max($mods) . '</lastmod></sitemap>' . "\n";
	global $wpdb;
	$om = $wpdb->get_var("SELECT MAX(post_modified_gmt) FROM $wpdb->posts WHERE post_type='ft4a_oefening' AND post_status='publish'");
	if ($om) $x .= '<sitemap><loc>' . $e(home_url('/sitemap-oefeningen.xml')) . '</loc><lastmod>' . $d($om) . '</lastmod></sitemap>' . "\n";
	$extra = ft4a_sitemap_extra_posts();
	if ($extra) $x .= '<sitemap><loc>' . $e(home_url('/sitemap-extra.xml')) . '</loc><lastmod>' . $d($extra[0]->post_modified_gmt) . '</lastmod></sitemap>' . "\n";
	ft4a_sitemap_out($x . '</sitemapindex>');
}, 0);

/* Yoast SEO: niet dubbel met de eigen tags op de FT4A-pagina's (Yoast zette daar een verkeerde canonical naar de homepage) */
add_action('wp', function () {
	if (ft4a_current_key() === null) return;
	add_filter('wpseo_frontend_presenters', '__return_empty_array', 99);
	add_filter('wpseo_json_ld_output', '__return_false', 99);
	add_filter('wpseo_debug_markers', '__return_false', 99);
}, 1);
add_filter('wpseo_enable_xml_sitemap', '__return_false');

/* robots.txt: één duidelijke groep, zonder het tweede blok van Yoast */
add_action('do_robotstxt', function () {
	ob_start(function ($out) { return trim(preg_replace('/\n*# START YOAST BLOCK.*?# END YOAST BLOCK\n*/s', "\n", $out)) . "\n"; });
}, 0);
add_filter('robots_txt', function ($out, $public) {
	if (!$public) return $out;
	$out = preg_replace('/\n*Sitemap:[^\n]*/i', '', rtrim($out)) . "\n";
	$out .= "Disallow: /online/\nDisallow: /app/\nDisallow: /updates/\nDisallow: /wp-content/uploads/ft4a-bib-\n"
		. "Disallow: /*?ft4a_koop=\nDisallow: /*?*ft4a_download=\nDisallow: /*?*redirect_to=\n"
		. "Disallow: /*?s=\nDisallow: /*?*&s=\nDisallow: /*?q=\nDisallow: /*?*&q=\nDisallow: /*?pg=\nDisallow: /*?*&pg=\nDisallow: /*?cat=\nDisallow: /*?*&cat=\nDisallow: /*?anim=\nDisallow: /*?*&anim=\n"
		. "Allow: /wp-content/uploads/ft4a-voorbeelden/\n";
	// winkel- en accountpagina's (welke dat zijn, haalt WordPress zelf op)
	if (function_exists('wc_get_page_id')) foreach (['cart', 'checkout', 'myaccount'] as $w) {
		$id = wc_get_page_id($w);
		if ($id > 0 && ($u = get_permalink($id)) && ($pth = wp_parse_url($u, PHP_URL_PATH)) && $pth !== '/') $out .= 'Disallow: ' . $pth . "\n";
	}
	// privé FT4A-pagina's in alle talen (account, inloggen, oefening toevoegen)
	foreach (FT4A_NOINDEX_KEYS as $k) { if ($k === '404') continue; foreach (FT4A_LANGS as $c => $l) { $pth = wp_parse_url(ft4a_url($k, $c), PHP_URL_PATH); if ($pth && $pth !== '/') $out .= 'Disallow: ' . $pth . "\n"; } }
	$out = implode("\n", array_unique(explode("\n", rtrim($out)))) . "\n";
	$out .= "\nSitemap: " . home_url('/sitemap.xml') . "\n";
	return $out;
}, 99, 2);

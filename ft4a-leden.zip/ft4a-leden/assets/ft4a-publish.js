/*
 * FT4A.com - Publiceren vanuit de online software (alleen op ft4a.com/online/).
 * Voegt aan het menu Exporteren "Publiceren op FT4A.com" toe. Het venster stelt titel, categorie, leeftijd en uitleg
 * voor vanuit de oefening; de software maakt zelf de voorbeeldafbeelding. Zie ft4a_publish in ft4a-leden.php.
 */
(function () {
  'use strict';
  var CFG = window.FT4A_PUB;
  if (!CFG || typeof doc === 'undefined' || typeof exportSVGString !== 'function' || !document.getElementById('exportMenu')) return;

  var S = {
    nl: { menu: 'Publiceren op FT4A.com', head: 'Oefening publiceren', intro: 'Je oefening komt meteen in de oefeningendatabase op FT4A.com, voor alle leden.', title: 'Titel', cat: 'Categorie', age: 'Leeftijd', desc: 'Uitleg', descPh: 'Organisatie, verloop, coachingspunten…', prev: 'Voorbeeldafbeelding', pub: 'Publiceren', busy: 'Bezig met publiceren…', done: 'Je oefening staat nu in de oefeningendatabase.', updDone: 'Je oefening is bijgewerkt in de oefeningendatabase.', view: 'Bekijken in de database', empty: 'Teken eerst een oefening op het veld.', dbSame: 'Deze oefening komt uit de oefeningendatabase. Pas ze eerst aan voor je ze publiceert.', eTitle: 'Geef je oefening een titel (minstens 3 tekens).', login: 'Je bent niet meer ingelogd. Log opnieuw in op FT4A.com en probeer het nog eens.', member: 'Om te publiceren heb je een online of compleet pakket nodig.', nonce: 'Je sessie is verlopen. Sla je oefening op, herlaad de pagina en probeer het opnieuw.', size: 'Deze oefening is te groot om te publiceren (maximaal {n} MB).', fail: 'Publiceren is niet gelukt. Controleer je internetverbinding en probeer het opnieuw.', limit: 'Je hebt het afgelopen uur al veel oefeningen gepubliceerd. Probeer het later opnieuw.', exists: 'Je hebt deze oefening al eerder gepubliceerd als „{t}”. Wil je die bijwerken of een nieuwe oefening publiceren?', upd: 'Bijwerken', asNew: 'Als nieuwe oefening' },
    en: { menu: 'Publish on FT4A.com', head: 'Publish drill', intro: 'Your drill goes straight into the drill database on FT4A.com, for all members.', title: 'Title', cat: 'Category', age: 'Age group', desc: 'Explanation', descPh: 'Organisation, procedure, coaching points…', prev: 'Preview image', pub: 'Publish', busy: 'Publishing…', done: 'Your drill is now in the drill database.', updDone: 'Your drill has been updated in the drill database.', view: 'View in the database', empty: 'First draw a drill on the field.', dbSame: 'This drill comes from the drill database. Change it before you publish it.', eTitle: 'Give your drill a title (at least 3 characters).', login: 'You are no longer logged in. Log in again on FT4A.com and try again.', member: 'To publish you need an online or complete package.', nonce: 'Your session has expired. Save your drill, reload the page and try again.', size: 'This drill is too large to publish (maximum {n} MB).', fail: 'Publishing did not succeed. Check your internet connection and try again.', limit: 'You have already published many drills in the past hour. Please try again later.', exists: 'You already published this drill as “{t}”. Do you want to update it or publish a new drill?', upd: 'Update', asNew: 'As a new drill' },
    fr: { menu: 'Publier sur FT4A.com', head: 'Publier l’exercice', intro: 'Votre exercice arrive directement dans la base d’exercices de FT4A.com, pour tous les membres.', title: 'Titre', cat: 'Catégorie', age: 'Âge', desc: 'Explication', descPh: 'Organisation, déroulement, points de coaching…', prev: 'Image d’aperçu', pub: 'Publier', busy: 'Publication en cours…', done: 'Votre exercice est maintenant dans la base d’exercices.', updDone: 'Votre exercice a été mis à jour dans la base d’exercices.', view: 'Voir dans la base', empty: 'Dessinez d’abord un exercice sur le terrain.', dbSame: 'Cet exercice vient de la base d’exercices. Modifiez-le avant de le publier.', eTitle: 'Donnez un titre à votre exercice (au moins 3 caractères).', login: 'Vous n’êtes plus connecté. Reconnectez-vous sur FT4A.com et réessayez.', member: 'Pour publier, il vous faut un pack en ligne ou complet.', nonce: 'Votre session a expiré. Enregistrez votre exercice, rechargez la page et réessayez.', size: 'Cet exercice est trop volumineux pour être publié (maximum {n} Mo).', fail: 'La publication n’a pas réussi. Vérifiez votre connexion internet et réessayez.', limit: 'Vous avez déjà publié beaucoup d’exercices au cours de la dernière heure. Réessayez plus tard.', exists: 'Vous avez déjà publié cet exercice sous le nom « {t} ». Voulez-vous le mettre à jour ou publier un nouvel exercice ?', upd: 'Mettre à jour', asNew: 'Comme nouvel exercice' },
    de: { menu: 'Auf FT4A.com veröffentlichen', head: 'Übung veröffentlichen', intro: 'Deine Übung kommt sofort in die Übungsdatenbank auf FT4A.com, für alle Mitglieder.', title: 'Titel', cat: 'Kategorie', age: 'Altersklasse', desc: 'Erklärung', descPh: 'Organisation, Ablauf, Coachingpunkte…', prev: 'Vorschaubild', pub: 'Veröffentlichen', busy: 'Wird veröffentlicht…', done: 'Deine Übung ist jetzt in der Übungsdatenbank.', updDone: 'Deine Übung wurde in der Übungsdatenbank aktualisiert.', view: 'In der Datenbank ansehen', empty: 'Zeichne zuerst eine Übung auf das Spielfeld.', dbSame: 'Diese Übung stammt aus der Übungsdatenbank. Ändere sie, bevor du sie veröffentlichst.', eTitle: 'Gib deiner Übung einen Titel (mindestens 3 Zeichen).', login: 'Du bist nicht mehr angemeldet. Melde dich auf FT4A.com erneut an und versuche es noch einmal.', member: 'Zum Veröffentlichen brauchst du ein Online- oder Komplettpaket.', nonce: 'Deine Sitzung ist abgelaufen. Speichere deine Übung, lade die Seite neu und versuche es erneut.', size: 'Diese Übung ist zu groß zum Veröffentlichen (maximal {n} MB).', fail: 'Das Veröffentlichen hat nicht geklappt. Prüfe deine Internetverbindung und versuche es erneut.', limit: 'Du hast in der letzten Stunde schon viele Übungen veröffentlicht. Versuche es später noch einmal.', exists: 'Du hast diese Übung bereits als „{t}“ veröffentlicht. Möchtest du sie aktualisieren oder eine neue Übung veröffentlichen?', upd: 'Aktualisieren', asNew: 'Als neue Übung' },
    es: { menu: 'Publicar en FT4A.com', head: 'Publicar ejercicio', intro: 'Tu ejercicio pasa directamente a la base de ejercicios de FT4A.com, para todos los miembros.', title: 'Título', cat: 'Categoría', age: 'Edad', desc: 'Explicación', descPh: 'Organización, desarrollo, puntos de coaching…', prev: 'Imagen de vista previa', pub: 'Publicar', busy: 'Publicando…', done: 'Tu ejercicio ya está en la base de ejercicios.', updDone: 'Tu ejercicio se ha actualizado en la base de ejercicios.', view: 'Ver en la base de datos', empty: 'Primero dibuja un ejercicio en el campo.', dbSame: 'Este ejercicio viene de la base de ejercicios. Modifícalo antes de publicarlo.', eTitle: 'Ponle un título a tu ejercicio (al menos 3 caracteres).', login: 'Ya no has iniciado sesión. Vuelve a iniciar sesión en FT4A.com e inténtalo de nuevo.', member: 'Para publicar necesitas un paquete online o completo.', nonce: 'Tu sesión ha caducado. Guarda tu ejercicio, recarga la página e inténtalo de nuevo.', size: 'Este ejercicio es demasiado grande para publicarlo (máximo {n} MB).', fail: 'No se ha podido publicar. Comprueba tu conexión a internet e inténtalo de nuevo.', limit: 'Ya has publicado muchos ejercicios en la última hora. Inténtalo más tarde.', exists: 'Ya publicaste este ejercicio como «{t}». ¿Quieres actualizarlo o publicar un ejercicio nuevo?', upd: 'Actualizar', asNew: 'Como ejercicio nuevo' },
    it: { menu: 'Pubblica su FT4A.com', head: 'Pubblica esercizio', intro: 'Il tuo esercizio entra subito nel database degli esercizi di FT4A.com, per tutti i membri.', title: 'Titolo', cat: 'Categoria', age: 'Età', desc: 'Spiegazione', descPh: 'Organizzazione, svolgimento, punti di coaching…', prev: 'Immagine di anteprima', pub: 'Pubblica', busy: 'Pubblicazione in corso…', done: 'Il tuo esercizio ora è nel database degli esercizi.', updDone: 'Il tuo esercizio è stato aggiornato nel database degli esercizi.', view: 'Vedi nel database', empty: 'Prima disegna un esercizio sul campo.', dbSame: 'Questo esercizio viene dal database degli esercizi. Modificalo prima di pubblicarlo.', eTitle: 'Dai un titolo al tuo esercizio (almeno 3 caratteri).', login: 'Non sei più connesso. Accedi di nuovo su FT4A.com e riprova.', member: 'Per pubblicare ti serve un pacchetto online o completo.', nonce: 'La sessione è scaduta. Salva l’esercizio, ricarica la pagina e riprova.', size: 'Questo esercizio è troppo grande da pubblicare (massimo {n} MB).', fail: 'La pubblicazione non è riuscita. Controlla la connessione internet e riprova.', limit: 'Nell’ultima ora hai già pubblicato molti esercizi. Riprova più tardi.', exists: 'Hai già pubblicato questo esercizio come «{t}». Vuoi aggiornarlo o pubblicare un nuovo esercizio?', upd: 'Aggiorna', asNew: 'Come nuovo esercizio' },
    pt: { menu: 'Publicar no FT4A.com', head: 'Publicar exercício', intro: 'O seu exercício entra logo na base de exercícios do FT4A.com, para todos os membros.', title: 'Título', cat: 'Categoria', age: 'Idade', desc: 'Explicação', descPh: 'Organização, execução, pontos de treino…', prev: 'Imagem de pré-visualização', pub: 'Publicar', busy: 'A publicar…', done: 'O seu exercício já está na base de exercícios.', updDone: 'O seu exercício foi atualizado na base de exercícios.', view: 'Ver na base de dados', empty: 'Desenhe primeiro um exercício no campo.', dbSame: 'Este exercício vem da base de exercícios. Altere-o antes de o publicar.', eTitle: 'Dê um título ao seu exercício (pelo menos 3 caracteres).', login: 'Já não tem sessão iniciada. Inicie sessão novamente no FT4A.com e tente outra vez.', member: 'Para publicar precisa de um pacote online ou completo.', nonce: 'A sua sessão expirou. Guarde o exercício, recarregue a página e tente novamente.', size: 'Este exercício é demasiado grande para publicar (máximo {n} MB).', fail: 'Não foi possível publicar. Verifique a ligação à internet e tente novamente.', limit: 'Já publicou muitos exercícios na última hora. Tente mais tarde.', exists: 'Já publicou este exercício como «{t}». Quer atualizá-lo ou publicar um exercício novo?', upd: 'Atualizar', asNew: 'Como exercício novo' },
    ro: { menu: 'Publică pe FT4A.com', head: 'Publică exercițiul', intro: 'Exercițiul tău intră imediat în baza de exerciții FT4A.com, pentru toți membrii.', title: 'Titlu', cat: 'Categorie', age: 'Vârstă', desc: 'Explicație', descPh: 'Organizare, desfășurare, indicații de coaching…', prev: 'Imagine de previzualizare', pub: 'Publică', busy: 'Se publică…', done: 'Exercițiul tău este acum în baza de exerciții.', updDone: 'Exercițiul tău a fost actualizat în baza de exerciții.', view: 'Vezi în baza de date', empty: 'Desenează mai întâi un exercițiu pe teren.', dbSame: 'Acest exercițiu provine din baza de exerciții. Modifică-l înainte să-l publici.', eTitle: 'Dă-i exercițiului un titlu (cel puțin 3 caractere).', login: 'Nu mai ești autentificat. Autentifică-te din nou pe FT4A.com și încearcă din nou.', member: 'Pentru a publica ai nevoie de un pachet online sau complet.', nonce: 'Sesiunea a expirat. Salvează exercițiul, reîncarcă pagina și încearcă din nou.', size: 'Acest exercițiu este prea mare pentru a fi publicat (maximum {n} MB).', fail: 'Publicarea nu a reușit. Verifică conexiunea la internet și încearcă din nou.', limit: 'Ai publicat deja multe exerciții în ultima oră. Încearcă mai târziu.', exists: 'Ai publicat deja acest exercițiu ca „{t}”. Vrei să-l actualizezi sau să publici un exercițiu nou?', upd: 'Actualizează', asNew: 'Ca exercițiu nou' },
    pl: { menu: 'Opublikuj na FT4A.com', head: 'Opublikuj ćwiczenie', intro: 'Twoje ćwiczenie trafi od razu do bazy ćwiczeń na FT4A.com, dla wszystkich członków.', title: 'Tytuł', cat: 'Kategoria', age: 'Wiek', desc: 'Opis', descPh: 'Organizacja, przebieg, wskazówki trenerskie…', prev: 'Obraz podglądu', pub: 'Opublikuj', busy: 'Publikowanie…', done: 'Twoje ćwiczenie jest już w bazie ćwiczeń.', updDone: 'Twoje ćwiczenie zostało zaktualizowane w bazie ćwiczeń.', view: 'Zobacz w bazie', empty: 'Najpierw narysuj ćwiczenie na boisku.', dbSame: 'To ćwiczenie pochodzi z bazy ćwiczeń. Zmień je przed opublikowaniem.', eTitle: 'Nadaj ćwiczeniu tytuł (co najmniej 3 znaki).', login: 'Nie jesteś już zalogowany. Zaloguj się ponownie na FT4A.com i spróbuj jeszcze raz.', member: 'Do publikowania potrzebny jest pakiet online lub kompletny.', nonce: 'Sesja wygasła. Zapisz ćwiczenie, odśwież stronę i spróbuj ponownie.', size: 'To ćwiczenie jest za duże, aby je opublikować (maksymalnie {n} MB).', fail: 'Publikowanie się nie powiodło. Sprawdź połączenie z internetem i spróbuj ponownie.', limit: 'W ciągu ostatniej godziny opublikowano już wiele ćwiczeń. Spróbuj później.', exists: 'To ćwiczenie zostało już opublikowane jako „{t}”. Zaktualizować je czy opublikować nowe ćwiczenie?', upd: 'Zaktualizuj', asNew: 'Jako nowe ćwiczenie' },
    tr: { menu: 'FT4A.com’da yayınla', head: 'Antrenmanı yayınla', intro: 'Antrenmanın hemen FT4A.com antrenman veritabanına, tüm üyeler için eklenir.', title: 'Başlık', cat: 'Kategori', age: 'Yaş', desc: 'Açıklama', descPh: 'Organizasyon, uygulama, koçluk noktaları…', prev: 'Önizleme görseli', pub: 'Yayınla', busy: 'Yayınlanıyor…', done: 'Antrenmanın artık antrenman veritabanında.', updDone: 'Antrenmanın antrenman veritabanında güncellendi.', view: 'Veritabanında görüntüle', empty: 'Önce sahaya bir antrenman çiz.', dbSame: 'Bu antrenman veritabanından geliyor. Yayınlamadan önce değiştir.', eTitle: 'Antrenmanına bir başlık ver (en az 3 karakter).', login: 'Artık oturumun açık değil. FT4A.com’da yeniden oturum aç ve tekrar dene.', member: 'Yayınlamak için çevrimiçi veya tam paket gerekir.', nonce: 'Oturumunun süresi doldu. Antrenmanını kaydet, sayfayı yenile ve tekrar dene.', size: 'Bu antrenman yayınlamak için çok büyük (en fazla {n} MB).', fail: 'Yayınlama başarısız oldu. İnternet bağlantını kontrol et ve tekrar dene.', limit: 'Son bir saatte zaten çok sayıda antrenman yayınladın. Daha sonra tekrar dene.', exists: 'Bu antrenmanı daha önce “{t}” olarak yayınladın. Güncellemek mi yoksa yeni bir antrenman yayınlamak mı istiyorsun?', upd: 'Güncelle', asNew: 'Yeni antrenman olarak' },
    ru: { menu: 'Опубликовать на FT4A.com', head: 'Опубликовать упражнение', intro: 'Ваше упражнение сразу попадёт в базу упражнений FT4A.com и станет доступно всем участникам.', title: 'Название', cat: 'Категория', age: 'Возраст', desc: 'Описание', descPh: 'Организация, ход упражнения, тренерские указания…', prev: 'Изображение для предпросмотра', pub: 'Опубликовать', busy: 'Публикация…', done: 'Ваше упражнение теперь в базе упражнений.', updDone: 'Ваше упражнение обновлено в базе упражнений.', view: 'Посмотреть в базе', empty: 'Сначала нарисуйте упражнение на поле.', dbSame: 'Это упражнение из базы упражнений. Измените его перед публикацией.', eTitle: 'Дайте упражнению название (не менее 3 символов).', login: 'Вы больше не авторизованы. Войдите снова на FT4A.com и повторите попытку.', member: 'Для публикации нужен онлайн- или полный пакет.', nonce: 'Сеанс истёк. Сохраните упражнение, перезагрузите страницу и повторите попытку.', size: 'Это упражнение слишком велико для публикации (максимум {n} МБ).', fail: 'Опубликовать не удалось. Проверьте подключение к интернету и повторите попытку.', limit: 'За последний час вы уже опубликовали много упражнений. Повторите попытку позже.', exists: 'Вы уже публиковали это упражнение под названием «{t}». Обновить его или опубликовать новое упражнение?', upd: 'Обновить', asNew: 'Как новое упражнение' },
    sv: { menu: 'Publicera på FT4A.com', head: 'Publicera övning', intro: 'Din övning hamnar direkt i övningsdatabasen på FT4A.com, för alla medlemmar.', title: 'Titel', cat: 'Kategori', age: 'Ålder', desc: 'Förklaring', descPh: 'Organisation, genomförande, coachningspunkter…', prev: 'Förhandsbild', pub: 'Publicera', busy: 'Publicerar…', done: 'Din övning finns nu i övningsdatabasen.', updDone: 'Din övning har uppdaterats i övningsdatabasen.', view: 'Visa i databasen', empty: 'Rita först en övning på planen.', dbSame: 'Den här övningen kommer från övningsdatabasen. Ändra den innan du publicerar den.', eTitle: 'Ge din övning en titel (minst 3 tecken).', login: 'Du är inte längre inloggad. Logga in igen på FT4A.com och försök igen.', member: 'För att publicera behöver du ett online- eller komplett paket.', nonce: 'Din session har gått ut. Spara övningen, ladda om sidan och försök igen.', size: 'Övningen är för stor för att publiceras (högst {n} MB).', fail: 'Det gick inte att publicera. Kontrollera internetanslutningen och försök igen.', limit: 'Du har redan publicerat många övningar den senaste timmen. Försök igen senare.', exists: 'Du har redan publicerat den här övningen som ”{t}”. Vill du uppdatera den eller publicera en ny övning?', upd: 'Uppdatera', asNew: 'Som ny övning' },
    da: { menu: 'Udgiv på FT4A.com', head: 'Udgiv øvelse', intro: 'Din øvelse kommer straks i øvelsesdatabasen på FT4A.com, for alle medlemmer.', title: 'Titel', cat: 'Kategori', age: 'Alder', desc: 'Forklaring', descPh: 'Organisering, forløb, coachingpunkter…', prev: 'Eksempelbillede', pub: 'Udgiv', busy: 'Udgiver…', done: 'Din øvelse er nu i øvelsesdatabasen.', updDone: 'Din øvelse er opdateret i øvelsesdatabasen.', view: 'Se i databasen', empty: 'Tegn først en øvelse på banen.', dbSame: 'Denne øvelse kommer fra øvelsesdatabasen. Ret den, før du udgiver den.', eTitle: 'Giv din øvelse en titel (mindst 3 tegn).', login: 'Du er ikke længere logget ind. Log ind igen på FT4A.com, og prøv igen.', member: 'For at udgive skal du have en online- eller komplet pakke.', nonce: 'Din session er udløbet. Gem øvelsen, genindlæs siden, og prøv igen.', size: 'Øvelsen er for stor til at blive udgivet (højst {n} MB).', fail: 'Udgivelsen lykkedes ikke. Kontrollér internetforbindelsen, og prøv igen.', limit: 'Du har allerede udgivet mange øvelser inden for den seneste time. Prøv igen senere.', exists: 'Du har allerede udgivet denne øvelse som “{t}”. Vil du opdatere den eller udgive en ny øvelse?', upd: 'Opdater', asNew: 'Som ny øvelse' },
    nb: { menu: 'Publiser på FT4A.com', head: 'Publiser øvelse', intro: 'Øvelsen din havner med en gang i øvelsesdatabasen på FT4A.com, for alle medlemmer.', title: 'Tittel', cat: 'Kategori', age: 'Alder', desc: 'Forklaring', descPh: 'Organisering, gjennomføring, coachingpunkter…', prev: 'Forhåndsbilde', pub: 'Publiser', busy: 'Publiserer …', done: 'Øvelsen din ligger nå i øvelsesdatabasen.', updDone: 'Øvelsen din er oppdatert i øvelsesdatabasen.', view: 'Se i databasen', empty: 'Tegn først en øvelse på banen.', dbSame: 'Denne øvelsen kommer fra øvelsesdatabasen. Endre den før du publiserer den.', eTitle: 'Gi øvelsen en tittel (minst 3 tegn).', login: 'Du er ikke lenger logget inn. Logg inn på nytt på FT4A.com og prøv igjen.', member: 'For å publisere trenger du en online- eller komplett pakke.', nonce: 'Økten din er utløpt. Lagre øvelsen, last inn siden på nytt og prøv igjen.', size: 'Øvelsen er for stor til å publiseres (maks {n} MB).', fail: 'Publiseringen lyktes ikke. Kontroller internettilkoblingen og prøv igjen.', limit: 'Du har allerede publisert mange øvelser den siste timen. Prøv igjen senere.', exists: 'Du har allerede publisert denne øvelsen som «{t}». Vil du oppdatere den eller publisere en ny øvelse?', upd: 'Oppdater', asNew: 'Som ny øvelse' },
    fi: { menu: 'Julkaise FT4A.comissa', head: 'Julkaise harjoite', intro: 'Harjoitteesi siirtyy heti FT4A.comin harjoitetietokantaan kaikkien jäsenten nähtäväksi.', title: 'Nimi', cat: 'Luokka', age: 'Ikä', desc: 'Kuvaus', descPh: 'Järjestelyt, kulku, valmennuspisteet…', prev: 'Esikatselukuva', pub: 'Julkaise', busy: 'Julkaistaan…', done: 'Harjoitteesi on nyt harjoitetietokannassa.', updDone: 'Harjoitteesi on päivitetty harjoitetietokantaan.', view: 'Näytä tietokannassa', empty: 'Piirrä ensin harjoite kentälle.', dbSame: 'Tämä harjoite on peräisin harjoitetietokannasta. Muokkaa sitä ennen julkaisemista.', eTitle: 'Anna harjoitteelle nimi (vähintään 3 merkkiä).', login: 'Et ole enää kirjautuneena. Kirjaudu uudelleen FT4A.comiin ja yritä uudelleen.', member: 'Julkaiseminen vaatii online- tai täyden paketin.', nonce: 'Istuntosi on vanhentunut. Tallenna harjoite, lataa sivu uudelleen ja yritä uudelleen.', size: 'Harjoite on liian suuri julkaistavaksi (enintään {n} Mt).', fail: 'Julkaiseminen epäonnistui. Tarkista internetyhteys ja yritä uudelleen.', limit: 'Olet julkaissut jo monta harjoitetta viimeisen tunnin aikana. Yritä myöhemmin uudelleen.', exists: 'Olet jo julkaissut tämän harjoitteen nimellä ”{t}”. Haluatko päivittää sen vai julkaista uuden harjoitteen?', upd: 'Päivitä', asNew: 'Uutena harjoitteena' },
    ar: { menu: 'النشر على FT4A.com', head: 'نشر التمرين', intro: 'يُضاف تمرينك فورًا إلى قاعدة التمارين على FT4A.com، ليراه جميع الأعضاء.', title: 'العنوان', cat: 'الفئة', age: 'العمر', desc: 'الشرح', descPh: 'التنظيم وطريقة التنفيذ ونقاط التوجيه…', prev: 'صورة المعاينة', pub: 'نشر', busy: 'جارٍ النشر…', done: 'تمرينك الآن في قاعدة التمارين.', updDone: 'تم تحديث تمرينك في قاعدة التمارين.', view: 'عرض في قاعدة التمارين', empty: 'ارسم تمرينًا على الملعب أولًا.', dbSame: 'هذا التمرين من قاعدة التمارين. عدّله قبل نشره.', eTitle: 'أعطِ تمرينك عنوانًا (3 أحرف على الأقل).', login: 'لم تعد مسجّلًا الدخول. سجّل الدخول مجددًا على FT4A.com وحاول مرة أخرى.', member: 'للنشر تحتاج إلى باقة إلكترونية أو كاملة.', nonce: 'انتهت جلستك. احفظ تمرينك وأعد تحميل الصفحة ثم حاول مرة أخرى.', size: 'هذا التمرين أكبر من أن يُنشر (الحد الأقصى {n} ميغابايت).', fail: 'لم ينجح النشر. تحقق من اتصالك بالإنترنت وحاول مرة أخرى.', limit: 'لقد نشرت بالفعل تمارين كثيرة خلال الساعة الماضية. حاول لاحقًا.', exists: 'لقد نشرت هذا التمرين من قبل باسم «{t}». هل تريد تحديثه أم نشر تمرين جديد؟', upd: 'تحديث', asNew: 'كتمرين جديد' }
  };
  var lg = function () { return (typeof LANG === 'string' && S[LANG]) ? LANG : (typeof LANG === 'string' && S[LANG.split('-')[0]] ? LANG.split('-')[0] : 'en'); };
  var L = function (k, p) { var v = S[lg()][k] || S.en[k] || k; if (p) for (var n in p) v = v.split('{' + n + '}').join(p[n]); return v; };
  var nm = function (o) { return (o.n && (o.n[lg()] || o.n.en)) || o.name || o.v; };
  var tt = function (k, d) { try { var v = t(k); return v && v !== k ? v : d; } catch (e) { return d; } };
  var h = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };

  /* voorstel categorie en leeftijd op de website vanuit de gegevens van de oefening */
  var CAT_MAP = { warmup: 'Opwarmingen', coordination: 'Opwarmingen', passing: 'Passvormen', control: 'Passvormen', finishing: 'Scoren', goalkeeping: 'Doelmannen', fitness: 'Conditie' };
  function suggestCat(m) {
    var k = typeof catKey === 'function' ? catKey(m.cat) : m.cat, young = /^O[6-9]$/.test(m.age || '');
    var want = young && k !== 'goalkeeping' ? 'U6 – U9' : (CAT_MAP[k] || 'Allerlei');
    var c = CFG.cats.filter(function (x) { return x.name === want; })[0] || CFG.cats.filter(function (x) { return x.name === 'Allerlei'; })[0] || CFG.cats[0];
    return c ? c.id : '';
  }
  function suggestAge(a) {
    var m = /^O(\d+)$/.exec(a || ''), n = m ? +m[1] : 0;
    if (n && n <= 9) return 'U6 – U9'; if (n && n <= 13) return 'U10 – U13'; if (n && n <= 17) return 'U14 – U17'; if (n) return 'U18 – U21';
    return a === 'Senioren' ? 'Senioren' : 'Alle leeftijden';
  }

  /* voorbeeldafbeelding zoals op de website (640 px breed, webp), zonder het opschrift van de proefversie */
  function thumb() {
    var keep = (typeof LIC !== 'undefined' && LIC) ? LIC.isTrial : null, s;
    try { if (keep) LIC.isTrial = function () { return false; }; s = exportSVGString(false, 'pub'); } finally { if (keep) LIC.isTrial = keep; }
    return new Promise(function (ok, no) {
      var img = new Image();
      img.onload = function () {
        var w = 640, k = w / (img.naturalWidth || 680), c = document.createElement('canvas');
        c.width = w; c.height = Math.round((img.naturalHeight || 560) * k);
        var g = c.getContext('2d'); g.drawImage(img, 0, 0, c.width, c.height);
        var u = c.toDataURL('image/webp', 0.85); if (u.indexOf('data:image/webp') !== 0) u = c.toDataURL('image/png');
        ok(u);
      };
      img.onerror = function () { no(new Error('image')); };
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s);
    });
  }
  function fileText() { return JSON.stringify(Object.assign({ app: 'FT4A.com' }, JSON.parse(snapshot())), null, 1); }

  /* knop in het menu Exporteren */
  var menu = document.getElementById('exportMenu'), item = document.createElement('button');
  item.type = 'button'; item.id = 'expPublish'; item.dataset.exp = 'publish';
  item.innerHTML = '<span class="pubLabel"></span> <small>FT4A.com</small>';
  menu.appendChild(item);
  var label = function () { item.querySelector('.pubLabel').textContent = L('menu'); };
  label();
  if (typeof setLang === 'function') { var _setLang = setLang; setLang = function () { var r = _setLang.apply(this, arguments); label(); return r; }; }

  /* venster */
  var st = document.createElement('style');
  st.textContent = '#pubDlg{max-width:560px}#pubDlg .pubIntro{margin:0 0 12px;color:var(--muted);line-height:1.45}#pubDlg .pubRow{display:flex;gap:10px}#pubDlg .pubRow .field{flex:1}'
    + '#pubDlg .pubPrev{display:block;max-width:100%;max-height:200px;margin:2px auto 0;border-radius:6px;border:1px solid var(--line);background:var(--panel2)}'
    + '#pubDlg .pubMsg{margin:10px 0 0;padding:9px 11px;border-radius:7px;line-height:1.45}#pubDlg .pubMsg.err{background:#FDECEA;color:#8A1C12}#pubDlg .pubMsg.ok{background:#E6F4EA;color:#1D5A2E}'
    + '#pubDlg .pubBtns{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;margin-top:14px}#pubDlg .pubBtns .btn{text-decoration:none}#pubDlg .pubBtns .btn[disabled]{opacity:.6;cursor:default}';
  document.head.appendChild(st);
  var dlg = document.createElement('dialog');
  dlg.id = 'pubDlg'; dlg.setAttribute('aria-labelledby', 'pubHead');
  document.body.appendChild(dlg);
  var busy = false, lastPrev = '';
  dlg.addEventListener('cancel', function (e) { if (busy) e.preventDefault(); });

  function msg(text, kind) { var p = dlg.querySelector('.pubMsg'); if (!p) return; p.hidden = !text; p.textContent = text || ''; p.className = 'pubMsg ' + (kind || 'err'); }
  function head() { return '<div class="dhead"><h2 id="pubHead">' + h(L('head')) + '</h2><button class="btn" type="button" data-pubclose>' + h(tt('close', 'Close')) + '</button></div>'; }

  function openDlg() {
    if (!doc.items || !doc.items.length) { if (typeof toast === 'function') toast(L('empty')); return; }
    try { if (typeof store !== 'undefined' && store.get('ft4a.dbSnap', '') === snapshot()) { if (typeof toast === 'function') toast(L('dbSame')); return; } } catch (e) {}
    var m = doc.meta || {}, newT = tt('doc.new', ''), title = doc.title && doc.title !== newT ? doc.title : '';
    var cats = CFG.cats.map(function (c) { return '<option value="' + c.id + '">' + h(nm(c)) + '</option>'; }).join('');
    var ages = CFG.ages.map(function (a) { return '<option value="' + h(a.v) + '">' + h(nm(a)) + '</option>'; }).join('');
    dlg.innerHTML = head() + '<div class="dbody"><p class="pubIntro">' + h(L('intro')) + '</p>'
      + '<label class="field"><span>' + h(L('title')) + '</span><input type="text" id="pubTitle" maxlength="120"></label>'
      + '<div class="pubRow"><label class="field"><span>' + h(L('cat')) + '</span><select id="pubCat">' + cats + '</select></label>'
      + '<label class="field"><span>' + h(L('age')) + '</span><select id="pubAge">' + ages + '</select></label></div>'
      + '<label class="field"><span>' + h(L('desc')) + '</span><textarea id="pubDesc" rows="5"></textarea></label>'
      + '<div class="field"><span>' + h(L('prev')) + '</span><img class="pubPrev" id="pubPrev" alt=""></div>'
      + '<p class="pubMsg" hidden></p>'
      + '<div class="pubBtns"><button class="btn" type="button" data-pubclose>' + h(tt('cancel', 'Cancel')) + '</button><button class="btn primary" type="button" id="pubGo">' + h(L('pub')) + '</button></div></div>';
    dlg.querySelector('#pubTitle').value = title;
    dlg.querySelector('#pubDesc').value = m.desc || '';
    dlg.querySelector('#pubDesc').placeholder = L('descPh');
    dlg.querySelector('#pubCat').value = String(suggestCat(m));
    dlg.querySelector('#pubAge').value = suggestAge(m.age);
    dlg.querySelector('#pubGo').onclick = function () { send(''); };
    lastPrev = '';
    thumb().then(function (u) { lastPrev = u; var im = dlg.querySelector('#pubPrev'); if (im) im.src = u; }).catch(function () {});
    dlg.showModal();
    if (!title) dlg.querySelector('#pubTitle').focus();
  }

  function setBusy(on) { busy = on; dlg.querySelectorAll('button').forEach(function (b) { b.disabled = on; }); var g = dlg.querySelector('#pubGo'); if (g) g.textContent = on ? L('busy') : L('pub'); }
  function post(fd) { return fetch(CFG.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }); }
  function newNonce() { return fetch(CFG.ajax + '?action=ft4a_pub_nonce&_=' + Date.now(), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) { if (j && j.ok && j.nonce) { CFG.nonce = j.nonce; return true; } return false; }); }

  function send(mode, retried) {
    if (busy) return;
    var title = dlg.querySelector('#pubTitle').value.trim();
    if (title.length < 3) { msg(L('eTitle')); dlg.querySelector('#pubTitle').focus(); return; }
    var body;
    try { body = fileText(); } catch (e) { msg(L('fail')); return; }
    if (body.length > CFG.max * 1048576) { msg(L('size', { n: CFG.max })); return; }
    msg(''); setBusy(true);
    (lastPrev ? Promise.resolve(lastPrev) : thumb().catch(function () { return ''; })).then(function (img) {
      var fd = new FormData();
      fd.append('action', 'ft4a_publish'); fd.append('_ft4a', CFG.nonce); fd.append('mode', mode || '');
      fd.append('titel', title); fd.append('beschrijving', dlg.querySelector('#pubDesc').value);
      fd.append('categorie', dlg.querySelector('#pubCat').value); fd.append('leeftijd', dlg.querySelector('#pubAge').value);
      fd.append('bestand', body); if (img) fd.append('afbeelding', img);
      return post(fd);
    }).then(function (r) {
      setBusy(false);
      if (r && r.ok) return done(r);
      var e = (r && r.error) || 'fail';
      if (e === 'nonce' && !retried) return newNonce().then(function (ok) { if (ok) send(mode, true); else msg(L('nonce')); }, function () { msg(L('nonce')); });
      if (e === 'exists') return askExists(r.title || title);
      msg(L({ login: 'login', member: 'member', nonce: 'nonce', size: 'size', limit: 'limit', title: 'eTitle' }[e] || 'fail', { n: CFG.max }));
    }, function () { setBusy(false); msg(L('fail')); });
  }

  function askExists(old) {
    msg(L('exists', { t: old }), 'ok');
    var b = dlg.querySelector('.pubBtns');
    b.innerHTML = '<button class="btn" type="button" data-pubclose>' + h(tt('cancel', 'Cancel')) + '</button>'
      + '<button class="btn" type="button" id="pubNew">' + h(L('asNew')) + '</button><button class="btn primary" type="button" id="pubUpd">' + h(L('upd')) + '</button>';
    dlg.querySelector('#pubNew').onclick = function () { send('new'); };
    dlg.querySelector('#pubUpd').onclick = function () { send('update'); };
  }

  function done(r) {
    dlg.innerHTML = head() + '<div class="dbody"><p class="pubMsg ok">' + h(L(r.updated ? 'updDone' : 'done')) + '</p>'
      + (lastPrev ? '<img class="pubPrev" alt="" src="' + h(lastPrev) + '" style="margin-top:12px">' : '')
      + '<div class="pubBtns"><button class="btn" type="button" data-pubclose>' + h(tt('close', 'Close')) + '</button>'
      + (r.list ? '<a class="btn primary" target="_blank" rel="noopener" href="' + h(r.list) + '">' + h(L('view')) + '</a>' : '') + '</div></div>';
  }

  dlg.addEventListener('click', function (e) { if (!busy && e.target.closest('[data-pubclose]')) dlg.close(); });
  menu.addEventListener('click', function (e) { if (e.target.closest('#expPublish')) { if (typeof toggleMenu === 'function') toggleMenu(null, null, false); openDlg(); } });
})();

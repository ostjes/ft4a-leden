<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:s="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" exclude-result-prefixes="s xhtml image">
<xsl:output method="html" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<html lang="nl">
<head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta name="robots" content="noindex, follow"/>
<title>Sitemap – FT4A.com</title>
<style>
:root{--bg:#3f4a43;--card:#4c5951;--line:rgba(255,255,255,.12);--fg:#f3f7f4;--muted:#b9c6be;--brand:#5fdc9c;--ink:#08311d}
*{box-sizing:border-box}html{background:var(--bg)}
body{margin:0;font:15px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--fg);background:radial-gradient(1200px 500px at 10% -10%,rgba(95,220,156,.14),transparent 60%),var(--bg);min-height:100vh}
.wrap{max-width:1180px;margin:0 auto;padding:48px 20px 72px}
.top{display:flex;align-items:center;gap:14px;margin-bottom:30px}
.logo{width:44px;height:44px;border-radius:50%;background:linear-gradient(140deg,#1f9d5c,#0e8a7a);display:grid;place-items:center;font-weight:800;color:#fff;font-size:20px;box-shadow:0 8px 20px rgba(0,0,0,.25)}
.top a{color:var(--fg);text-decoration:none;font-weight:700;font-size:18px}
.eyebrow{font:600 12px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.1em;text-transform:uppercase;color:#a7f3d0}
.eyebrow:before{content:"";display:inline-block;width:6px;height:6px;border-radius:50%;background:#ef4444;margin-right:8px;vertical-align:middle}
h1{font-size:clamp(30px,5vw,48px);line-height:1.05;letter-spacing:-.02em;margin:12px 0 10px}
.lead{color:var(--muted);max-width:720px;margin:0 0 28px}
.stats{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:28px}
.stat{padding:8px 16px;border-radius:999px;background:rgba(255,255,255,.06);border:1px solid var(--line);font-weight:600}
.stat b{color:#a7f3d0;margin-right:6px}
.card{background:var(--card);border:1px solid var(--line);border-radius:20px;overflow:hidden;box-shadow:0 20px 44px rgba(0,0,0,.25)}
table{width:100%;border-collapse:collapse}
th{text-align:left;font:600 12px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);padding:16px 18px;border-bottom:1px solid var(--line);background:rgba(0,0,0,.08)}
td{padding:12px 18px;border-bottom:1px solid var(--line);vertical-align:middle}
tr:last-child td{border-bottom:0}
tbody tr:hover{background:rgba(255,255,255,.04)}
td a{color:var(--fg);text-decoration:none;word-break:break-all}td a:hover{color:var(--brand)}
.pill{display:inline-block;padding:3px 10px;border-radius:999px;background:rgba(95,220,156,.14);color:#a7f3d0;font-size:12.5px;font-weight:600;white-space:nowrap}
.muted{color:var(--muted);white-space:nowrap}
.sec td{background:rgba(0,0,0,.12);font-weight:700;color:#a7f3d0;font-size:13px;letter-spacing:.02em}
.foot{margin-top:22px;color:var(--muted);font-size:13px}
.foot a{color:var(--brand)}
@media (max-width:640px){.hide-s{display:none}td,th{padding:10px 12px}}
</style>
</head>
<body><div class="wrap">
<div class="top"><span class="logo">4</span><a href="/">FT4A.com</a></div>
<xsl:choose>
<xsl:when test="s:sitemapindex">
  <span class="eyebrow">Sitemap</span>
  <h1>Overzicht van de sitemap</h1>
  <p class="lead">Deze sitemap helpt zoekmachines om alle pagina's van FT4A.com in alle talen te vinden. Ze wordt automatisch bijgewerkt.</p>
  <div class="stats"><span class="stat"><b><xsl:value-of select="count(s:sitemapindex/s:sitemap)"/></b>onderdelen</span></div>
  <div class="card"><table><thead><tr><th>Onderdeel</th><th>Laatst gewijzigd</th></tr></thead><tbody>
  <xsl:for-each select="s:sitemapindex/s:sitemap">
    <tr><td><a href="{s:loc}"><xsl:value-of select="s:loc"/></a></td><td class="muted"><xsl:value-of select="s:lastmod"/></td></tr>
  </xsl:for-each>
  </tbody></table></div>
</xsl:when>
<xsl:otherwise>
  <span class="eyebrow">Sitemap</span>
  <h1>Pagina's van FT4A.com</h1>
  <p class="lead">Alle pagina's die zoekmachines mogen tonen, met hun taalversies. De lijst wordt automatisch bijgewerkt wanneer er iets verandert.</p>
  <div class="stats">
    <span class="stat"><b><xsl:value-of select="count(s:urlset/s:url)"/></b>pagina's</span>
    <xsl:if test="s:urlset/s:url[1]/xhtml:link"><span class="stat"><b><xsl:value-of select="count(s:urlset/s:url[1]/xhtml:link[@hreflang!='x-default'])"/></b>talen</span></xsl:if>
  </div>
  <div class="card"><table><thead><tr><th>Pagina</th><th class="hide-s">Talen</th><th class="hide-s">Afbeelding</th><th>Gewijzigd</th></tr></thead><tbody>
  <xsl:for-each select="s:urlset/s:url">
    <tr><td><a href="{s:loc}"><xsl:value-of select="s:loc"/></a></td>
    <td class="hide-s"><xsl:if test="xhtml:link"><span class="pill"><xsl:value-of select="count(xhtml:link[@hreflang!='x-default'])"/> talen</span></xsl:if></td>
    <td class="hide-s muted"><xsl:if test="image:image">✓</xsl:if></td>
    <td class="muted"><xsl:value-of select="s:lastmod"/></td></tr>
  </xsl:for-each>
  </tbody></table></div>
  <p class="foot"><a href="/sitemap.xml">← Terug naar het overzicht</a></p>
</xsl:otherwise>
</xsl:choose>
</div></body></html>
</xsl:template>
</xsl:stylesheet>

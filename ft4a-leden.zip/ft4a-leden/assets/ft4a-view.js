/*
 * FT4A.com - viewer in de online software (alleen op ft4a.com/online/?view=1, in het venster op de ledenoefeningen-pagina).
 * Toont enkel het veld met de animatie en de gegevens van de oefening (titel, categorie, leeftijd, spelers, uitleg,
 * coachingspunten, variaties); geen werkbalken of panelen. Bewerken gebeurt in de gewone software (knop "Bewerken" in het venster).
 * De viewer verandert niets aan de software van het lid: geen vraag over niet-bewaarde wijzigingen en niets opslaan
 * (kladversie, bibliotheek blijven zoals ze waren). Zie ft4a_view_inject in ft4a-leden.php.
 */
(function () {
  'use strict';
  if (!window.FT4A_VIEW || typeof doc === 'undefined') return;
  var root = document.documentElement;
  root.classList.add('ft4a-view');
  /* niets vragen en niets bewaren */
  try { guardUnsaved = function () { return Promise.resolve(true); }; } catch (e) {}
  try { store.set = function () { return true; }; } catch (e) {}
  try { var sd = document.getElementById('startDlg'); if (sd && sd.open) sd.close(); } catch (e) {}

  var css = ''
    + 'html.ft4a-view body{overflow:hidden}'
    + 'html.ft4a-view .app{height:100vh;height:100dvh;min-height:0}'
    + 'html.ft4a-view .topbar,html.ft4a-view #palette,html.ft4a-view .inspector,html.ft4a-view .stagebar,html.ft4a-view .licBar,'
    + 'html.ft4a-view #animBadge,html.ft4a-view #toast,html.ft4a-view .timeline .switch,html.ft4a-view .timeline .sep,'
    + 'html.ft4a-view #tlSpeed,html.ft4a-view .timeline label.check{display:none!important}'
    + 'html.ft4a-view .workspace{display:flex!important;flex-direction:row;min-height:0}'
    + 'html.ft4a-view .stage{flex:1 1 auto;min-width:0;min-height:0;order:0}'
    + 'html.ft4a-view .canvasWrap{flex:1;height:auto;min-height:0;pointer-events:none;cursor:default}'
    + 'html.ft4a-view:not(.ft4a-ready) .canvasWrap,html.ft4a-view:not(.ft4a-ready) .timeline{visibility:hidden}'
    + 'html.ft4a-view.ft4a-static .timeline{display:none!important}'
    + '#ft4aInfo{flex:0 0 min(400px,40%);min-width:0;overflow:auto;padding:18px 20px 24px;border-inline-start:1px solid var(--line);background:var(--panel);color:var(--ink);font-size:14px;line-height:1.55}'
    + '#ft4aInfo h2{margin:0 0 10px;font-size:20px;line-height:1.25}'
    + '#ft4aInfo .chips{display:flex;flex-wrap:wrap;gap:6px;margin:0;padding:0}'
    + '#ft4aInfo .chips span{background:var(--panel2);border:1px solid var(--line);border-radius:999px;padding:2px 10px;font-size:12px}'
    + '#ft4aInfo h3{margin:18px 0 6px;font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:var(--muted)}'
    + '#ft4aInfo .txt{white-space:pre-line}'
    + '#ft4aInfo .ft4aLoad{color:var(--muted)}'
    + '@media (max-width:800px){html.ft4a-view .workspace{flex-direction:column}html.ft4a-view .stage{flex:none;height:55vh;height:55dvh}'
    + '#ft4aInfo{flex:1 1 auto;border-inline-start:0;border-top:1px solid var(--line)}}';
  var st = document.createElement('style');
  st.textContent = css;
  document.head.appendChild(st);

  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var tt = function (k, d) { try { var v = t(k); return v && v !== k ? v : d; } catch (e) { return d; } };
  var info = document.createElement('aside');
  info.id = 'ft4aInfo';
  info.innerHTML = '<p class="ft4aLoad">…</p>';
  var ws = document.querySelector('.workspace');
  if (ws) ws.appendChild(info);

  function optText(id, v) {
    var s = document.getElementById(id);
    if (!s || v == null || v === '') return '';
    for (var i = 0; i < s.options.length; i++) if (s.options[i].value === String(v)) return s.options[i].textContent;
    return '';
  }
  function show() {
    var m = doc.meta || {}, chips = [];
    var cat = '';
    try { cat = (typeof catLabel === 'function' && m.cat) ? catLabel(m.cat) : ''; } catch (e) {}
    if (!cat) cat = optText('exCat', m.cat);
    if (cat) chips.push(cat);
    var age = optText('exAge', m.age) || m.age;
    if (age) chips.push(age);
    if (m.players) chips.push(/^\d+$/.test(String(m.players)) ? tt('ex.players', '') + (tt('ex.players', '') ? ': ' : '') + m.players : m.players);
    if (m.minutes) chips.push(m.minutes + ' min');
    var sec = function (k, label) { return m[k] ? '<h3>' + esc(label) + '</h3><div class="txt">' + esc(m[k]) + '</div>' : ''; };
    info.innerHTML = '<h2>' + esc(doc.title || '') + '</h2>'
      + (chips.length ? '<p class="chips">' + chips.map(function (c) { return '<span>' + esc(c) + '</span>'; }).join('') + '</p>' : '')
      + sec('desc', tt('ex.desc', 'Description')) + sec('coach', tt('ex.coach', 'Coaching')) + sec('vari', tt('ex.vari', 'Variations'));
    var anim = false;
    try { anim = typeof maxKeyT === 'function' && maxKeyT(doc) > 0; } catch (e) {}
    root.classList.toggle('ft4a-static', !anim);
    root.classList.add('ft4a-ready');
    try { window.dispatchEvent(new Event('resize')); } catch (e) {}
    try { if (typeof render === 'function') render(); } catch (e) {}
    if (anim) {
      var lp = document.getElementById('tlLoop');
      if (lp) lp.checked = true;
      try { if (typeof play === 'function') play(); } catch (e) {}
    }
  }
  window.ft4aOpened = show;
})();

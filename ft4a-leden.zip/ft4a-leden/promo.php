<?php
/* ---------- Promotiemail (3.6.74; oud-leden van ft4a.com sinds 3.6.77; bounces sinds 3.6.78) ----------
   FT4A → Promotiemail: adressen importeren (CSV), testmail sturen en de verzending starten of pauzeren.
   Zolang de verzending aan staat, vertrekt elke 15 minuten een pakje van 5 mails (instelbaar), in de taal van de
   ontvanger en in de FT4A-opmaak, vanaf info@ft4a.com. Onderaan elke mail staat een afmeldlink; de mail heeft ook een
   List-Unsubscribe-kop (afmelden met één klik in Gmail, Outlook …). Wie zich afmeldt, krijgt nooit meer iets.
   Twee soorten ontvangers, elk met hun eigen teksten (per taal bewerkbaar onder FT4A → Promotiemail-teksten):
   - 'ft4all':   oude accounts van footballtraining4all.com (geïmporteerd); wie al een account op ft4a.com heeft, wordt overgeslagen.
   - 'verlopen': leden van ft4a.com van wie het pakket (of de proefperiode) minstens 30 dagen afgelopen is; elke dag
                 automatisch in de wachtrij gezet. Wie intussen weer een pakket heeft, wordt overgeslagen.
   De verzending staat standaard uit: niets vertrekt voordat iemand in het beheer op Start klikt. */
if (!defined('ABSPATH')) exit;

const FT4A_PROMO_DB = 'v2';
const FT4A_PROMO_DAGEN = 30;
const FT4A_PROMO_STATUS = [
	'wachtrij'     => 'In de wachtrij',
	'verzonden'    => 'Verstuurd',
	'afgemeld'     => 'Afgemeld',
	'mislukt'      => 'Mislukt',
	'overgeslagen' => 'Overgeslagen',
	'bounce'       => 'Bounce (verwijderd)',
];
const FT4A_PROMO_SOORTEN = [
	'ft4all'   => ['Promotiemail (oude accounts footballtraining4all.com)', 'oude site', 'promo.json', 'ft4a_promo_teksten'],
	'verlopen' => ['Oud-leden van ft4a.com (' . FT4A_PROMO_DAGEN . ' dagen na het einde van hun pakket)', 'oud-lid', 'promo-verlopen.json', 'ft4a_promo_teksten_verlopen'],
];

function ft4a_promo_table() { global $wpdb; return $wpdb->prefix . 'ft4a_promo'; }
function ft4a_promo_aantal() { return max(1, min(50, (int) get_option('ft4a_promo_aantal', 5))); }
function ft4a_promo_minuten() { return max(5, min(1440, (int) get_option('ft4a_promo_minuten', 15))); }
function ft4a_promo_soort($s) { return isset(FT4A_PROMO_SOORTEN[$s]) ? $s : 'ft4all'; }

/* Tabel met de adressen (aanmaken en bijwerken) */
function ft4a_promo_install() {
	if (get_option('ft4a_promo_db') === FT4A_PROMO_DB) return;
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$t = ft4a_promo_table();
	dbDelta("CREATE TABLE $t (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  email varchar(190) NOT NULL,
  voornaam varchar(100) NOT NULL DEFAULT '',
  achternaam varchar(100) NOT NULL DEFAULT '',
  land varchar(100) NOT NULL DEFAULT '',
  taal varchar(8) NOT NULL DEFAULT 'en',
  status varchar(20) NOT NULL DEFAULT 'wachtrij',
  soort varchar(20) NOT NULL DEFAULT 'ft4all',
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  token char(32) NOT NULL,
  toegevoegd datetime DEFAULT NULL,
  verzonden datetime DEFAULT NULL,
  afgemeld datetime DEFAULT NULL,
  fout varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY  (id),
  UNIQUE KEY email (email),
  UNIQUE KEY token (token),
  KEY status (status),
  KEY soort (soort)
) " . $wpdb->get_charset_collate() . ';');
	if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) !== $t) return;
	if (!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $t LIKE %s", 'soort'))) return;
	add_option('ft4a_promo_aan', 0);
	update_option('ft4a_promo_db', FT4A_PROMO_DB);
}
add_action('admin_init', 'ft4a_promo_install', 5);

/* Taal van een ontvanger: FT4A-code (nl, fr …), code van footballtraining4all.com (nl-NL, se-FI …) of de naam uit de ledenlijst (Nederlands, Frans …) */
function ft4a_promo_lang($v) {
	$v = trim((string) $v);
	$v = function_exists('mb_strtolower') ? mb_strtolower($v, 'UTF-8') : strtolower($v);
	$v = str_replace('_', '-', $v);
	if ($v === '') return 'en';
	if (isset(FT4A_LANGS[$v])) return $v;
	$oud = ['nl-nl' => 'nl', 'nl-be' => 'nl', 'en-gb' => 'en', 'fr-fr' => 'fr', 'fr-be' => 'fr', 'de-de' => 'de', 'es-es' => 'es', 'it-it' => 'it', 'pt-pt' => 'pt', 'da-dk' => 'da', 'sv-se' => 'sv', 'se-fi' => 'fi', 'fi-fi' => 'fi', 'smj-no' => 'no', 'nb-no' => 'no', 'nn-no' => 'no', 'nb' => 'no', 'nn' => 'no', 'pl-pl' => 'pl', 'tr-tr' => 'tr', 'ru-ru' => 'ru', 'ro-ro' => 'ro'];
	if (isset($oud[$v])) return $oud[$v];
	$namen = ['nederlands' => 'nl', 'engels' => 'en', 'engels (vs)' => 'en-us', 'frans' => 'fr', 'duits' => 'de', 'spaans' => 'es', 'italiaans' => 'it', 'portugees' => 'pt', 'portugees (brazilië)' => 'pt-br', 'deens' => 'da', 'zweeds' => 'sv', 'fins' => 'fi', 'noors' => 'no', 'pools' => 'pl', 'turks' => 'tr', 'russisch' => 'ru', 'roemeens' => 'ro', 'arabisch' => 'ar'];
	if (isset($namen[$v])) return $namen[$v];
	if (strpos($v, 'ar-') === 0) return 'ar';
	$s = substr($v, 0, 2);
	return isset(FT4A_LANGS[$s]) ? $s : 'en';
}

/* Voornaam netjes: "jan" of "JAN" wordt "Jan" */
function ft4a_promo_naam($s) {
	$s = trim((string) preg_replace('/\s+/u', ' ', (string) $s));
	if ($s === '' || !function_exists('mb_convert_case')) return $s;
	$lo = mb_strtolower($s, 'UTF-8');
	if ($s === $lo || $s === mb_strtoupper($s, 'UTF-8')) $s = mb_convert_case($lo, MB_CASE_TITLE, 'UTF-8');
	return $s;
}

function ft4a_promo_set($id, $status, $fout = '') {
	global $wpdb;
	$d = ['status' => $status, 'fout' => mb_substr((string) $fout, 0, 250)];
	if ($status === 'verzonden') $d['verzonden'] = current_time('mysql');
	if ($status === 'afgemeld') $d['afgemeld'] = current_time('mysql');
	$wpdb->update(ft4a_promo_table(), $d, ['id' => (int) $id]);
}

/* ---------- Teksten: één bericht per taal en per soort, bewerkbaar in WordPress (titel = onderwerp) ---------- */
add_action('init', function () {
	register_post_type('ft4a_promomail', [
		'labels' => ['name' => 'Promotiemail-teksten', 'singular_name' => 'Promotiemail-tekst', 'menu_name' => 'Promotiemail-teksten', 'all_items' => 'Promotiemail-teksten', 'edit_item' => 'Promotiemail-tekst bewerken', 'add_new_item' => 'Nieuwe promotiemail-tekst', 'add_new' => 'Nieuwe tekst', 'search_items' => 'Teksten zoeken', 'not_found' => 'Geen teksten gevonden'],
		'public' => false, 'show_ui' => true, 'show_in_menu' => false, 'show_in_rest' => false, 'show_in_admin_bar' => false,
		'supports' => ['title', 'editor', 'revisions'], 'capability_type' => 'page', 'map_meta_cap' => true, 'rewrite' => false, 'query_var' => false,
	]);
});
function ft4a_promo_soort_van($id) { return ft4a_promo_soort((string) get_post_meta($id, '_ft4a_soort', true)); }
add_filter('manage_ft4a_promomail_posts_columns', function ($c) {
	return ['cb' => $c['cb'] ?? '', 'title' => 'Onderwerp', 'ft4a_taal' => 'Taal', 'ft4a_soort' => 'Voor', 'date' => $c['date'] ?? 'Datum'];
});
add_action('manage_ft4a_promomail_posts_custom_column', function ($col, $id) {
	if ($col === 'ft4a_taal') { $l = (string) get_post_meta($id, '_ft4a_lang', true); echo esc_html(FT4A_LANGS[$l][3] ?? $l); }
	if ($col === 'ft4a_soort') echo esc_html(ft4a_promo_soort_van($id) === 'verlopen' ? 'Oud-leden ft4a.com' : 'Oude accounts footballtraining4all.com');
}, 10, 2);
add_action('pre_get_posts', function ($q) {
	if (is_admin() && $q->is_main_query() && $q->get('post_type') === 'ft4a_promomail' && !$q->get('orderby')) { $q->set('orderby', 'menu_order'); $q->set('order', 'ASC'); }
});
add_action('add_meta_boxes_ft4a_promomail', function () {
	add_meta_box('ft4a_promo_uitleg', 'Taal en uitleg', function ($post) {
		$l = (string) get_post_meta($post->ID, '_ft4a_lang', true);
		$verlopen = ft4a_promo_soort_van($post->ID) === 'verlopen';
		echo '<p><strong>Taal:</strong> ' . esc_html(FT4A_LANGS[$l][3] ?? '—') . '<br><strong>Voor:</strong> ' . ($verlopen ? 'oud-leden van ft4a.com, ' . FT4A_PROMO_DAGEN . ' dagen na het einde van hun pakket' : 'oude accounts van footballtraining4all.com') . '</p>'
			. '<p>De titel is het onderwerp van de mail. In de tekst wordt <code>{voornaam}</code> de voornaam van de ontvanger en wordt <code>{knop}</code> (op een eigen regel) de groene knop ' . ($verlopen ? '<strong>Pakket kiezen</strong> naar de prijzen' : 'naar FT4A.com') . ', in de taal van de ontvanger.</p>'
			. '<p>Onderaan komt automatisch waarom iemand de mail krijgt en de afmeldlink. Zonder (gepubliceerde) tekst in een taal gaat de Engelse tekst.</p>'
			. '<p><a href="' . esc_url(admin_url('admin.php?page=ft4a-promo')) . '">← Terug naar Promotiemail</a></p>';
	}, null, 'side', 'high');
});
add_action('admin_menu', function () {
	add_submenu_page('ft4a', 'Promotiemail', 'Promotiemail', 'manage_options', 'ft4a-promo', 'ft4a_promo_page');
	add_submenu_page('ft4a', 'Promotiemail-teksten', 'Promotiemail-teksten', 'manage_options', 'edit.php?post_type=ft4a_promomail');
}, 24);
add_filter('parent_file', function ($p) {
	$s = function_exists('get_current_screen') ? get_current_screen() : null;
	return ($s && $s->post_type === 'ft4a_promomail') ? 'ft4a' : $p;
});

/* Teksten uit site/promo.json en site/promo-verlopen.json als berichten aanmaken, en bijwerken als de plugin een nieuwe
   versie van de tekst heeft. Een tekst die in WordPress aangepast is, wordt nooit overschreven (vingerafdruk van de inhoud). */
const FT4A_PROMO_TEKSTEN = 'v3'; // promo.json – 3.6.75: tekenprogramma en animatiemodule + uitleg met tekst en animatie; 3.6.76: (nieuw) bij tekst
const FT4A_PROMO_TEKSTEN_VERLOPEN = 'v1'; // promo-verlopen.json – 3.6.77
// vingerafdrukken van de eerste versie van promo.json (3.6.74): zo herkennen we teksten die niemand aanpaste
const FT4A_PROMO_V1 = ['nl' => 'e086028edbc9da241aac77a3d9ab4827', 'en' => '908078df23e1963beb4c83b988bdf274', 'en-us' => '8e43da00a30dcee0bfbc98ade16ad149', 'fr' => '65c3f40605e34859d566952fb06f82bd', 'de' => 'e3a7a0a8eb449e6da0f99d88d1e903cb', 'es' => 'e82d64aba79314ea54a047c37e403f31', 'it' => '6daa5265809f8f4c68729adb1c563710', 'pt' => '77a4628980a47aff725a00e98daf2d24', 'pt-br' => '96e4b97e09016a80a716135a9519cd2f', 'da' => '67350e656c089840b6068b04d30868a4', 'sv' => '30d4a7323091beff02e5166a9ae6a8c8', 'fi' => 'fcc883d7af5fd5548b79a7c7eafa10ae', 'no' => '0a00f61775df526d500161e811eb2fa1', 'pl' => '6884ad773f0606779c16d32302d283b8', 'tr' => '00f36b3bc7b9a45cae14c31961489e44', 'ru' => 'efc66405224ee6e9183b78464e1a29e7', 'ro' => '1d83221cd09bdbf32211d7efe19a9776', 'ar' => 'b9ec2faec1f78e6004c8aaa653f35495'];
function ft4a_promo_vinger($s) { return md5(trim((string) preg_replace('/\s+/u', ' ', str_replace("\r", '', (string) $s)))); }
function ft4a_promo_seed_set($soort, $versie, $v1 = []) {
	$optie = FT4A_PROMO_SOORTEN[$soort][3];
	if (get_option($optie) === $versie) return;
	$def = json_decode((string) @file_get_contents(FT4A_DIR . 'site/' . FT4A_PROMO_SOORTEN[$soort][2]), true);
	if (!is_array($def)) return;
	$have = [];
	foreach (get_posts(['post_type' => 'ft4a_promomail', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC', 'suppress_filters' => true]) as $id) {
		if (ft4a_promo_soort_van($id) !== $soort) continue;
		$l = (string) get_post_meta($id, '_ft4a_lang', true);
		if (!isset($have[$l])) $have[$l] = $id;
	}
	$eigen = [];
	$i = $soort === 'ft4all' ? 0 : 100;
	foreach (FT4A_LANGS as $code => $l) {
		$i++;
		if (empty($def[$code]['onderwerp']) || empty($def[$code]['tekst'])) continue;
		$nieuw = $def[$code]['tekst'];
		$id = $have[$code] ?? 0;
		if (!$id) {
			$id = wp_insert_post(wp_slash(['post_type' => 'ft4a_promomail', 'post_status' => 'publish', 'post_title' => $def[$code]['onderwerp'], 'post_content' => $nieuw, 'menu_order' => $i]));
			if ($id && !is_wp_error($id)) {
				update_post_meta($id, '_ft4a_lang', $code);
				if ($soort !== 'ft4all') update_post_meta($id, '_ft4a_soort', $soort);
				update_post_meta($id, '_ft4a_hash', ft4a_promo_vinger(get_post_field('post_content', $id, 'raw')));
			}
			continue;
		}
		$nu = ft4a_promo_vinger(get_post_field('post_content', $id, 'raw'));
		if ($nu === ft4a_promo_vinger($nieuw)) { update_post_meta($id, '_ft4a_hash', $nu); continue; }
		$bekend = array_filter([(string) get_post_meta($id, '_ft4a_hash', true), $v1[$code] ?? '']);
		if (in_array($nu, $bekend, true)) {
			$ok = wp_update_post(wp_slash(['ID' => $id, 'post_content' => $nieuw]), true);
			if ($ok && !is_wp_error($ok)) update_post_meta($id, '_ft4a_hash', ft4a_promo_vinger(get_post_field('post_content', $id, 'raw')));
		} else {
			$eigen[] = FT4A_LANGS[$code][3];
		}
	}
	update_option($soort === 'ft4all' ? 'ft4a_promo_eigen' : 'ft4a_promo_eigen_' . $soort, $eigen, false);
	update_option($optie, $versie);
}
function ft4a_promo_seed_texts() {
	if (wp_doing_ajax() || !current_user_can('manage_options')) return;
	ft4a_promo_seed_set('ft4all', FT4A_PROMO_TEKSTEN, FT4A_PROMO_V1);
	ft4a_promo_seed_set('verlopen', FT4A_PROMO_TEKSTEN_VERLOPEN);
}
add_action('admin_init', 'ft4a_promo_seed_texts', 20);

function ft4a_promo_post($lang, $soort = 'ft4all') {
	$mq = [['key' => '_ft4a_lang', 'value' => $lang]];
	$mq[] = $soort === 'ft4all'
		? ['relation' => 'OR', ['key' => '_ft4a_soort', 'compare' => 'NOT EXISTS'], ['key' => '_ft4a_soort', 'value' => 'ft4all']]
		: ['key' => '_ft4a_soort', 'value' => $soort];
	$ids = get_posts(['post_type' => 'ft4a_promomail', 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'meta_query' => $mq, 'orderby' => 'ID', 'order' => 'ASC', 'suppress_filters' => true]);
	return $ids ? get_post($ids[0]) : null;
}
/* Tekst voor een taal en soort; zonder gepubliceerde tekst: Engels */
function ft4a_promo_text($lang, $soort = 'ft4all') {
	static $c = [];
	$soort = ft4a_promo_soort($soort);
	$k = $soort . '|' . $lang;
	if (array_key_exists($k, $c)) return $c[$k];
	$p = ft4a_promo_post($lang, $soort);
	if ($p && trim($p->post_title) !== '' && trim(wp_strip_all_tags($p->post_content)) !== '') return $c[$k] = ['lang' => $lang, 'onderwerp' => $p->post_title, 'tekst' => $p->post_content];
	return $c[$k] = ($lang === 'en' ? null : ft4a_promo_text('en', $soort));
}

/* ---------- Eén promotiemail versturen (in de taal van de ontvanger, FT4A-opmaak via WooCommerce) ---------- */
function ft4a_promo_mail($row, $to = '') {
	if (!function_exists('WC')) return new WP_Error('wc', 'WooCommerce is niet actief.');
	$soort = ft4a_promo_soort($row->soort ?? 'ft4all');
	$tx = ft4a_promo_text(ft4a_promo_lang($row->taal), $soort);
	if (!$tx) return new WP_Error('tekst', 'Er is geen tekst voor deze taal en ook geen Engelse tekst.');
	$lang = isset(FT4A_LANGS[$tx['lang']]) ? $tx['lang'] : 'en';
	$GLOBALS['ft4a_lang_stack'][] = $lang;
	$sw = switch_to_locale(FT4A_LANGS[$lang][1]);
	$err = '';
	$vang = function ($e) use (&$err) { if (is_wp_error($e)) $err = $e->get_error_message(); };
	add_action('wp_mail_failed', $vang);
	try {
		$afmeld = add_query_arg('ft4a_afmelden', $row->token, home_url('/'));
		$first = ft4a_promo_naam($row->voornaam ?? '');
		$tekst = str_replace(["\r\n", "\r"], "\n", (string) $tx['tekst']);
		$tekst = $first !== '' ? str_replace('{voornaam}', esc_html($first), $tekst) : preg_replace('/,?[ \t]*\{voornaam\}/u', '', $tekst);
		$verlopen = $soort === 'verlopen';
		$knop = '<a class="ft4a-btn" href="' . esc_url($verlopen ? ft4a_url('prijzen', $lang) : ft4a_url('home', $lang)) . '" style="display:inline-block;background-color:#16924f;color:#ffffff;text-decoration:none;font-weight:700;font-size:15px;line-height:1;padding:15px 26px;border-radius:12px">' . esc_html($verlopen ? ft4a_t('Pakket kiezen') : ft4a_t('Ontdek FT4A.com')) . '</a>';
		$tekst = str_replace('{knop}', $knop, $tekst);
		$waarom = $verlopen ? ft4a_t('Je krijgt deze e-mail omdat je een account hebt op FT4A.com.') : ft4a_t('Je krijgt deze e-mail omdat je een account had op footballtraining4all.com, de vorige website van FT4A.');
		$tekst = rtrim($tekst) . "\n\n" . '<p style="font-size:12px;line-height:1.6;color:#6b7a72;margin:28px 0 0;padding-top:14px;border-top:1px solid #e4ece7">'
			. esc_html($waarom) . ' '
			. esc_html(ft4a_t('Geen e-mails meer ontvangen?')) . ' <a href="' . esc_url($afmeld) . '" style="color:#6b7a72;text-decoration:underline">' . esc_html(ft4a_t('Afmelden')) . '</a></p>';
		/* Arabisch altijd van rechts naar links, ook als het taalpakket van WordPress ontbreekt */
		if ($lang === 'ar') $tekst = '<div dir="rtl" style="direction:rtl;text-align:right">' . "\n\n" . $tekst . "\n\n</div>";
		$onderwerp = trim(wp_strip_all_tags($tx['onderwerp']));
		$headers = "Content-Type: text/html; charset=UTF-8\r\n"
			. 'List-Unsubscribe: <' . esc_url_raw($afmeld) . '>, <mailto:' . FT4A_MAIL_FROM . "?subject=Afmelden>\r\n"
			. "List-Unsubscribe-Post: List-Unsubscribe=One-Click\r\n";
		$mailer = WC()->mailer();
		$ok = (bool) $mailer->send($to ?: $row->email, $onderwerp, $mailer->wrap_message($onderwerp, $tekst), $headers);
	} catch (\Throwable $e) { $ok = false; $err = $e->getMessage(); }
	remove_action('wp_mail_failed', $vang);
	if ($sw) restore_previous_locale();
	array_pop($GLOBALS['ft4a_lang_stack']);
	return $ok ? true : new WP_Error('mail', $err ?: 'De mail kon niet verstuurd worden.');
}

/* ---------- Pakjes versturen via WP-Cron ---------- */
add_filter('cron_schedules', function ($s) {
	$m = ft4a_promo_minuten();
	$s['ft4a_promo'] = ['interval' => $m * MINUTE_IN_SECONDS, 'display' => 'FT4A promotiemail (elke ' . $m . ' minuten)'];
	return $s;
});
add_action('ft4a_promo_tick', 'ft4a_promo_run');
add_action('init', function () {
	if (get_option('ft4a_promo_aan') && !wp_next_scheduled('ft4a_promo_tick')) wp_schedule_event(time() + MINUTE_IN_SECONDS, 'ft4a_promo', 'ft4a_promo_tick');
}, 31);

function ft4a_promo_start() {
	update_option('ft4a_promo_aan', 1);
	delete_option('ft4a_promo_melding');
	wp_clear_scheduled_hook('ft4a_promo_tick');
	wp_schedule_event(time() + MINUTE_IN_SECONDS, 'ft4a_promo', 'ft4a_promo_tick');
}
function ft4a_promo_stop($melding = '') {
	update_option('ft4a_promo_aan', 0);
	wp_clear_scheduled_hook('ft4a_promo_tick');
	if ($melding !== '') update_option('ft4a_promo_melding', ['at' => time(), 'tekst' => $melding], false);
}
function ft4a_promo_heeft_pakket($uid) { return max(ft4a_until($uid, '_ft4a_db_tot'), ft4a_until($uid, '_ft4a_offline_tot')) > time(); }

/* Ontvangt het domein van een adres nog e-mail? (MX-, A- of AAAA-record). Werkt DNS zelf niet (gmail.com faalt), dan geen controle. */
function ft4a_promo_dns_werkt() {
	static $ok = null;
	if ($ok === null) $ok = function_exists('checkdnsrr') && checkdnsrr('gmail.com.', 'MX');
	return $ok;
}
function ft4a_promo_domein_ok($dom) {
	static $c = [];
	if (isset($c[$dom])) return $c[$dom];
	if (!preg_match('/^[a-z0-9.-]+\.[a-z0-9-]{2,}$/i', $dom)) return $c[$dom] = false;
	return $c[$dom] = (checkdnsrr($dom . '.', 'MX') || checkdnsrr($dom . '.', 'A') || checkdnsrr($dom . '.', 'AAAA'));
}

function ft4a_promo_run() {
	global $wpdb;
	if (!get_option('ft4a_promo_aan')) { wp_clear_scheduled_hook('ft4a_promo_tick'); return 0; }
	if (!function_exists('WC')) return 0;
	if (get_transient('ft4a_promo_lock')) return -1;
	set_transient('ft4a_promo_lock', 1, 5 * MINUTE_IN_SECONDS);
	$t = ft4a_promo_table();
	$n = ft4a_promo_aantal();
	$sent = 0; $fail = 0; $fout = '';
	/* oud-leden van ft4a.com eerst (hun mail hoort kort na de 30 dagen te vertrekken), daarna de rest in volgorde van import */
	$rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE status = %s ORDER BY CASE WHEN soort = 'verlopen' THEN 0 ELSE 1 END, id ASC LIMIT %d", 'wachtrij', $n * 4));
	$dns = ft4a_promo_dns_werkt();
	foreach ((array) $rows as $r) {
		if ($sent + $fail >= $n) break;
		if (!is_email($r->email)) { ft4a_promo_set($r->id, 'mislukt', 'Ongeldig e-mailadres'); continue; }
		$dom = strtolower((string) substr((string) strrchr($r->email, '@'), 1));
		if ($dns && $dom !== '' && !ft4a_promo_domein_ok($dom)) { ft4a_promo_set($r->id, 'bounce', 'Het domein ' . $dom . ' bestaat niet (meer) of ontvangt geen e-mail'); continue; }
		if (ft4a_promo_soort($r->soort ?? '') === 'verlopen') {
			$uid = (int) $r->user_id ?: (int) email_exists($r->email);
			if (!$uid || !get_userdata($uid)) { ft4a_promo_set($r->id, 'overgeslagen', 'Account bestaat niet meer'); continue; }
			if (ft4a_promo_heeft_pakket($uid)) { ft4a_promo_set($r->id, 'overgeslagen', 'Heeft weer een pakket'); continue; }
		} elseif (email_exists($r->email)) { ft4a_promo_set($r->id, 'overgeslagen', 'Heeft een account op ft4a.com'); continue; }
		$res = ft4a_promo_mail($r);
		if ($res === true) { ft4a_promo_set($r->id, 'verzonden'); $sent++; }
		else { $fout = $res->get_error_message(); ft4a_promo_set($r->id, 'mislukt', $fout); $fail++; }
	}
	$left = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE status = %s", 'wachtrij'));
	update_option('ft4a_promo_laatst', ['at' => time(), 'sent' => $sent, 'fail' => $fail], false);
	if ($fail && !$sent && $fail >= min(3, $n)) {
		ft4a_promo_stop('Automatisch gepauzeerd: ' . $fail . ' mails na elkaar mislukt (' . $fout . '). Los het probleem op, zet de mislukte adressen opnieuw in de wachtrij en start opnieuw.');
	} elseif (!$left && get_option('ft4a_promo_campagne')) {
		/* een geïmporteerde lijst is volledig verstuurd; de verzending blijft aan voor oud-leden die later in de wachtrij komen */
		delete_option('ft4a_promo_campagne');
		update_option('ft4a_promo_melding', ['at' => time(), 'tekst' => 'Klaar: alle geïmporteerde adressen hebben de promotiemail gekregen. De verzending blijft aan, zodat oud-leden van ft4a.com hun mail vanzelf krijgen.'], false);
		wp_mail(FT4A_MAIL_TO, 'FT4A: promotiemail volledig verstuurd', "De promotiemail is naar alle geïmporteerde adressen verstuurd.\n\nOverzicht: " . admin_url('admin.php?page=ft4a-promo'));
	}
	delete_transient('ft4a_promo_lock');
	return $sent;
}

/* ---------- Oud-leden van ft4a.com: elke dag wie minstens 30 dagen geen pakket meer heeft in de wachtrij zetten ---------- */
add_action('init', function () {
	if (!wp_next_scheduled('ft4a_promo_verlopen')) {
		$t = new DateTime('tomorrow 09:23', wp_timezone());
		wp_schedule_event($t->getTimestamp(), 'daily', 'ft4a_promo_verlopen');
	}
}, 32);
add_action('ft4a_promo_verlopen', 'ft4a_promo_verlopen_run');
function ft4a_promo_verlopen_run() {
	if (!get_option('ft4a_promo_verlopen', 1) || !function_exists('ft4a_reminder_users')) return 0;
	global $wpdb;
	ft4a_promo_install();
	if (get_option('ft4a_promo_db') !== FT4A_PROMO_DB) return 0;
	$t = ft4a_promo_table();
	$grens = time() - FT4A_PROMO_DAGEN * DAY_IN_SECONDS;
	$trial = (bool) get_option('ft4a_promo_verlopen_trial', 1);
	$n = 0;
	foreach (ft4a_reminder_users() as $id) {
		$u = get_userdata($id);
		if (!$u || user_can($u, 'edit_posts') || !is_email($u->user_email)) continue;
		$end = max(ft4a_until($id, '_ft4a_db_tot'), ft4a_until($id, '_ft4a_offline_tot'));
		if (!$end || $end > $grens) continue; // heeft nog een pakket, of het einde is minder dan 30 dagen geleden
		if ((int) get_user_meta($id, '_ft4a_promo_na', true) === $end) continue; // voor deze einddatum al gedaan
		if (!$trial && get_user_meta($id, '_ft4a_pakket', true) === 'TRIAL') continue;
		$row = $wpdb->get_row($wpdb->prepare("SELECT id, status FROM $t WHERE email = %s", $u->user_email));
		if ($row && $row->status === 'afgemeld') { update_user_meta($id, '_ft4a_promo_na', $end); continue; }
		$d = [
			'voornaam'   => mb_substr((string) $u->first_name, 0, 100),
			'achternaam' => mb_substr((string) $u->last_name, 0, 100),
			'land'       => mb_substr((string) (get_user_meta($id, 'billing_country', true) ?: get_user_meta($id, '_ft4a_land', true)), 0, 100),
			'taal'       => ft4a_guess_lang($u),
			'status'     => 'wachtrij',
			'soort'      => 'verlopen',
			'user_id'    => (int) $id,
			'fout'       => '',
		];
		if ($row) $wpdb->update($t, $d, ['id' => (int) $row->id]);
		else $wpdb->insert($t, $d + ['email' => $u->user_email, 'token' => bin2hex(random_bytes(16)), 'toegevoegd' => current_time('mysql')]);
		update_user_meta($id, '_ft4a_promo_na', $end);
		$n++;
	}
	update_option('ft4a_promo_verlopen_laatst', ['at' => time(), 'n' => $n], false);
	return $n;
}

/* ---------- Bounces: onbestelbare mails uit de mailbox info@ft4a.com halen (IMAP, 3.6.78) ----------
   De mails vertrekken met info@ft4a.com als afzender (Return-Path), dus meldingen van onbestelbare mails komen daar terug.
   Elk uur leest de site alleen de bounce-meldingen (afzender mailer-daemon/postmaster of een typisch onderwerp), zet de
   adressen die niet bestaan op 'bounce' (nooit meer mailen, niet opnieuw importeren) en verplaatst die meldingen naar de
   map Bounces. Andere mails in de mailbox worden niet aangeraakt. Het wachtwoord staat versleuteld in de database. */
const FT4A_PROMO_IMAP_STANDAARD = ['host' => 'ft4a.com', 'port' => 993, 'user' => 'info@ft4a.com', 'map' => 'Bounces'];
function ft4a_promo_imap_cfg() { $c = get_option('ft4a_promo_imap'); return array_merge(FT4A_PROMO_IMAP_STANDAARD, is_array($c) ? $c : []); }
function ft4a_promo_sleutel() { return hash('sha256', wp_salt('auth') . '|ft4a-promo-imap', true); }
function ft4a_promo_imap_pw_set($pw) {
	if ($pw === '') { delete_option('ft4a_promo_imap_pw'); return; }
	if (function_exists('openssl_encrypt')) { $iv = random_bytes(16); $v = 'v1:' . base64_encode($iv . openssl_encrypt($pw, 'aes-256-cbc', ft4a_promo_sleutel(), OPENSSL_RAW_DATA, $iv)); }
	else $v = 'b64:' . base64_encode($pw);
	update_option('ft4a_promo_imap_pw', $v, false);
}
function ft4a_promo_imap_pw() {
	$v = (string) get_option('ft4a_promo_imap_pw', '');
	if (strpos($v, 'v1:') === 0 && function_exists('openssl_decrypt')) { $b = (string) base64_decode(substr($v, 3)); return (string) openssl_decrypt(substr($b, 16), 'aes-256-cbc', ft4a_promo_sleutel(), OPENSSL_RAW_DATA, substr($b, 0, 16)); }
	if (strpos($v, 'b64:') === 0) return (string) base64_decode(substr($v, 4));
	return '';
}

/* Kleine IMAP-client over SSL (geen PHP-imap-extensie nodig) */
class FT4A_Promo_Imap {
	private $s = null;
	private $tag = 0;
	public $fout = '';
	public $caps = '';
	public function open($host, $port, $user, $pass) {
		$ssl = apply_filters('ft4a_promo_imap_ssl', ['verify_peer' => true, 'verify_peer_name' => true, 'SNI_enabled' => true, 'peer_name' => $host]);
		$this->s = @stream_socket_client('ssl://' . $host . ':' . (int) $port, $no, $str, 20, STREAM_CLIENT_CONNECT, stream_context_create(['ssl' => $ssl]));
		if (!$this->s) { $this->fout = 'Geen verbinding met ' . $host . ':' . (int) $port . ($str ? ' (' . $str . ')' : '') . '. Controleer de server en de poort.'; return false; }
		stream_set_timeout($this->s, 30);
		$g = $this->regel();
		if ($g === false || stripos($g, '* OK') !== 0) { $this->fout = 'Onverwacht antwoord van de mailserver.'; return false; }
		$r = $this->cmd('LOGIN ' . $this->q($user) . ' ' . $this->q($pass));
		if (!$r[0]) { $this->fout = 'Inloggen bij de mailbox mislukt: controleer de gebruikersnaam en het wachtwoord.'; return false; }
		$c = $this->cmd('CAPABILITY');
		$this->caps = strtoupper(implode(' ', $c[1]) . ' ' . $r[2]);
		return true;
	}
	public function q($s) { return '"' . str_replace(['\\', '"'], ['\\\\', '\\"'], str_replace(["\r", "\n"], '', (string) $s)) . '"'; }
	/* één antwoordregel, met eventuele literals ({n} + n bytes) erin opgenomen */
	private function regel() {
		$l = fgets($this->s);
		if ($l === false) return false;
		while (preg_match('/\{(\d+)\}\r\n$/', $l, $m)) {
			$n = (int) $m[1];
			$data = '';
			while (strlen($data) < $n) {
				$stuk = fread($this->s, min(65536, $n - strlen($data)));
				if ($stuk === false || $stuk === '') break 2;
				$data .= $stuk;
			}
			$l .= $data;
			$rest = fgets($this->s);
			if ($rest === false) break;
			$l .= $rest;
		}
		return $l;
	}
	/* [gelukt, regels, slotregel] */
	public function cmd($c) {
		if (!$this->s) return [false, [], ''];
		$t = 'F' . (++$this->tag);
		fwrite($this->s, $t . ' ' . $c . "\r\n");
		$uit = [];
		while (($l = $this->regel()) !== false) {
			if (strpos($l, $t . ' ') === 0) return [stripos($l, $t . ' OK') === 0, $uit, $l];
			$uit[] = $l;
		}
		return [false, $uit, ''];
	}
	/* map voor de meldingen (met het voorvoegsel van de server, bv. INBOX.Bounces bij Plesk); aanmaken als ze er nog niet is */
	public function map($naam) {
		$prefix = '';
		$ns = $this->cmd('NAMESPACE');
		foreach ($ns[1] as $l) if (preg_match('/^\* NAMESPACE \(\("([^"]*)"/i', $l, $m)) $prefix = $m[1];
		$vol = $prefix . $naam;
		$lst = $this->cmd('LIST "" ' . $this->q($vol));
		foreach ($lst[1] as $l) if (stripos($l, '* LIST') === 0) return $vol;
		$c = $this->cmd('CREATE ' . $this->q($vol));
		if (!$c[0]) return '';
		$this->cmd('SUBSCRIBE ' . $this->q($vol));
		return $vol;
	}
	public function verplaats($uid, $map) {
		$uid = (int) $uid;
		if (preg_match('/\bMOVE\b/', $this->caps)) { $r = $this->cmd('UID MOVE ' . $uid . ' ' . $this->q($map)); if ($r[0]) return true; }
		$c = $this->cmd('UID COPY ' . $uid . ' ' . $this->q($map));
		if (!$c[0]) return false;
		$this->cmd('UID STORE ' . $uid . ' +FLAGS.SILENT (\\Deleted)');
		if (preg_match('/\bUIDPLUS\b/', $this->caps)) $this->cmd('UID EXPUNGE ' . $uid);
		return true;
	}
	public function close() {
		if (!$this->s) return;
		$this->cmd('LOGOUT');
		fclose($this->s);
		$this->s = null;
	}
}

/* Adressen die volgens een bounce-melding definitief niet afgeleverd konden worden: [adres => reden] */
function ft4a_promo_bounce_adressen($raw) {
	$uit = [];
	if (preg_match_all('/^X-Failed-Recipients:[ \t]*(.+(?:\r?\n[ \t]+.+)*)$/mi', $raw, $m)) {
		foreach ($m[1] as $v) foreach (preg_split('/[\s,]+/', $v) as $a) { $a = strtolower(trim($a, "<> \t\r\n")); if (is_email($a)) $uit[$a] = 'adres bestaat niet'; }
	}
	if (preg_match_all('/^Final-Recipient:[ \t]*rfc822;[ \t]*<?([^\s>]+)>?(.*?)(?=^Final-Recipient:|\z)/msi', $raw, $m, PREG_SET_ORDER)) {
		foreach ($m as $b) {
			$a = strtolower(trim($b[1]));
			$actie = preg_match('/^Action:[ \t]*(\w+)/mi', $b[2], $x) ? strtolower($x[1]) : '';
			$status = preg_match('/^Status:[ \t]*([245]\.\d{1,3}\.\d{1,3})/mi', $b[2], $y) ? $y[1] : '';
			$diag = preg_match('/^Diagnostic-Code:[ \t]*(?:smtp;[ \t]*)?(.+)$/mi', $b[2], $z) ? trim($z[1]) : '';
			if (in_array($actie, ['delayed', 'delivered', 'relayed', 'expanded'], true)) continue;
			if ($status !== '' && $status[0] !== '5') continue;
			if ($actie === '' && $status === '') continue;
			if (is_email($a)) $uit[$a] = mb_substr(trim(($status ? $status . ' ' : '') . $diag), 0, 200) ?: 'adres bestaat niet';
		}
	}
	return $uit;
}

add_action('ft4a_promo_bounces', 'ft4a_promo_bounces_run');
function ft4a_promo_bounces_plan() {
	if (get_option('ft4a_promo_imap_pw')) { if (!wp_next_scheduled('ft4a_promo_bounces')) wp_schedule_event(time() + 5 * MINUTE_IN_SECONDS, 'hourly', 'ft4a_promo_bounces'); }
	else wp_clear_scheduled_hook('ft4a_promo_bounces');
}
function ft4a_promo_bounces_run() {
	global $wpdb;
	$cfg = ft4a_promo_imap_cfg();
	$pw = ft4a_promo_imap_pw();
	$res = ['at' => time(), 'gelezen' => 0, 'bounces' => 0, 'verplaatst' => 0, 'fout' => ''];
	if ($pw === '') { $res['fout'] = 'Er is nog geen wachtwoord voor de mailbox ingevuld.'; update_option('ft4a_promo_bounce_laatst', $res, false); return $res; }
	if (get_transient('ft4a_promo_bounce_lock')) { $res['fout'] = 'Er loopt al een controle.'; return $res; }
	set_transient('ft4a_promo_bounce_lock', 1, 10 * MINUTE_IN_SECONDS);
	ft4a_promo_install();
	$t = ft4a_promo_table();
	$im = new FT4A_Promo_Imap();
	if (!$im->open($cfg['host'], (int) $cfg['port'], $cfg['user'], $pw)) {
		$res['fout'] = $im->fout;
	} else {
		$sel = $im->cmd('SELECT INBOX');
		$uv = 0; $volgende = 0;
		foreach ($sel[1] as $l) {
			if (preg_match('/UIDVALIDITY (\d+)/i', $l, $m)) $uv = (int) $m[1];
			if (preg_match('/UIDNEXT (\d+)/i', $l, $m)) $volgende = (int) $m[1];
		}
		$st = (array) get_option('ft4a_promo_bounce_uid', []);
		$van = (isset($st['uv'], $st['uid']) && (int) $st['uv'] === $uv) ? (int) $st['uid'] + 1 : 1;
		$uids = [];
		foreach (['FROM "mailer-daemon"', 'FROM "postmaster"', 'SUBJECT "undeliver"', 'SUBJECT "delivery status notification"', 'SUBJECT "mail delivery failed"', 'SUBJECT "returned mail"', 'SUBJECT "delivery failure"', 'SUBJECT "failure notice"', 'SUBJECT "niet afgeleverd"', 'SUBJECT "onbestelbaar"'] as $c) {
			$r = $im->cmd('UID SEARCH UID ' . $van . ':* ' . $c);
			foreach ($r[1] as $l) if (stripos($l, '* SEARCH') === 0) foreach (preg_split('/\s+/', trim(substr($l, 8))) as $u) if (ctype_digit($u) && (int) $u >= $van) $uids[(int) $u] = 1;
		}
		ksort($uids);
		$uids = array_keys($uids);
		$max = 60;
		$alles = count($uids) <= $max;
		$uids = array_slice($uids, 0, $max);
		$map = '';
		$laatste = $van - 1;
		foreach ($uids as $uid) {
			$laatste = max($laatste, $uid);
			$f = $im->cmd('UID FETCH ' . $uid . ' (BODY.PEEK[])');
			$raw = '';
			foreach ($f[1] as $l) if (preg_match('/BODY\[\] \{(\d+)\}\r\n/', $l, $m, PREG_OFFSET_CAPTURE)) { $raw = substr($l, $m[0][1] + strlen($m[0][0]), (int) $m[1][0]); break; }
			if ($raw === '') continue;
			$res['gelezen']++;
			$adr = ft4a_promo_bounce_adressen($raw);
			/* zonder standaardvelden: adressen uit onze lijst die in een duidelijke foutmelding staan */
			if (!$adr && preg_match('/\b5\.\d\.\d{1,3}\b|\b55[0-4][ -]|user unknown|does not exist|no such user|mailbox unavailable|recipient address rejected|invalid recipient|unknown user|address not found|adresse introuvable/i', $raw) && preg_match_all('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $raw, $mm)) {
				foreach (array_unique(array_map('strtolower', $mm[0])) as $a) {
					if ($a === strtolower($cfg['user'])) continue;
					if ($wpdb->get_var($wpdb->prepare("SELECT status FROM $t WHERE email = %s", $a)) === 'verzonden') $adr[$a] = 'adres bestaat niet';
				}
			}
			$ons = 0;
			foreach ($adr as $a => $reden) {
				$row = $wpdb->get_row($wpdb->prepare("SELECT id, status FROM $t WHERE email = %s", $a));
				if (!$row) continue;
				$ons++;
				if ($row->status !== 'bounce' && $row->status !== 'afgemeld') { ft4a_promo_set($row->id, 'bounce', 'Bounce: ' . $reden); $res['bounces']++; }
			}
			if ($ons) {
				if ($map === '') $map = $im->map($cfg['map']);
				if ($map !== '' && $im->verplaats($uid, $map)) $res['verplaatst']++;
			}
		}
		update_option('ft4a_promo_bounce_uid', ['uv' => $uv, 'uid' => ($alles && $volgende) ? max($laatste, $volgende - 1) : $laatste], false);
		$im->close();
	}
	update_option('ft4a_promo_bounce_laatst', $res, false);
	delete_transient('ft4a_promo_bounce_lock');
	return $res;
}

/* ---------- Adressen importeren (CSV met kolommen e-mail, voornaam, achternaam, land, taal) ---------- */
function ft4a_promo_import($rows) {
	global $wpdb;
	$t = ft4a_promo_table();
	$res = ['nieuw' => 0, 'bestaat' => 0, 'account' => 0, 'ongeldig' => 0];
	$pick = function ($row, $keys) {
		foreach ($keys as $k) if (isset($row[$k]) && trim((string) $row[$k]) !== '') return trim((string) $row[$k]);
		return '';
	};
	$kort = function ($s) { return mb_substr(sanitize_text_field($s), 0, 100); };
	foreach ($rows as $row) {
		$email = sanitize_email($pick($row, ['e-mailadres', 'email', 'e-mail', 'emailadres', 'mail', 'e-mail address']));
		if (!$email || !is_email($email)) { $res['ongeldig']++; continue; }
		$acc = email_exists($email) ? 1 : 0;
		$ok = $wpdb->query($wpdb->prepare(
			"INSERT IGNORE INTO $t (email, voornaam, achternaam, land, taal, status, soort, token, toegevoegd, fout) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
			$email,
			$kort($pick($row, ['voornaam', 'first name', 'firstname'])),
			$kort($pick($row, ['achternaam', 'last name', 'lastname', 'naam'])),
			$kort($pick($row, ['land', 'country'])),
			ft4a_promo_lang($pick($row, ['taal', 'taalcode', 'language', 'lang'])),
			$acc ? 'overgeslagen' : 'wachtrij',
			'ft4all',
			bin2hex(random_bytes(16)),
			current_time('mysql'),
			$acc ? 'Heeft een account op ft4a.com' : ''
		));
		if ($ok) $res[$acc ? 'account' : 'nieuw']++; else $res['bestaat']++;
	}
	if ($res['nieuw']) update_option('ft4a_promo_campagne', 1, false);
	return $res;
}

/* ---------- Afmelden: https://ft4a.com/?ft4a_afmelden=<code> (pagina met knop; met één klik via List-Unsubscribe-Post) ---------- */
add_action('init', function () {
	if (!isset($_GET['ft4a_afmelden'])) return;
	ft4a_promo_afmelden(sanitize_key(wp_unslash($_GET['ft4a_afmelden'])));
	exit;
}, 1);
function ft4a_promo_afmelden($token) {
	global $wpdb;
	nocache_headers();
	do_action('litespeed_control_set_nocache', 'ft4a: afmelden promotiemail');
	header('X-Robots-Tag: noindex, nofollow', true);
	$row = strlen($token) === 32 ? $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ft4a_promo_table() . ' WHERE token = %s', $token)) : null;
	$lang = $row ? ft4a_promo_lang($row->taal) : (function_exists('ft4a_browser_lang') ? (ft4a_browser_lang() ?: 'en') : 'en');
	if (!isset(FT4A_LANGS[$lang])) $lang = 'en';
	$post = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST';
	if ($row && $post && $row->status !== 'afgemeld') ft4a_promo_set($row->id, 'afgemeld');
	$GLOBALS['ft4a_lang_stack'][] = $lang;
	$home = ft4a_url('home', $lang);
	if (!$row) {
		$titel = ft4a_t('Deze link werkt niet meer');
		$inhoud = '<p>' . esc_html(ft4a_t('Deze afmeldlink is niet (meer) geldig. Wil je geen e-mails meer ontvangen? Stuur dan een e-mail naar info@ft4a.com.')) . '</p><p><a class="btn" href="' . esc_url($home) . '">' . esc_html(ft4a_t('Naar FT4A.com')) . '</a></p>';
	} elseif ($post || $row->status === 'afgemeld') {
		$titel = ft4a_t('Je bent afgemeld');
		$inhoud = '<p>' . esc_html(sprintf(ft4a_t('Je krijgt geen e-mails van FT4A.com meer op %s.'), $row->email)) . '</p><p><a class="btn" href="' . esc_url($home) . '">' . esc_html(ft4a_t('Naar FT4A.com')) . '</a></p>';
	} else {
		$titel = ft4a_t('Afmelden');
		$inhoud = '<p>' . esc_html(sprintf(ft4a_t('Wil je geen e-mails van FT4A.com meer ontvangen op %s?'), $row->email)) . '</p><form method="post" action="' . esc_url(add_query_arg('ft4a_afmelden', $row->token, home_url('/'))) . '"><button type="submit" class="btn">' . esc_html(ft4a_t('Afmelden')) . '</button></form>';
	}
	array_pop($GLOBALS['ft4a_lang_stack']);
	status_header($row ? 200 : 404);
	header('Content-Type: text/html; charset=utf-8');
	$logo = plugins_url('assets/logo-180.png', FT4A_DIR . 'ft4a-leden.php');
	echo '<!doctype html><html lang="' . esc_attr(FT4A_LANGS[$lang][2]) . '" dir="' . ($lang === 'ar' ? 'rtl' : 'ltr') . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . esc_html($titel) . ' – FT4A.com</title>'
		. '<style>body{margin:0;background:#eef3f0;color:#1d2a23;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}.wrap{max-width:520px;margin:48px auto;padding:0 16px}.card{background:#fff;border:1px solid #d7e3dc;border-radius:20px;overflow:hidden;box-shadow:0 12px 32px rgba(15,40,28,.10)}.head{background:#17241e;border-bottom:4px solid #62dc9e;padding:18px 26px}.head a{display:inline-flex;align-items:center;gap:12px;color:#fff;text-decoration:none;font-size:22px;font-weight:800;letter-spacing:-.3px}.head img{width:40px;height:40px;border-radius:10px}.head b{color:#e3342f}.head i{font-style:normal;color:#1f9d55}.body{padding:28px 26px 30px}h1{margin:0 0 12px;font-size:24px;line-height:1.25;color:#0f1f17}p{margin:0 0 16px;font-size:15px;line-height:1.6;color:#3d4a43;overflow-wrap:anywhere}.btn{display:inline-block;background:#16924f;color:#fff;border:0;border-radius:12px;padding:14px 24px;font:inherit;font-size:15px;font-weight:700;text-decoration:none;cursor:pointer}</style></head>'
		. '<body><div class="wrap"><div class="card"><div class="head"><a href="' . esc_url($home) . '"><img src="' . esc_url($logo) . '" alt="">FT<b>4</b>A<i>.com</i></a></div><div class="body"><h1>' . esc_html($titel) . '</h1>' . $inhoud . '</div></div></div></body></html>';
}

/* ---------- Beheer: FT4A → Promotiemail ---------- */
add_action('admin_post_ft4a_promo', function () {
	if (!current_user_can('manage_options')) wp_die('Geen toegang.');
	check_admin_referer('ft4a_promo');
	global $wpdb;
	ft4a_promo_install();
	$t = ft4a_promo_table();
	$doe = sanitize_key($_POST['doe'] ?? '');
	$msg = '';
	if ($doe === 'start') {
		$n = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE status = %s", 'wachtrij'));
		if (!$n && !get_option('ft4a_promo_verlopen', 1)) $msg = 'De wachtrij is leeg: importeer eerst een lijst.';
		elseif (!function_exists('WC')) $msg = 'WooCommerce is niet actief: zonder WooCommerce kan de site de mails niet in de FT4A-opmaak versturen.';
		elseif (!ft4a_promo_text('en')) $msg = 'Er is geen (gepubliceerde) Engelse tekst. Die is nodig voor talen zonder eigen tekst.';
		else { ft4a_promo_start(); $msg = $n ? 'De verzending is gestart. Het eerste pakje vertrekt binnen enkele minuten.' : 'De verzending staat aan. Oud-leden van ft4a.com krijgen hun mail vanzelf zodra ze in de wachtrij komen.'; }
	} elseif ($doe === 'pauze') {
		ft4a_promo_stop();
		$msg = 'De verzending is gepauzeerd. Er vertrekt niets meer tot je opnieuw op Start klikt.';
	} elseif ($doe === 'instellingen') {
		update_option('ft4a_promo_aantal', max(1, min(50, (int) ($_POST['aantal'] ?? 5))));
		update_option('ft4a_promo_minuten', max(5, min(1440, (int) ($_POST['minuten'] ?? 15))));
		if (get_option('ft4a_promo_aan')) ft4a_promo_start();
		$msg = 'Bewaard: ' . ft4a_promo_aantal() . ' mails om de ' . ft4a_promo_minuten() . ' minuten.';
	} elseif ($doe === 'verlopen') {
		update_option('ft4a_promo_verlopen', empty($_POST['aan']) ? 0 : 1);
		update_option('ft4a_promo_verlopen_trial', empty($_POST['trial']) ? 0 : 1);
		$msg = get_option('ft4a_promo_verlopen') ? 'Bewaard: oud-leden van ft4a.com komen ' . FT4A_PROMO_DAGEN . ' dagen na het einde van hun pakket' . (get_option('ft4a_promo_verlopen_trial') ? ' of proefperiode' : '') . ' in de wachtrij.' : 'Bewaard: oud-leden van ft4a.com worden niet meer automatisch toegevoegd.';
	} elseif ($doe === 'verlopen_nu') {
		$k = ft4a_promo_verlopen_run();
		$msg = get_option('ft4a_promo_verlopen', 1) ? $k . ' oud-leden van ft4a.com in de wachtrij gezet.' : 'Het automatisch toevoegen van oud-leden staat uit.';
	} elseif ($doe === 'bounces') {
		$host = preg_replace('/[^a-z0-9.\-]/i', '', (string) wp_unslash($_POST['host'] ?? ''));
		$map = trim(preg_replace('/["\\\\\r\n]/', '', sanitize_text_field(wp_unslash($_POST['map'] ?? ''))));
		update_option('ft4a_promo_imap', [
			'host' => $host ?: FT4A_PROMO_IMAP_STANDAARD['host'],
			'port' => max(1, min(65535, (int) ($_POST['port'] ?? 993))),
			'user' => sanitize_text_field(wp_unslash($_POST['user'] ?? '')) ?: FT4A_PROMO_IMAP_STANDAARD['user'],
			'map'  => $map ?: FT4A_PROMO_IMAP_STANDAARD['map'],
		], false);
		$pw = str_replace(["\r", "\n"], '', (string) wp_unslash($_POST['pw'] ?? ''));
		if ($pw !== '') ft4a_promo_imap_pw_set($pw);
		ft4a_promo_bounces_plan();
		if (get_option('ft4a_promo_imap_pw')) {
			$r = ft4a_promo_bounces_run();
			$msg = $r['fout'] ? 'Bewaard, maar de controle lukte niet: ' . $r['fout'] : sprintf('Bewaard en gecontroleerd: %d meldingen gelezen, %d adressen op Bounce gezet. Dit gebeurt nu elk uur.', $r['gelezen'], $r['bounces']);
		} else $msg = 'Bewaard. Vul het wachtwoord van de mailbox in om bounces te verwerken.';
	} elseif ($doe === 'bounces_nu') {
		$r = ft4a_promo_bounces_run();
		$msg = $r['fout'] ? 'Controle mislukt: ' . $r['fout'] : sprintf('%d meldingen gelezen, %d adressen op Bounce gezet, %d meldingen naar de map verplaatst.', $r['gelezen'], $r['bounces'], $r['verplaatst']);
	} elseif ($doe === 'test') {
		$u = wp_get_current_user();
		$naar = sanitize_email(wp_unslash($_POST['naar'] ?? '')) ?: $u->user_email;
		$keuze = sanitize_text_field(wp_unslash($_POST['taal'] ?? 'nl'));
		$soort = ft4a_promo_soort(sanitize_key($_POST['soort'] ?? 'ft4all'));
		$talen = $keuze === 'alle' ? array_keys(FT4A_LANGS) : [ft4a_promo_lang($keuze)];
		$ok = 0; $fout = '';
		foreach ($talen as $l) {
			$res = ft4a_promo_mail((object) ['email' => $naar, 'voornaam' => $u->first_name ?: $u->display_name, 'taal' => $l, 'soort' => $soort, 'token' => str_repeat('0', 32)], $naar);
			if ($res === true) $ok++; else $fout = $res->get_error_message();
		}
		$msg = $ok . ' testmail' . ($ok === 1 ? '' : 's') . ' (' . FT4A_PROMO_SOORTEN[$soort][1] . ') verstuurd naar ' . $naar . '.' . ($fout ? ' Fout: ' . $fout : '');
	} elseif ($doe === 'import') {
		$f = $_FILES['lijst']['tmp_name'] ?? '';
		if (!$f || !is_uploaded_file($f)) $msg = 'Kies eerst een CSV-bestand.';
		else {
			$r = ft4a_promo_import(ft4a_import_rows($f));
			$msg = sprintf('Import: %d adressen in de wachtrij gezet, %d stonden al in de lijst, %d hebben al een account op ft4a.com (overgeslagen), %d ongeldig.', $r['nieuw'], $r['bestaat'], $r['account'], $r['ongeldig']);
		}
	} elseif ($doe === 'opnieuw') {
		$k = (int) $wpdb->query($wpdb->prepare("UPDATE $t SET status = %s, fout = '' WHERE status = %s", 'wachtrij', 'mislukt'));
		$msg = $k . ' mislukte adressen staan opnieuw in de wachtrij.';
	} elseif ($doe === 'afmelden') {
		$e = sanitize_email(wp_unslash($_POST['email'] ?? ''));
		if (!$e || !is_email($e)) $msg = 'Geef een geldig e-mailadres.';
		else {
			$id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE email = %s", $e));
			if ($id) ft4a_promo_set($id, 'afgemeld', 'Afgemeld door de beheerder');
			else $wpdb->insert($t, ['email' => $e, 'taal' => 'en', 'status' => 'afgemeld', 'token' => bin2hex(random_bytes(16)), 'toegevoegd' => current_time('mysql'), 'afgemeld' => current_time('mysql'), 'fout' => 'Afgemeld door de beheerder']);
			$msg = $e . ' is afgemeld en krijgt geen promotiemail.';
		}
	} elseif ($doe === 'leegmaken') {
		$k = (int) $wpdb->query($wpdb->prepare("DELETE FROM $t WHERE status = %s", 'wachtrij'));
		$msg = $k . ' adressen uit de wachtrij verwijderd. Verstuurde en afgemelde adressen blijven bewaard.';
	}
	wp_safe_redirect(add_query_arg('r', rawurlencode($msg), admin_url('admin.php?page=ft4a-promo')));
	exit;
});

function ft4a_promo_form($doe, $inner, $extra = '', $style = 'display:inline-block;margin:0 8px 8px 0') {
	return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="' . esc_attr($style) . '"' . $extra . '><input type="hidden" name="action" value="ft4a_promo"><input type="hidden" name="doe" value="' . esc_attr($doe) . '">' . wp_nonce_field('ft4a_promo', '_wpnonce', true, false) . $inner . '</form>';
}

function ft4a_promo_page() {
	global $wpdb;
	if (!current_user_can('manage_options')) return;
	ft4a_promo_install();
	ft4a_promo_seed_texts();
	$t = ft4a_promo_table();
	$cnt = array_fill_keys(array_keys(FT4A_PROMO_STATUS), 0);
	foreach ((array) $wpdb->get_results("SELECT status, COUNT(*) AS n FROM $t GROUP BY status") as $x) $cnt[$x->status] = (int) $x->n;
	$wacht_oud = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE status = %s AND soort = %s", 'wachtrij', 'verlopen'));
	$aan = (bool) get_option('ft4a_promo_aan');
	$vaan = (bool) get_option('ft4a_promo_verlopen', 1);
	$vtrial = (bool) get_option('ft4a_promo_verlopen_trial', 1);
	$n = ft4a_promo_aantal();
	$m = ft4a_promo_minuten();
	$last = get_option('ft4a_promo_laatst');
	$vlast = get_option('ft4a_promo_verlopen_laatst');
	$next = wp_next_scheduled('ft4a_promo_tick');
	$vnext = wp_next_scheduled('ft4a_promo_verlopen');
	$mel = get_option('ft4a_promo_melding');
	$dt = function ($ts) { return esc_html(wp_date('j M Y H:i', $ts)); };
	$md = function ($v) { return $v ? esc_html(mysql2date('j M Y H:i', $v)) : '—'; };

	echo '<div class="wrap"><h1>Promotiemail</h1>';
	echo '<p style="max-width:860px">Promotiemails voor oude accounts van footballtraining4all.com (geïmporteerd) en voor oud-leden van ft4a.com (' . FT4A_PROMO_DAGEN . ' dagen na het einde van hun pakket, automatisch). Zolang de verzending aan staat, vertrekt er elke <strong>' . $m . ' minuten</strong> een pakje van <strong>' . $n . ' mails</strong>, in de taal van de ontvanger en in de FT4A-opmaak, vanaf info@ft4a.com. Onderaan elke mail staat waarom iemand de mail krijgt en een afmeldlink. Er vertrekt niets tot je op <strong>Verzending starten</strong> klikt; zolang de verzending aan staat, gaan nieuwe adressen in de wachtrij vanzelf mee.</p>';
	if (!empty($_GET['r'])) echo '<div class="notice notice-info is-dismissible"><p>' . esc_html(rawurldecode(wp_unslash($_GET['r']))) . '</p></div>';
	if (is_array($mel) && !empty($mel['tekst'])) echo '<div class="notice notice-' . (strpos($mel['tekst'], 'Klaar') === 0 ? 'success' : 'warning') . '"><p>' . $dt($mel['at']) . ': ' . esc_html($mel['tekst']) . '</p></div>';
	if (!function_exists('WC')) echo '<div class="notice notice-error"><p>WooCommerce is niet actief. De promotiemail gebruikt de mailopmaak van WooCommerce en kan zonder WooCommerce niet vertrekken.</p></div>';

	/* Verzending */
	echo '<h2>Verzending</h2><table class="widefat striped" style="max-width:860px"><tbody>';
	echo '<tr><th style="width:230px">Status</th><td>' . ($aan ? '<strong style="color:#16924f">Aan</strong>' . ($cnt['wachtrij'] ? '' : ' (wachtrij leeg: nieuwe adressen gaan vanzelf mee)') : '<strong style="color:#b32d2e">Gepauzeerd</strong>') . '</td></tr>';
	$st = [];
	foreach (FT4A_PROMO_STATUS as $k => $lab) $st[] = esc_html($lab) . ': <strong>' . number_format_i18n($cnt[$k]) . '</strong>' . ($k === 'wachtrij' && $wacht_oud ? ' (waarvan ' . number_format_i18n($wacht_oud) . ' oud-leden)' : '');
	echo '<tr><th>Adressen</th><td>' . implode(' &nbsp;·&nbsp; ', $st) . '</td></tr>';
	echo '<tr><th>Laatste pakje</th><td>' . (is_array($last) ? $dt($last['at']) . ' (' . (int) $last['sent'] . ' verstuurd' . (!empty($last['fail']) ? ', ' . (int) $last['fail'] . ' mislukt' : '') . ')' : 'nog geen') . '</td></tr>';
	if ($aan) {
		echo '<tr><th>Volgende pakje</th><td>' . ($next ? $dt($next) : '—') . '</td></tr>';
		if ($next && $cnt['wachtrij']) {
			$eind = $next + (int) (ceil($cnt['wachtrij'] / $n) - 1) * $m * MINUTE_IN_SECONDS;
			echo '<tr><th>Wachtrij verstuurd rond</th><td>' . $dt($eind) . '</td></tr>';
		}
		if ($next && $next < time() - 10 * MINUTE_IN_SECONDS) echo '<tr><th>Let op</th><td>Het volgende pakje is te laat. WordPress voert geplande taken pas uit bij een bezoek aan de site. Een cronjob bij Cloud86 die elke ' . $m . ' minuten <code>' . esc_html(site_url('wp-cron.php')) . '</code> oproept, maakt het stipt.</td></tr>';
	}
	echo '</tbody></table><p>';
	echo $aan
		? ft4a_promo_form('pauze', '<button class="button button-secondary">Pauzeren</button>')
		: ft4a_promo_form('start', '<button class="button button-primary"' . (($cnt['wachtrij'] || $vaan) ? '' : ' disabled') . '>Verzending starten</button>', ' onsubmit="return confirm(\'De verzending starten? Elke ' . $m . ' minuten vertrekken er ' . $n . ' mails naar de adressen in de wachtrij.\')"');
	echo '</p>';
	echo ft4a_promo_form('instellingen', '<label>Pakje: <input type="number" name="aantal" min="1" max="50" value="' . $n . '" style="width:64px"> mails</label> &nbsp; <label>om de <input type="number" name="minuten" min="5" max="1440" value="' . $m . '" style="width:72px"> minuten</label> &nbsp; <button class="button">Bewaren</button>', '', 'margin:4px 0 0') . '<p class="description">Cloud86 laat maximaal 250 mails per uur toe voor de hele site, ook voor bestellingen en licenties. Hou de promotiemail daarom ruim onder die grens.</p>';

	/* Oud-leden van ft4a.com */
	echo '<h2 style="margin-top:28px">Oud-leden van ft4a.com</h2><p style="max-width:860px">Elke dag zet de site leden van ft4a.com van wie het pakket minstens <strong>' . FT4A_PROMO_DAGEN . ' dagen</strong> afgelopen is in de wachtrij. Zij krijgen hun eigen mail met de knop <strong>Pakket kiezen</strong> (teksten hieronder). Iedereen krijgt die mail één keer per einddatum; wie intussen weer een pakket heeft of zich afmeldde, krijgt niets.</p>';
	echo ft4a_promo_form('verlopen', '<label><input type="checkbox" name="aan" value="1"' . checked($vaan, true, false) . '> Oud-leden automatisch toevoegen</label> &nbsp; <label><input type="checkbox" name="trial" value="1"' . checked($vtrial, true, false) . '> ook als alleen de proefperiode van 7 dagen afgelopen is</label> &nbsp; <button class="button">Bewaren</button>', '', 'margin:0 0 8px');
	echo '<p class="description">Laatste controle: ' . (is_array($vlast) ? $dt($vlast['at']) . ' (' . (int) $vlast['n'] . ' toegevoegd)' : 'nog niet') . ' · Volgende: ' . ($vnext ? $dt($vnext) : '—') . '</p>';
	if ($vaan) echo ft4a_promo_form('verlopen_nu', '<button class="button">Nu controleren</button>', '', 'margin:4px 0 0');

	/* Bounces */
	ft4a_promo_bounces_plan();
	$ic = ft4a_promo_imap_cfg();
	$heeftpw = (bool) get_option('ft4a_promo_imap_pw');
	$bl = get_option('ft4a_promo_bounce_laatst');
	$bnext = wp_next_scheduled('ft4a_promo_bounces');
	echo '<h2 style="margin-top:28px">Bounces</h2><p style="max-width:860px">Mails die niet afgeleverd kunnen worden, komen als melding terug in de mailbox <strong>' . esc_html($ic['user']) . '</strong>. Elk uur leest de site die mailbox (alleen de bounce-meldingen), zet de adressen die niet bestaan op <strong>Bounce</strong> (ze krijgen nooit meer een mail en worden niet opnieuw geïmporteerd) en verplaatst die meldingen naar de map <strong>' . esc_html($ic['map']) . '</strong>. Andere mails worden niet aangeraakt. Vóór elke mail controleert de site ook of het domein van het adres nog bestaat; zo niet, dan gaat het adres meteen naar Bounce, zonder mail.</p>';
	echo ft4a_promo_form('bounces', '<label>Server <input name="host" value="' . esc_attr($ic['host']) . '" style="width:150px"></label> &nbsp; <label>Poort <input type="number" name="port" value="' . (int) $ic['port'] . '" style="width:72px"></label> &nbsp; <label>Gebruiker <input name="user" value="' . esc_attr($ic['user']) . '" style="width:170px"></label> &nbsp; <label>Wachtwoord <input type="password" name="pw" autocomplete="new-password" placeholder="' . esc_attr($heeftpw ? '•••••••• (bewaard)' : 'wachtwoord van de mailbox') . '" style="width:190px"></label> &nbsp; <label>Map <input name="map" value="' . esc_attr($ic['map']) . '" style="width:100px"></label> &nbsp; <button class="button">Bewaren</button>', '', 'margin:0 0 8px');
	echo '<p class="description">' . ($heeftpw ? 'Het wachtwoord is (versleuteld) bewaard; laat het veld leeg om het te houden.' : '<strong style="color:#b32d2e">Vul één keer het wachtwoord van ' . esc_html($ic['user']) . ' in om bounces automatisch te verwerken.</strong>') . ' Laatste controle: ' . (is_array($bl) ? $dt($bl['at']) . (!empty($bl['fout']) ? ' – <span style="color:#b32d2e">' . esc_html($bl['fout']) . '</span>' : ' (' . (int) $bl['gelezen'] . ' meldingen gelezen, ' . (int) $bl['bounces'] . ' adressen op Bounce gezet)') : 'nog niet') . ($bnext ? ' · Volgende: ' . $dt($bnext) : '') . '</p>';
	if ($heeftpw) echo ft4a_promo_form('bounces_nu', '<button class="button">Nu controleren</button>', '', 'margin:4px 0 0');

	/* Testmail */
	$opts = '<option value="alle">Alle 18 talen</option>';
	foreach (FT4A_LANGS as $code => $l) $opts .= '<option value="' . esc_attr($code) . '"' . selected($code, 'nl', false) . '>' . esc_html($l[3]) . '</option>';
	$sopts = '';
	foreach (FT4A_PROMO_SOORTEN as $k => $s) $sopts .= '<option value="' . esc_attr($k) . '">' . esc_html($k === 'verlopen' ? 'Oud-leden ft4a.com' : 'Promotiemail (footballtraining4all.com)') . '</option>';
	echo '<h2 style="margin-top:28px">Testmail</h2>' . ft4a_promo_form('test', '<label>Mail <select name="soort">' . $sopts . '</select></label> &nbsp; <label>Taal <select name="taal">' . $opts . '</select></label> &nbsp; <label>naar <input type="email" name="naar" value="' . esc_attr(wp_get_current_user()->user_email) . '" style="width:240px"></label> &nbsp; <button class="button">Testmail versturen</button>', '', 'margin:0') . '<p class="description">De testmail is precies de mail die de ontvangers krijgen (met jouw voornaam). De afmeldlink in een testmail werkt niet.</p>';

	/* Import */
	echo '<h2 style="margin-top:28px">Adressen importeren</h2>' . ft4a_promo_form('import', '<input type="file" name="lijst" accept=".csv,text/csv"> <button class="button">Importeren</button>', ' enctype="multipart/form-data"', 'margin:0') . '<p class="description">Voor oude accounts van footballtraining4all.com. CSV-bestand met de kolommen <code>email</code> (verplicht), <code>voornaam</code>, <code>achternaam</code>, <code>land</code> en <code>taal</code> (bv. nl, fr, pt-br, of Nederlands, Frans …). Komma of puntkomma als scheidingsteken. Adressen die al in de lijst staan (ook afgemelde) worden niet opnieuw toegevoegd.</p>';

	/* Teksten */
	$ws = [];
	foreach ((array) $wpdb->get_results($wpdb->prepare("SELECT soort, taal, COUNT(*) AS n FROM $t WHERE status = %s GROUP BY soort, taal", 'wachtrij')) as $x) $ws[ft4a_promo_soort($x->soort) . '|' . $x->taal] = (int) $x->n;
	$by = [];
	foreach (get_posts(['post_type' => 'ft4a_promomail', 'post_status' => ['publish', 'draft', 'pending', 'private'], 'numberposts' => -1, 'suppress_filters' => true]) as $p) {
		$k = ft4a_promo_soort_van($p->ID) . '|' . (string) get_post_meta($p->ID, '_ft4a_lang', true);
		if (!isset($by[$k]) || $p->post_status === 'publish') $by[$k] = $p;
	}
	echo '<h2 style="margin-top:28px">Teksten</h2><p class="description" style="max-width:860px">Klik op Bewerken om het onderwerp of de tekst van een taal aan te passen. <code>{voornaam}</code> wordt de voornaam, <code>{knop}</code> de groene knop.</p>';
	foreach (FT4A_PROMO_SOORTEN as $soort => $s) {
		echo '<h3 style="margin:18px 0 8px">' . esc_html($s[0]) . '</h3>';
		$eigen = (array) get_option($soort === 'ft4all' ? 'ft4a_promo_eigen' : 'ft4a_promo_eigen_' . $soort, []);
		if ($eigen) echo '<p class="description" style="max-width:860px">Niet bijgewerkt naar de nieuwste tekst omdat ze in WordPress aangepast zijn: ' . esc_html(implode(', ', $eigen)) . '.</p>';
		echo '<table class="widefat striped" style="max-width:860px"><thead><tr><th>Taal</th><th>Onderwerp</th><th>In de wachtrij</th><th></th></tr></thead><tbody>';
		foreach (FT4A_LANGS as $code => $l) {
			$p = $by[$soort . '|' . $code] ?? null;
			$sub = $p ? esc_html($p->post_title) . ($p->post_status !== 'publish' ? ' <em>(niet gepubliceerd: de Engelse tekst wordt gebruikt)</em>' : '') : '<em>geen tekst: de Engelse tekst wordt gebruikt</em>';
			echo '<tr><td>' . esc_html($l[3]) . '</td><td>' . $sub . '</td><td>' . number_format_i18n($ws[$soort . '|' . $code] ?? 0) . '</td><td>' . ($p ? '<a href="' . esc_url(get_edit_post_link($p->ID)) . '">Bewerken</a>' : '') . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	/* Laatst verstuurd, afgemeld en mislukt */
	$lijst = function ($titel, $sql, $kolom) use ($wpdb, $md) {
		$rows = $wpdb->get_results($sql);
		echo '<h2 style="margin-top:28px">' . esc_html($titel) . '</h2><table class="widefat striped" style="max-width:860px"><thead><tr><th style="width:150px">Wanneer</th><th>E-mail</th><th style="width:80px">Soort</th><th style="width:60px">Taal</th><th>Opmerking</th></tr></thead><tbody>';
		if (!$rows) echo '<tr><td colspan="5">Nog niets.</td></tr>';
		foreach ((array) $rows as $r) echo '<tr><td>' . $md($r->$kolom) . '</td><td>' . esc_html($r->email) . '</td><td>' . esc_html(FT4A_PROMO_SOORTEN[ft4a_promo_soort($r->soort)][1]) . '</td><td>' . esc_html(strtoupper($r->taal)) . '</td><td>' . esc_html($r->fout) . '</td></tr>';
		echo '</tbody></table>';
	};
	$lijst('Laatst verstuurd', "SELECT email, soort, taal, fout, verzonden FROM $t WHERE status = 'verzonden' ORDER BY verzonden DESC, id DESC LIMIT 30", 'verzonden');
	if ($wacht_oud) $lijst('Oud-leden in de wachtrij', "SELECT email, soort, taal, fout, toegevoegd FROM $t WHERE status = 'wachtrij' AND soort = 'verlopen' ORDER BY id ASC LIMIT 30", 'toegevoegd');
	$lijst('Afgemeld', "SELECT email, soort, taal, fout, afgemeld FROM $t WHERE status = 'afgemeld' ORDER BY afgemeld DESC, id DESC LIMIT 30", 'afgemeld');
	if ($cnt['bounce']) $lijst('Bounces (uit de verzending gehaald)', "SELECT email, soort, taal, fout, verzonden FROM $t WHERE status = 'bounce' ORDER BY id DESC LIMIT 30", 'verzonden');
	if ($cnt['mislukt']) $lijst('Mislukt', "SELECT email, soort, taal, fout, toegevoegd FROM $t WHERE status = 'mislukt' ORDER BY id DESC LIMIT 30", 'toegevoegd');

	/* Beheer */
	echo '<h2 style="margin-top:28px">Beheer</h2><p>';
	echo ft4a_promo_form('afmelden', '<input type="email" name="email" placeholder="e-mailadres" style="width:240px" required> <button class="button">Adres afmelden</button>');
	if ($cnt['mislukt']) echo ft4a_promo_form('opnieuw', '<button class="button">Mislukte adressen opnieuw in de wachtrij</button>');
	if ($cnt['wachtrij']) echo ft4a_promo_form('leegmaken', '<button class="button button-link-delete">Wachtrij leegmaken</button>', ' onsubmit="return confirm(\'Alle ' . (int) $cnt['wachtrij'] . ' adressen die nog niet verstuurd zijn uit de wachtrij verwijderen?\')"');
	echo '</p><p class="description">Vraagt iemand per mail om geen e-mails meer te krijgen? Vul het adres in bij Adres afmelden.</p></div>';
}

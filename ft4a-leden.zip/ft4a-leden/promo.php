<?php
/* ---------- Promotiemail naar oude accounts van footballtraining4all.com (3.6.74) ----------
   FT4A → Promotiemail: adressen importeren (CSV), testmail sturen en de verzending starten of pauzeren.
   Zolang de verzending aan staat, vertrekt elke 15 minuten een pakje van 5 mails (instelbaar), in de taal van de
   ontvanger en in de FT4A-opmaak, vanaf info@ft4a.com. Onderaan elke mail staat een afmeldlink; de mail heeft ook een
   List-Unsubscribe-kop (afmelden met één klik in Gmail, Outlook …). Wie zich afmeldt of al een account op ft4a.com
   heeft, krijgt niets. De teksten staan per taal onder FT4A → Promotiemail-teksten (bewerkbaar in WordPress).
   De verzending staat standaard uit: niets vertrekt voordat iemand in het beheer op Start klikt. */
if (!defined('ABSPATH')) exit;

const FT4A_PROMO_DB = 'v1';
const FT4A_PROMO_STATUS = [
	'wachtrij'     => 'In de wachtrij',
	'verzonden'    => 'Verstuurd',
	'afgemeld'     => 'Afgemeld',
	'mislukt'      => 'Mislukt',
	'overgeslagen' => 'Overgeslagen (heeft een account op ft4a.com)',
];

function ft4a_promo_table() { global $wpdb; return $wpdb->prefix . 'ft4a_promo'; }
function ft4a_promo_aantal() { return max(1, min(50, (int) get_option('ft4a_promo_aantal', 5))); }
function ft4a_promo_minuten() { return max(5, min(1440, (int) get_option('ft4a_promo_minuten', 15))); }

/* Tabel met de adressen (eenmalig aanmaken) */
function ft4a_promo_install() {
	if (get_option('ft4a_promo_db') === FT4A_PROMO_DB) return;
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$t = ft4a_promo_table();
	dbDelta("CREATE TABLE $t (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  email varchar(190) NOT NULL,
  voornaam varchar(100) NOT NULL DEFAULT '',
  achternaam varchar(100) NOT NULL DEFAULT '',
  land varchar(100) NOT NULL DEFAULT '',
  taal varchar(8) NOT NULL DEFAULT 'en',
  status varchar(20) NOT NULL DEFAULT 'wachtrij',
  token char(32) NOT NULL,
  toegevoegd datetime DEFAULT NULL,
  verzonden datetime DEFAULT NULL,
  afgemeld datetime DEFAULT NULL,
  fout varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY  (id),
  UNIQUE KEY email (email),
  UNIQUE KEY token (token),
  KEY status (status)
) " . $wpdb->get_charset_collate() . ';');
	if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) !== $t) return;
	add_option('ft4a_promo_aan', 0);
	update_option('ft4a_promo_db', FT4A_PROMO_DB);
}
add_action('admin_init', 'ft4a_promo_install', 5);

/* Taal van een ontvanger: FT4A-code (nl, fr …), code van footballtraining4all.com (nl-NL, se-FI …) of de naam uit de ledenlijst (Nederlands, Frans …) */
function ft4a_promo_lang($v) {
	$v = trim((string) $v);
	$v = function_exists('mb_strtolower') ? mb_strtolower($v, 'UTF-8') : strtolower($v);
	$v = str_replace('_', '-', $v);
	if ($v === '') return 'en';
	if (isset(FT4A_LANGS[$v])) return $v;
	$oud = ['nl-nl' => 'nl', 'nl-be' => 'nl', 'en-gb' => 'en', 'fr-fr' => 'fr', 'fr-be' => 'fr', 'de-de' => 'de', 'es-es' => 'es', 'it-it' => 'it', 'pt-pt' => 'pt', 'da-dk' => 'da', 'sv-se' => 'sv', 'se-fi' => 'fi', 'fi-fi' => 'fi', 'smj-no' => 'no', 'nb-no' => 'no', 'nn-no' => 'no', 'nb' => 'no', 'nn' => 'no', 'pl-pl' => 'pl', 'tr-tr' => 'tr', 'ru-ru' => 'ru', 'ro-ro' => 'ro'];
	if (isset($oud[$v])) return $oud[$v];
	$namen = ['nederlands' => 'nl', 'engels' => 'en', 'engels (vs)' => 'en-us', 'frans' => 'fr', 'duits' => 'de', 'spaans' => 'es', 'italiaans' => 'it', 'portugees' => 'pt', 'portugees (brazilië)' => 'pt-br', 'deens' => 'da', 'zweeds' => 'sv', 'fins' => 'fi', 'noors' => 'no', 'pools' => 'pl', 'turks' => 'tr', 'russisch' => 'ru', 'roemeens' => 'ro', 'arabisch' => 'ar'];
	if (isset($namen[$v])) return $namen[$v];
	if (strpos($v, 'ar-') === 0) return 'ar';
	$s = substr($v, 0, 2);
	return isset(FT4A_LANGS[$s]) ? $s : 'en';
}

/* Voornaam netjes: "jan" of "JAN" wordt "Jan" */
function ft4a_promo_naam($s) {
	$s = trim((string) preg_replace('/\s+/u', ' ', (string) $s));
	if ($s === '' || !function_exists('mb_convert_case')) return $s;
	$lo = mb_strtolower($s, 'UTF-8');
	if ($s === $lo || $s === mb_strtoupper($s, 'UTF-8')) $s = mb_convert_case($lo, MB_CASE_TITLE, 'UTF-8');
	return $s;
}

function ft4a_promo_set($id, $status, $fout = '') {
	global $wpdb;
	$d = ['status' => $status, 'fout' => mb_substr((string) $fout, 0, 250)];
	if ($status === 'verzonden') $d['verzonden'] = current_time('mysql');
	if ($status === 'afgemeld') $d['afgemeld'] = current_time('mysql');
	$wpdb->update(ft4a_promo_table(), $d, ['id' => (int) $id]);
}

/* ---------- Teksten: één bericht per taal, bewerkbaar in WordPress (titel = onderwerp) ---------- */
add_action('init', function () {
	register_post_type('ft4a_promomail', [
		'labels' => ['name' => 'Promotiemail-teksten', 'singular_name' => 'Promotiemail-tekst', 'menu_name' => 'Promotiemail-teksten', 'all_items' => 'Promotiemail-teksten', 'edit_item' => 'Promotiemail-tekst bewerken', 'add_new_item' => 'Nieuwe promotiemail-tekst', 'add_new' => 'Nieuwe tekst', 'search_items' => 'Teksten zoeken', 'not_found' => 'Geen teksten gevonden'],
		'public' => false, 'show_ui' => true, 'show_in_menu' => false, 'show_in_rest' => false, 'show_in_admin_bar' => false,
		'supports' => ['title', 'editor', 'revisions'], 'capability_type' => 'page', 'map_meta_cap' => true, 'rewrite' => false, 'query_var' => false,
	]);
});
add_filter('manage_ft4a_promomail_posts_columns', function ($c) {
	return ['cb' => $c['cb'] ?? '', 'title' => 'Onderwerp', 'ft4a_taal' => 'Taal', 'date' => $c['date'] ?? 'Datum'];
});
add_action('manage_ft4a_promomail_posts_custom_column', function ($col, $id) {
	if ($col !== 'ft4a_taal') return;
	$l = (string) get_post_meta($id, '_ft4a_lang', true);
	echo esc_html(FT4A_LANGS[$l][3] ?? $l);
}, 10, 2);
add_action('pre_get_posts', function ($q) {
	if (is_admin() && $q->is_main_query() && $q->get('post_type') === 'ft4a_promomail' && !$q->get('orderby')) { $q->set('orderby', 'menu_order'); $q->set('order', 'ASC'); }
});
add_action('add_meta_boxes_ft4a_promomail', function () {
	add_meta_box('ft4a_promo_uitleg', 'Taal en uitleg', function ($post) {
		$l = (string) get_post_meta($post->ID, '_ft4a_lang', true);
		echo '<p><strong>Taal:</strong> ' . esc_html(FT4A_LANGS[$l][3] ?? '—') . '</p>'
			. '<p>De titel is het onderwerp van de mail. In de tekst wordt <code>{voornaam}</code> de voornaam van de ontvanger en wordt <code>{knop}</code> (op een eigen regel) de groene knop naar FT4A.com, in de taal van de ontvanger.</p>'
			. '<p>Onderaan komt automatisch waarom iemand de mail krijgt en de afmeldlink. Zonder (gepubliceerde) tekst in een taal gaat de Engelse tekst.</p>'
			. '<p><a href="' . esc_url(admin_url('admin.php?page=ft4a-promo')) . '">← Terug naar Promotiemail</a></p>';
	}, null, 'side', 'high');
});
add_action('admin_menu', function () {
	add_submenu_page('ft4a', 'Promotiemail', 'Promotiemail', 'manage_options', 'ft4a-promo', 'ft4a_promo_page');
	add_submenu_page('ft4a', 'Promotiemail-teksten', 'Promotiemail-teksten', 'manage_options', 'edit.php?post_type=ft4a_promomail');
}, 24);
add_filter('parent_file', function ($p) {
	$s = function_exists('get_current_screen') ? get_current_screen() : null;
	return ($s && $s->post_type === 'ft4a_promomail') ? 'ft4a' : $p;
});

/* Beginteksten (site/promo.json) eenmalig als berichten aanmaken; aangepaste teksten blijven altijd staan */
function ft4a_promo_seed_texts() {
	if (get_option('ft4a_promo_teksten') === 'v1') return;
	$def = json_decode((string) @file_get_contents(FT4A_DIR . 'site/promo.json'), true);
	if (!is_array($def)) return;
	$have = [];
	foreach (get_posts(['post_type' => 'ft4a_promomail', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'suppress_filters' => true]) as $id) $have[(string) get_post_meta($id, '_ft4a_lang', true)] = $id;
	$i = 0;
	foreach (FT4A_LANGS as $code => $l) {
		$i++;
		if (isset($have[$code]) || empty($def[$code]['onderwerp']) || empty($def[$code]['tekst'])) continue;
		$id = wp_insert_post(wp_slash(['post_type' => 'ft4a_promomail', 'post_status' => 'publish', 'post_title' => $def[$code]['onderwerp'], 'post_content' => $def[$code]['tekst'], 'menu_order' => $i]));
		if ($id && !is_wp_error($id)) update_post_meta($id, '_ft4a_lang', $code);
	}
	update_option('ft4a_promo_teksten', 'v1');
}
add_action('admin_init', 'ft4a_promo_seed_texts', 20);

function ft4a_promo_post($lang) {
	$ids = get_posts(['post_type' => 'ft4a_promomail', 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_ft4a_lang', 'meta_value' => $lang, 'orderby' => 'ID', 'order' => 'ASC', 'suppress_filters' => true]);
	return $ids ? get_post($ids[0]) : null;
}
/* Tekst voor een taal; zonder gepubliceerde tekst: Engels */
function ft4a_promo_text($lang) {
	static $c = [];
	if (array_key_exists($lang, $c)) return $c[$lang];
	$p = ft4a_promo_post($lang);
	if ($p && trim($p->post_title) !== '' && trim(wp_strip_all_tags($p->post_content)) !== '') return $c[$lang] = ['lang' => $lang, 'onderwerp' => $p->post_title, 'tekst' => $p->post_content];
	return $c[$lang] = ($lang === 'en' ? null : ft4a_promo_text('en'));
}

/* ---------- Eén promotiemail versturen (in de taal van de ontvanger, FT4A-opmaak via WooCommerce) ---------- */
function ft4a_promo_mail($row, $to = '') {
	if (!function_exists('WC')) return new WP_Error('wc', 'WooCommerce is niet actief.');
	$tx = ft4a_promo_text(ft4a_promo_lang($row->taal));
	if (!$tx) return new WP_Error('tekst', 'Er is geen tekst voor deze taal en ook geen Engelse tekst.');
	$lang = isset(FT4A_LANGS[$tx['lang']]) ? $tx['lang'] : 'en';
	$GLOBALS['ft4a_lang_stack'][] = $lang;
	$sw = switch_to_locale(FT4A_LANGS[$lang][1]);
	$err = '';
	$vang = function ($e) use (&$err) { if (is_wp_error($e)) $err = $e->get_error_message(); };
	add_action('wp_mail_failed', $vang);
	try {
		$afmeld = add_query_arg('ft4a_afmelden', $row->token, home_url('/'));
		$first = ft4a_promo_naam($row->voornaam ?? '');
		$tekst = str_replace(["\r\n", "\r"], "\n", (string) $tx['tekst']);
		$tekst = $first !== '' ? str_replace('{voornaam}', esc_html($first), $tekst) : preg_replace('/,?[ \t]*\{voornaam\}/u', '', $tekst);
		$knop = '<a class="ft4a-btn" href="' . esc_url(ft4a_url('home', $lang)) . '" style="display:inline-block;background-color:#16924f;color:#ffffff;text-decoration:none;font-weight:700;font-size:15px;line-height:1;padding:15px 26px;border-radius:12px">' . esc_html(ft4a_t('Ontdek FT4A.com')) . '</a>';
		$tekst = str_replace('{knop}', $knop, $tekst);
		$tekst = rtrim($tekst) . "\n\n" . '<p style="font-size:12px;line-height:1.6;color:#6b7a72;margin:28px 0 0;padding-top:14px;border-top:1px solid #e4ece7">'
			. esc_html(ft4a_t('Je krijgt deze e-mail omdat je een account had op footballtraining4all.com, de vorige website van FT4A.')) . ' '
			. esc_html(ft4a_t('Geen e-mails meer ontvangen?')) . ' <a href="' . esc_url($afmeld) . '" style="color:#6b7a72;text-decoration:underline">' . esc_html(ft4a_t('Afmelden')) . '</a></p>';
		/* Arabisch altijd van rechts naar links, ook als het taalpakket van WordPress ontbreekt */
		if ($lang === 'ar') $tekst = '<div dir="rtl" style="direction:rtl;text-align:right">' . "\n\n" . $tekst . "\n\n</div>";
		$onderwerp = trim(wp_strip_all_tags($tx['onderwerp']));
		$headers = "Content-Type: text/html; charset=UTF-8\r\n"
			. 'List-Unsubscribe: <' . esc_url_raw($afmeld) . '>, <mailto:' . FT4A_MAIL_FROM . "?subject=Afmelden>\r\n"
			. "List-Unsubscribe-Post: List-Unsubscribe=One-Click\r\n";
		$mailer = WC()->mailer();
		$ok = (bool) $mailer->send($to ?: $row->email, $onderwerp, $mailer->wrap_message($onderwerp, $tekst), $headers);
	} catch (\Throwable $e) { $ok = false; $err = $e->getMessage(); }
	remove_action('wp_mail_failed', $vang);
	if ($sw) restore_previous_locale();
	array_pop($GLOBALS['ft4a_lang_stack']);
	return $ok ? true : new WP_Error('mail', $err ?: 'De mail kon niet verstuurd worden.');
}

/* ---------- Pakjes versturen via WP-Cron ---------- */
add_filter('cron_schedules', function ($s) {
	$m = ft4a_promo_minuten();
	$s['ft4a_promo'] = ['interval' => $m * MINUTE_IN_SECONDS, 'display' => 'FT4A promotiemail (elke ' . $m . ' minuten)'];
	return $s;
});
add_action('ft4a_promo_tick', 'ft4a_promo_run');
add_action('init', function () {
	if (get_option('ft4a_promo_aan') && !wp_next_scheduled('ft4a_promo_tick')) wp_schedule_event(time() + MINUTE_IN_SECONDS, 'ft4a_promo', 'ft4a_promo_tick');
}, 31);

function ft4a_promo_start() {
	update_option('ft4a_promo_aan', 1);
	delete_option('ft4a_promo_melding');
	wp_clear_scheduled_hook('ft4a_promo_tick');
	wp_schedule_event(time() + MINUTE_IN_SECONDS, 'ft4a_promo', 'ft4a_promo_tick');
}
function ft4a_promo_stop($melding = '') {
	update_option('ft4a_promo_aan', 0);
	wp_clear_scheduled_hook('ft4a_promo_tick');
	if ($melding !== '') update_option('ft4a_promo_melding', ['at' => time(), 'tekst' => $melding], false);
}

function ft4a_promo_run() {
	global $wpdb;
	if (!get_option('ft4a_promo_aan')) { wp_clear_scheduled_hook('ft4a_promo_tick'); return 0; }
	if (!function_exists('WC')) return 0;
	if (get_transient('ft4a_promo_lock')) return -1;
	set_transient('ft4a_promo_lock', 1, 5 * MINUTE_IN_SECONDS);
	$t = ft4a_promo_table();
	$n = ft4a_promo_aantal();
	$sent = 0; $fail = 0; $fout = '';
	$rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE status = %s ORDER BY id ASC LIMIT %d", 'wachtrij', $n * 4));
	foreach ((array) $rows as $r) {
		if ($sent + $fail >= $n) break;
		if (!is_email($r->email)) { ft4a_promo_set($r->id, 'mislukt', 'Ongeldig e-mailadres'); continue; }
		if (email_exists($r->email)) { ft4a_promo_set($r->id, 'overgeslagen', 'Heeft een account op ft4a.com'); continue; }
		$res = ft4a_promo_mail($r);
		if ($res === true) { ft4a_promo_set($r->id, 'verzonden'); $sent++; }
		else { $fout = $res->get_error_message(); ft4a_promo_set($r->id, 'mislukt', $fout); $fail++; }
	}
	$left = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE status = %s", 'wachtrij'));
	update_option('ft4a_promo_laatst', ['at' => time(), 'sent' => $sent, 'fail' => $fail], false);
	if ($fail && !$sent && $fail >= min(3, $n)) {
		ft4a_promo_stop('Automatisch gepauzeerd: ' . $fail . ' mails na elkaar mislukt (' . $fout . '). Los het probleem op, zet de mislukte adressen opnieuw in de wachtrij en start opnieuw.');
	} elseif (!$left) {
		ft4a_promo_stop('Klaar: alle adressen uit de wachtrij hebben de promotiemail gekregen.');
		wp_mail(FT4A_MAIL_TO, 'FT4A: promotiemail volledig verstuurd', "De promotiemail is naar alle adressen in de wachtrij verstuurd.\n\nOverzicht: " . admin_url('admin.php?page=ft4a-promo'));
	}
	delete_transient('ft4a_promo_lock');
	return $sent;
}

/* ---------- Adressen importeren (CSV met kolommen e-mail, voornaam, achternaam, land, taal) ---------- */
function ft4a_promo_import($rows) {
	global $wpdb;
	$t = ft4a_promo_table();
	$res = ['nieuw' => 0, 'bestaat' => 0, 'account' => 0, 'ongeldig' => 0];
	$pick = function ($row, $keys) {
		foreach ($keys as $k) if (isset($row[$k]) && trim((string) $row[$k]) !== '') return trim((string) $row[$k]);
		return '';
	};
	$kort = function ($s) { return mb_substr(sanitize_text_field($s), 0, 100); };
	foreach ($rows as $row) {
		$email = sanitize_email($pick($row, ['e-mailadres', 'email', 'e-mail', 'emailadres', 'mail', 'e-mail address']));
		if (!$email || !is_email($email)) { $res['ongeldig']++; continue; }
		$acc = email_exists($email) ? 1 : 0;
		$ok = $wpdb->query($wpdb->prepare(
			"INSERT IGNORE INTO $t (email, voornaam, achternaam, land, taal, status, token, toegevoegd, fout) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
			$email,
			$kort($pick($row, ['voornaam', 'first name', 'firstname'])),
			$kort($pick($row, ['achternaam', 'last name', 'lastname', 'naam'])),
			$kort($pick($row, ['land', 'country'])),
			ft4a_promo_lang($pick($row, ['taal', 'taalcode', 'language', 'lang'])),
			$acc ? 'overgeslagen' : 'wachtrij',
			bin2hex(random_bytes(16)),
			current_time('mysql'),
			$acc ? 'Heeft een account op ft4a.com' : ''
		));
		if ($ok) $res[$acc ? 'account' : 'nieuw']++; else $res['bestaat']++;
	}
	return $res;
}

/* ---------- Afmelden: https://ft4a.com/?ft4a_afmelden=<code> (pagina met knop; met één klik via List-Unsubscribe-Post) ---------- */
add_action('init', function () {
	if (!isset($_GET['ft4a_afmelden'])) return;
	ft4a_promo_afmelden(sanitize_key(wp_unslash($_GET['ft4a_afmelden'])));
	exit;
}, 1);
function ft4a_promo_afmelden($token) {
	global $wpdb;
	nocache_headers();
	do_action('litespeed_control_set_nocache', 'ft4a: afmelden promotiemail');
	header('X-Robots-Tag: noindex, nofollow', true);
	$row = strlen($token) === 32 ? $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ft4a_promo_table() . ' WHERE token = %s', $token)) : null;
	$lang = $row ? ft4a_promo_lang($row->taal) : (function_exists('ft4a_browser_lang') ? (ft4a_browser_lang() ?: 'en') : 'en');
	if (!isset(FT4A_LANGS[$lang])) $lang = 'en';
	$post = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST';
	if ($row && $post && $row->status !== 'afgemeld') ft4a_promo_set($row->id, 'afgemeld');
	$GLOBALS['ft4a_lang_stack'][] = $lang;
	$home = ft4a_url('home', $lang);
	if (!$row) {
		$titel = ft4a_t('Deze link werkt niet meer');
		$inhoud = '<p>' . esc_html(ft4a_t('Deze afmeldlink is niet (meer) geldig. Wil je geen e-mails meer ontvangen? Stuur dan een e-mail naar info@ft4a.com.')) . '</p><p><a class="btn" href="' . esc_url($home) . '">' . esc_html(ft4a_t('Naar FT4A.com')) . '</a></p>';
	} elseif ($post || $row->status === 'afgemeld') {
		$titel = ft4a_t('Je bent afgemeld');
		$inhoud = '<p>' . esc_html(sprintf(ft4a_t('Je krijgt geen e-mails van FT4A.com meer op %s.'), $row->email)) . '</p><p><a class="btn" href="' . esc_url($home) . '">' . esc_html(ft4a_t('Naar FT4A.com')) . '</a></p>';
	} else {
		$titel = ft4a_t('Afmelden');
		$inhoud = '<p>' . esc_html(sprintf(ft4a_t('Wil je geen e-mails van FT4A.com meer ontvangen op %s?'), $row->email)) . '</p><form method="post" action="' . esc_url(add_query_arg('ft4a_afmelden', $row->token, home_url('/'))) . '"><button type="submit" class="btn">' . esc_html(ft4a_t('Afmelden')) . '</button></form>';
	}
	array_pop($GLOBALS['ft4a_lang_stack']);
	status_header($row ? 200 : 404);
	header('Content-Type: text/html; charset=utf-8');
	$logo = plugins_url('assets/logo-180.png', FT4A_DIR . 'ft4a-leden.php');
	echo '<!doctype html><html lang="' . esc_attr(FT4A_LANGS[$lang][2]) . '" dir="' . ($lang === 'ar' ? 'rtl' : 'ltr') . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . esc_html($titel) . ' – FT4A.com</title>'
		. '<style>body{margin:0;background:#eef3f0;color:#1d2a23;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}.wrap{max-width:520px;margin:48px auto;padding:0 16px}.card{background:#fff;border:1px solid #d7e3dc;border-radius:20px;overflow:hidden;box-shadow:0 12px 32px rgba(15,40,28,.10)}.head{background:#17241e;border-bottom:4px solid #62dc9e;padding:18px 26px}.head a{display:inline-flex;align-items:center;gap:12px;color:#fff;text-decoration:none;font-size:22px;font-weight:800;letter-spacing:-.3px}.head img{width:40px;height:40px;border-radius:10px}.head b{color:#e3342f}.head i{font-style:normal;color:#1f9d55}.body{padding:28px 26px 30px}h1{margin:0 0 12px;font-size:24px;line-height:1.25;color:#0f1f17}p{margin:0 0 16px;font-size:15px;line-height:1.6;color:#3d4a43;overflow-wrap:anywhere}.btn{display:inline-block;background:#16924f;color:#fff;border:0;border-radius:12px;padding:14px 24px;font:inherit;font-size:15px;font-weight:700;text-decoration:none;cursor:pointer}</style></head>'
		. '<body><div class="wrap"><div class="card"><div class="head"><a href="' . esc_url($home) . '"><img src="' . esc_url($logo) . '" alt="">FT<b>4</b>A<i>.com</i></a></div><div class="body"><h1>' . esc_html($titel) . '</h1>' . $inhoud . '</div></div></div></body></html>';
}

/* ---------- Beheer: FT4A → Promotiemail ---------- */
add_action('admin_post_ft4a_promo', function () {
	if (!current_user_can('manage_options')) wp_die('Geen toegang.');
	check_admin_referer('ft4a_promo');
	global $wpdb;
	ft4a_promo_install();
	$t = ft4a_promo_table();
	$doe = sanitize_key($_POST['doe'] ?? '');
	$msg = '';
	if ($doe === 'start') {
		$n = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE status = %s", 'wachtrij'));
		if (!$n) $msg = 'De wachtrij is leeg: importeer eerst een lijst.';
		elseif (!function_exists('WC')) $msg = 'WooCommerce is niet actief: zonder WooCommerce kan de site de mails niet in de FT4A-opmaak versturen.';
		elseif (!ft4a_promo_text('en')) $msg = 'Er is geen (gepubliceerde) Engelse tekst. Die is nodig voor talen zonder eigen tekst.';
		else { ft4a_promo_start(); $msg = 'De verzending is gestart. Het eerste pakje vertrekt binnen enkele minuten.'; }
	} elseif ($doe === 'pauze') {
		ft4a_promo_stop();
		$msg = 'De verzending is gepauzeerd. Er vertrekt niets meer tot je opnieuw op Start klikt.';
	} elseif ($doe === 'instellingen') {
		update_option('ft4a_promo_aantal', max(1, min(50, (int) ($_POST['aantal'] ?? 5))));
		update_option('ft4a_promo_minuten', max(5, min(1440, (int) ($_POST['minuten'] ?? 15))));
		if (get_option('ft4a_promo_aan')) ft4a_promo_start();
		$msg = 'Bewaard: ' . ft4a_promo_aantal() . ' mails om de ' . ft4a_promo_minuten() . ' minuten.';
	} elseif ($doe === 'test') {
		$u = wp_get_current_user();
		$naar = sanitize_email(wp_unslash($_POST['naar'] ?? '')) ?: $u->user_email;
		$keuze = sanitize_text_field(wp_unslash($_POST['taal'] ?? 'nl'));
		$talen = $keuze === 'alle' ? array_keys(FT4A_LANGS) : [ft4a_promo_lang($keuze)];
		$ok = 0; $fout = '';
		foreach ($talen as $l) {
			$res = ft4a_promo_mail((object) ['email' => $naar, 'voornaam' => $u->first_name ?: $u->display_name, 'taal' => $l, 'token' => str_repeat('0', 32)], $naar);
			if ($res === true) $ok++; else $fout = $res->get_error_message();
		}
		$msg = $ok . ' testmail' . ($ok === 1 ? '' : 's') . ' verstuurd naar ' . $naar . '.' . ($fout ? ' Fout: ' . $fout : '');
	} elseif ($doe === 'import') {
		$f = $_FILES['lijst']['tmp_name'] ?? '';
		if (!$f || !is_uploaded_file($f)) $msg = 'Kies eerst een CSV-bestand.';
		else {
			$r = ft4a_promo_import(ft4a_import_rows($f));
			$msg = sprintf('Import: %d adressen in de wachtrij gezet, %d stonden al in de lijst, %d hebben al een account op ft4a.com (overgeslagen), %d ongeldig.', $r['nieuw'], $r['bestaat'], $r['account'], $r['ongeldig']);
		}
	} elseif ($doe === 'opnieuw') {
		$k = (int) $wpdb->query($wpdb->prepare("UPDATE $t SET status = %s, fout = '' WHERE status = %s", 'wachtrij', 'mislukt'));
		$msg = $k . ' mislukte adressen staan opnieuw in de wachtrij.';
	} elseif ($doe === 'afmelden') {
		$e = sanitize_email(wp_unslash($_POST['email'] ?? ''));
		if (!$e || !is_email($e)) $msg = 'Geef een geldig e-mailadres.';
		else {
			$id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE email = %s", $e));
			if ($id) ft4a_promo_set($id, 'afgemeld', 'Afgemeld door de beheerder');
			else $wpdb->insert($t, ['email' => $e, 'taal' => 'en', 'status' => 'afgemeld', 'token' => bin2hex(random_bytes(16)), 'toegevoegd' => current_time('mysql'), 'afgemeld' => current_time('mysql'), 'fout' => 'Afgemeld door de beheerder']);
			$msg = $e . ' is afgemeld en krijgt geen promotiemail.';
		}
	} elseif ($doe === 'leegmaken') {
		$k = (int) $wpdb->query($wpdb->prepare("DELETE FROM $t WHERE status = %s", 'wachtrij'));
		$msg = $k . ' adressen uit de wachtrij verwijderd. Verstuurde en afgemelde adressen blijven bewaard.';
	}
	wp_safe_redirect(add_query_arg('r', rawurlencode($msg), admin_url('admin.php?page=ft4a-promo')));
	exit;
});

function ft4a_promo_form($doe, $inner, $extra = '', $style = 'display:inline-block;margin:0 8px 8px 0') {
	return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="' . esc_attr($style) . '"' . $extra . '><input type="hidden" name="action" value="ft4a_promo"><input type="hidden" name="doe" value="' . esc_attr($doe) . '">' . wp_nonce_field('ft4a_promo', '_wpnonce', true, false) . $inner . '</form>';
}

function ft4a_promo_page() {
	global $wpdb;
	if (!current_user_can('manage_options')) return;
	ft4a_promo_install();
	ft4a_promo_seed_texts();
	$t = ft4a_promo_table();
	$cnt = array_fill_keys(array_keys(FT4A_PROMO_STATUS), 0);
	foreach ((array) $wpdb->get_results("SELECT status, COUNT(*) AS n FROM $t GROUP BY status") as $x) $cnt[$x->status] = (int) $x->n;
	$aan = (bool) get_option('ft4a_promo_aan');
	$n = ft4a_promo_aantal();
	$m = ft4a_promo_minuten();
	$last = get_option('ft4a_promo_laatst');
	$next = wp_next_scheduled('ft4a_promo_tick');
	$mel = get_option('ft4a_promo_melding');
	$dt = function ($ts) { return esc_html(wp_date('j M Y H:i', $ts)); };
	$md = function ($v) { return $v ? esc_html(mysql2date('j M Y H:i', $v)) : '—'; };

	echo '<div class="wrap"><h1>Promotiemail</h1>';
	echo '<p style="max-width:860px">Een promotiemail voor oude accounts van footballtraining4all.com. Zolang de verzending aan staat, vertrekt er elke <strong>' . $m . ' minuten</strong> een pakje van <strong>' . $n . ' mails</strong>, in de taal van de ontvanger en in de FT4A-opmaak, vanaf info@ft4a.com. Onderaan elke mail staat waarom iemand de mail krijgt en een afmeldlink. Wie zich afmeldt of al een account op ft4a.com heeft, krijgt niets. Er vertrekt niets tot je op <strong>Verzending starten</strong> klikt; zolang de verzending aan staat, gaan ook nieuw geïmporteerde adressen mee.</p>';
	if (!empty($_GET['r'])) echo '<div class="notice notice-info is-dismissible"><p>' . esc_html(rawurldecode(wp_unslash($_GET['r']))) . '</p></div>';
	if (is_array($mel) && !empty($mel['tekst'])) echo '<div class="notice notice-' . (strpos($mel['tekst'], 'Klaar') === 0 ? 'success' : 'warning') . '"><p>' . $dt($mel['at']) . ': ' . esc_html($mel['tekst']) . '</p></div>';
	if (!function_exists('WC')) echo '<div class="notice notice-error"><p>WooCommerce is niet actief. De promotiemail gebruikt de mailopmaak van WooCommerce en kan zonder WooCommerce niet vertrekken.</p></div>';

	/* Verzending */
	echo '<h2>Verzending</h2><table class="widefat striped" style="max-width:860px"><tbody>';
	echo '<tr><th style="width:230px">Status</th><td>' . ($aan ? '<strong style="color:#16924f">Bezig</strong>' : '<strong style="color:#b32d2e">Gepauzeerd</strong>') . '</td></tr>';
	$st = [];
	foreach (FT4A_PROMO_STATUS as $k => $lab) $st[] = esc_html($lab) . ': <strong>' . number_format_i18n($cnt[$k]) . '</strong>';
	echo '<tr><th>Adressen</th><td>' . implode(' &nbsp;·&nbsp; ', $st) . '</td></tr>';
	echo '<tr><th>Laatste pakje</th><td>' . (is_array($last) ? $dt($last['at']) . ' (' . (int) $last['sent'] . ' verstuurd' . (!empty($last['fail']) ? ', ' . (int) $last['fail'] . ' mislukt' : '') . ')' : 'nog geen') . '</td></tr>';
	if ($aan) {
		echo '<tr><th>Volgende pakje</th><td>' . ($next ? $dt($next) : '—') . '</td></tr>';
		if ($next && $cnt['wachtrij']) {
			$eind = $next + (int) (ceil($cnt['wachtrij'] / $n) - 1) * $m * MINUTE_IN_SECONDS;
			echo '<tr><th>Alles verstuurd rond</th><td>' . $dt($eind) . '</td></tr>';
		}
		if ($next && $next < time() - 10 * MINUTE_IN_SECONDS) echo '<tr><th>Let op</th><td>Het volgende pakje is te laat. WordPress voert geplande taken pas uit bij een bezoek aan de site. Een cronjob bij Cloud86 die elke ' . $m . ' minuten <code>' . esc_html(site_url('wp-cron.php')) . '</code> oproept, maakt het stipt.</td></tr>';
	}
	echo '</tbody></table><p>';
	echo $aan
		? ft4a_promo_form('pauze', '<button class="button button-secondary">Pauzeren</button>')
		: ft4a_promo_form('start', '<button class="button button-primary"' . ($cnt['wachtrij'] ? '' : ' disabled') . '>Verzending starten</button>', ' onsubmit="return confirm(\'De verzending starten? Elke ' . $m . ' minuten vertrekken er ' . $n . ' mails naar de adressen in de wachtrij.\')"');
	echo '</p>';
	echo ft4a_promo_form('instellingen', '<label>Pakje: <input type="number" name="aantal" min="1" max="50" value="' . $n . '" style="width:64px"> mails</label> &nbsp; <label>om de <input type="number" name="minuten" min="5" max="1440" value="' . $m . '" style="width:72px"> minuten</label> &nbsp; <button class="button">Bewaren</button>', '', 'margin:4px 0 0') . '<p class="description">Cloud86 laat maximaal 250 mails per uur toe voor de hele site, ook voor bestellingen en licenties. Hou de promotiemail daarom ruim onder die grens.</p>';

	/* Testmail */
	$opts = '<option value="alle">Alle 18 talen</option>';
	foreach (FT4A_LANGS as $code => $l) $opts .= '<option value="' . esc_attr($code) . '"' . selected($code, 'nl', false) . '>' . esc_html($l[3]) . '</option>';
	echo '<h2 style="margin-top:28px">Testmail</h2>' . ft4a_promo_form('test', '<label>Taal <select name="taal">' . $opts . '</select></label> &nbsp; <label>naar <input type="email" name="naar" value="' . esc_attr(wp_get_current_user()->user_email) . '" style="width:260px"></label> &nbsp; <button class="button">Testmail versturen</button>', '', 'margin:0') . '<p class="description">De testmail is precies de mail die de ontvangers krijgen (met jouw voornaam). De afmeldlink in een testmail werkt niet.</p>';

	/* Import */
	echo '<h2 style="margin-top:28px">Adressen importeren</h2>' . ft4a_promo_form('import', '<input type="file" name="lijst" accept=".csv,text/csv"> <button class="button">Importeren</button>', ' enctype="multipart/form-data"', 'margin:0') . '<p class="description">CSV-bestand met de kolommen <code>email</code> (verplicht), <code>voornaam</code>, <code>achternaam</code>, <code>land</code> en <code>taal</code> (bv. nl, fr, pt-br, of Nederlands, Frans …). Komma of puntkomma als scheidingsteken. Adressen die al in de lijst staan (ook afgemelde) worden niet opnieuw toegevoegd.</p>';

	/* Teksten */
	$ws = [];
	foreach ((array) $wpdb->get_results($wpdb->prepare("SELECT taal, COUNT(*) AS n FROM $t WHERE status = %s GROUP BY taal", 'wachtrij')) as $x) $ws[$x->taal] = (int) $x->n;
	$by = [];
	foreach (get_posts(['post_type' => 'ft4a_promomail', 'post_status' => ['publish', 'draft', 'pending', 'private'], 'numberposts' => -1, 'suppress_filters' => true]) as $p) {
		$l = (string) get_post_meta($p->ID, '_ft4a_lang', true);
		if (!isset($by[$l]) || $p->post_status === 'publish') $by[$l] = $p;
	}
	echo '<h2 style="margin-top:28px">Teksten</h2><p class="description" style="max-width:860px">Klik op Bewerken om het onderwerp of de tekst van een taal aan te passen. <code>{voornaam}</code> wordt de voornaam, <code>{knop}</code> de knop naar FT4A.com.</p><table class="widefat striped" style="max-width:860px"><thead><tr><th>Taal</th><th>Onderwerp</th><th>In de wachtrij</th><th></th></tr></thead><tbody>';
	foreach (FT4A_LANGS as $code => $l) {
		$p = $by[$code] ?? null;
		$sub = $p ? esc_html($p->post_title) . ($p->post_status !== 'publish' ? ' <em>(niet gepubliceerd: de Engelse tekst wordt gebruikt)</em>' : '') : '<em>geen tekst: de Engelse tekst wordt gebruikt</em>';
		echo '<tr><td>' . esc_html($l[3]) . '</td><td>' . $sub . '</td><td>' . number_format_i18n($ws[$code] ?? 0) . '</td><td>' . ($p ? '<a href="' . esc_url(get_edit_post_link($p->ID)) . '">Bewerken</a>' : '') . '</td></tr>';
	}
	echo '</tbody></table>';

	/* Laatst verstuurd, afgemeld en mislukt */
	$lijst = function ($titel, $sql, $kolom) use ($wpdb, $md) {
		$rows = $wpdb->get_results($sql);
		echo '<h2 style="margin-top:28px">' . esc_html($titel) . '</h2><table class="widefat striped" style="max-width:860px"><thead><tr><th style="width:150px">Wanneer</th><th>E-mail</th><th style="width:70px">Taal</th><th>Opmerking</th></tr></thead><tbody>';
		if (!$rows) echo '<tr><td colspan="4">Nog niets.</td></tr>';
		foreach ((array) $rows as $r) echo '<tr><td>' . $md($r->$kolom) . '</td><td>' . esc_html($r->email) . '</td><td>' . esc_html(strtoupper($r->taal)) . '</td><td>' . esc_html($r->fout) . '</td></tr>';
		echo '</tbody></table>';
	};
	$lijst('Laatst verstuurd', "SELECT email, taal, fout, verzonden FROM $t WHERE status = 'verzonden' ORDER BY verzonden DESC, id DESC LIMIT 30", 'verzonden');
	$lijst('Afgemeld', "SELECT email, taal, fout, afgemeld FROM $t WHERE status = 'afgemeld' ORDER BY afgemeld DESC, id DESC LIMIT 30", 'afgemeld');
	if ($cnt['mislukt']) $lijst('Mislukt', "SELECT email, taal, fout, toegevoegd FROM $t WHERE status = 'mislukt' ORDER BY id DESC LIMIT 30", 'toegevoegd');

	/* Beheer */
	echo '<h2 style="margin-top:28px">Beheer</h2><p>';
	echo ft4a_promo_form('afmelden', '<input type="email" name="email" placeholder="e-mailadres" style="width:240px" required> <button class="button">Adres afmelden</button>');
	if ($cnt['mislukt']) echo ft4a_promo_form('opnieuw', '<button class="button">Mislukte adressen opnieuw in de wachtrij</button>');
	if ($cnt['wachtrij']) echo ft4a_promo_form('leegmaken', '<button class="button button-link-delete">Wachtrij leegmaken</button>', ' onsubmit="return confirm(\'Alle ' . (int) $cnt['wachtrij'] . ' adressen die nog niet verstuurd zijn uit de wachtrij verwijderen?\')"');
	echo '</p><p class="description">Vraagt iemand per mail om geen e-mails meer te krijgen? Vul het adres in bij Adres afmelden.</p></div>';
}

<?php
/* FT4A: meertaligheid. Nederlands staat op de root, de andere talen onder een prefix (/fr/, /en-us/ …). */
if (!defined('ABSPATH')) exit;

// code => [prefix, wp-locale, html-lang, naam, vlag, code op footballtraining4all.com, korte code]
const FT4A_LANGS = [
	'nl'    => ['',      'nl_NL', 'nl',    'Nederlands',     'f-nl', 'nl-nl',  'NL'],
	'en'    => ['en',    'en_GB', 'en-GB', 'English (UK)',   'f-gb', 'en-gb',  'EN'],
	'en-us' => ['en-us', 'en_US', 'en-US', 'English (US)',   'f-us', 'en-us',  'US'],
	'fr'    => ['fr',    'fr_FR', 'fr',    'Français',       'f-fr', 'fr-fr',  'FR'],
	'de'    => ['de',    'de_DE', 'de',    'Deutsch',        'f-de', 'de-de',  'DE'],
	'es'    => ['es',    'es_ES', 'es',    'Español',        'f-es', 'es-es',  'ES'],
	'it'    => ['it',    'it_IT', 'it',    'Italiano',       'f-it', 'it-it',  'IT'],
	'pt'    => ['pt',    'pt_PT', 'pt-PT', 'Português',      'f-pt', 'pt-pt',  'PT'],
	'pt-br' => ['pt-br', 'pt_BR', 'pt-BR', 'Português (BR)', 'f-br', 'pt-br',  'BR'],
	'da'    => ['da',    'da_DK', 'da',    'Dansk',          'f-dk', 'da-dk',  'DA'],
	'sv'    => ['sv',    'sv_SE', 'sv',    'Svenska',        'f-se', 'sv-se',  'SV'],
	'fi'    => ['fi',    'fi',    'fi',    'Finnish',        'f-fi', 'se-fi',  'FI'],
	'no'    => ['no',    'nb_NO', 'nb',    'Norwegian',      'f-no', 'smj-no', 'NO'],
	'pl'    => ['pl',    'pl_PL', 'pl',    'Polski',         'f-pl', 'pl-pl',  'PL'],
	'tr'    => ['tr',    'tr_TR', 'tr',    'Türkçe',         'f-tr', 'tr-tr',  'TR'],
	'ru'    => ['ru',    'ru_RU', 'ru',    'Русский',        'f-ru', 'ru-ru',  'RU'],
	'ro'    => ['ro',    'ro_RO', 'ro',    'Română',         'f-ro', 'en-gb',  'RO'],
	'ar'    => ['ar',    'ar',    'ar',    'العربية',        'f-ar', 'en-gb',  'AR'],
];
const FT4A_KEYS = ['oefeningen','software','prijzen','vragen','handleiding','reviews','contact','ledenoefeningen','oefening-toevoegen','account','inloggen','privacy','voorwaarden'];

function ft4a_slugs() {
	static $s = null;
	if ($s === null) $s = json_decode((string) @file_get_contents(__DIR__ . '/site/i18n/slugs.json'), true) ?: [];
	return $s;
}
function ft4a_slug($key, $lang) {
	if ($lang === 'nl') return $key;
	return ft4a_slugs()[$lang][$key] ?? $key;
}
function ft4a_key_from_slug($slug, $lang) {
	if ($lang === 'nl') return in_array($slug, FT4A_KEYS, true) ? $slug : null;
	$k = array_search($slug, ft4a_slugs()[$lang] ?? [], true);
	return $k === false ? null : $k;
}
function ft4a_prefixes() {
	$p = [];
	foreach (FT4A_LANGS as $c => $l) if ($l[0] !== '') $p[$l[0]] = $c;
	return $p;
}
function ft4a_path() {
	$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
	$base = rtrim((string) parse_url(home_url('/'), PHP_URL_PATH), '/');
	if ($base && strpos($uri, $base) === 0) $uri = substr($uri, strlen($base));
	return trim($uri, '/');
}

/* Huidige taal: prefix in de URL > Nederlandse pagina > cookie > Nederlands */
function ft4a_lang() {
	static $lang = null;
	$force = ft4a_force_lang();
	if ($force) return $force;
	if ($lang !== null) return $lang;
	$q = sanitize_key($_GET['lang'] ?? '');
	if ($q !== '' && isset(FT4A_LANGS[$q])) return $lang = $q;
	$path = ft4a_path();
	$seg = explode('/', $path)[0];
	$pre = ft4a_prefixes();
	if (isset($pre[$seg])) return $lang = $pre[$seg];
	$cookie = sanitize_key($_COOKIE['ft4a_lang'] ?? '');
	if (($path === '' && empty($_GET)) || in_array($seg, FT4A_KEYS, true)) return $lang = 'nl';
	return $lang = isset(FT4A_LANGS[$cookie]) ? $cookie : 'nl';
}
function ft4a_old_code() { return FT4A_LANGS[ft4a_lang()][5]; }
function ft4a_is_rtl() { return ft4a_lang() === 'ar'; }

function ft4a_t($s) {
	static $dict = [];
	$lang = ft4a_lang();
	if ($lang === 'nl') return $s;
	if (!isset($dict[$lang])) $dict[$lang] = json_decode((string) @file_get_contents(__DIR__ . '/site/i18n/' . $lang . '/php.json'), true) ?: [];
	return $dict[$lang][$s] ?? $s;
}

function ft4a_url($key, $lang = null) {
	$lang = $lang ?: ft4a_lang();
	$frag = '';
	if (strpos($key, '#') !== false) { [$key, $frag] = explode('#', $key, 2); $frag = '#' . $frag; }
	$pre = FT4A_LANGS[$lang][0];
	$parts = [];
	if ($pre !== '') $parts[] = $pre;
	if ($key !== 'home' && $key !== '') $parts[] = ft4a_slug(trim($key, '/'), $lang);
	return home_url($parts ? '/' . implode('/', $parts) . '/' : '/') . $frag;
}

/* WordPress- en WooCommerce-teksten in de taal van de bezoeker */
/* Taal van een e-mail: tijdelijk vastgezet zolang WordPress/WooCommerce naar de taal van de ontvanger omschakelt */
function ft4a_force_lang() { $st = $GLOBALS['ft4a_lang_stack'] ?? []; return $st ? end($st) : ''; }
function ft4a_lang_for_locale($loc) {
	foreach (FT4A_LANGS as $c => $l) if ($l[1] === $loc) return $c;
	$short = substr((string) $loc, 0, 2);
	foreach (FT4A_LANGS as $c => $l) if (substr($l[1], 0, 2) === $short) return $c;
	return '';
}
add_action('switch_locale', function ($loc) { $GLOBALS['ft4a_lang_stack'][] = ft4a_lang_for_locale($loc) ?: (ft4a_force_lang() ?: 'nl'); });
add_action('restore_previous_locale', function () { if (!empty($GLOBALS['ft4a_lang_stack'])) array_pop($GLOBALS['ft4a_lang_stack']); });
add_action('restore_current_locale', function () { $GLOBALS['ft4a_lang_stack'] = []; });
function ft4a_locale_filter($loc) {
	$force = ft4a_force_lang();
	if ($force) return FT4A_LANGS[$force][1];
	if (is_admin() && !wp_doing_ajax()) return $loc;
	if (defined('REST_REQUEST') && REST_REQUEST) return $loc;
	$l = ft4a_lang();
	return $l === 'nl' ? $loc : FT4A_LANGS[$l][1];
}
add_filter('locale', 'ft4a_locale_filter', 99);
add_filter('determine_locale', 'ft4a_locale_filter', 99);

/* Routes voor de andere talen */
add_filter('query_vars', function ($v) { $v[] = 'ft4a_lang'; $v[] = 'ft4a_slug'; return $v; });
add_action('init', function () {
	$re = implode('|', array_map('preg_quote', array_keys(ft4a_prefixes())));
	add_rewrite_rule('^(' . $re . ')/?$', 'index.php?ft4a_lang=$matches[1]', 'top');
	add_rewrite_rule('^(' . $re . ')/([^/]+)/?$', 'index.php?ft4a_lang=$matches[1]&ft4a_slug=$matches[2]', 'top');
}, 5);
add_filter('redirect_canonical', function ($r) { return get_query_var('ft4a_lang') ? false : $r; });

/* Welke FT4A-pagina wordt getoond? 'home', een sleutel, '404' of null (geen FT4A-pagina) */
function ft4a_current_key() {
	static $k = false;
	if ($k !== false) return $k;
	if (get_query_var('ft4a_lang')) {
		$slug = get_query_var('ft4a_slug');
		if (!$slug) return $k = 'home';
		return $k = (ft4a_key_from_slug($slug, ft4a_lang()) ?: '404');
	}
	if (is_front_page()) return $k = 'home';
	if (is_404()) return $k = '404';
	if (is_page()) {
		$p = get_queried_object();
		if ($p && get_post_meta($p->ID, '_ft4a_page', true) && in_array($p->post_name, FT4A_KEYS, true)) return $k = $p->post_name;
	}
	return $k = null;
}
function ft4a_site_dir($lang = null) {
	$lang = $lang ?: ft4a_lang();
	return FT4A_DIR . 'site/' . ($lang === 'nl' ? '' : 'i18n/' . $lang . '/');
}
/* Inhoud van een FT4A-pagina uit WordPress (bewerkbaar in de editor); valt terug op het bestand in de plugin. */
function ft4a_page_post($key, $lang = null) {
	$lang = $lang ?: ft4a_lang();
	$ids = get_transient('ft4a_page_ids');
	if (!is_array($ids)) {
		$ids = [];
		foreach (get_posts(['post_type' => 'page', 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => '_ft4a_key']) as $id)
			$ids[get_post_meta($id, '_ft4a_lang', true) . '|' . get_post_meta($id, '_ft4a_key', true)] = $id;
		set_transient('ft4a_page_ids', $ids, DAY_IN_SECONDS);
	}
	$id = $ids[$lang . '|' . $key] ?? 0;
	$p = $id ? get_post($id) : null;
	return ($p && $p->post_status === 'publish') ? $p : null;
}
function ft4a_page_html($key, $lang = null) {
	$p = ft4a_page_post($key, $lang);
	if ($p) return do_shortcode(do_blocks($p->post_content));
	$f = ft4a_site_dir($lang) . ($key === 'home' ? 'home.html' : 'pages/' . $key . '.html');
	return do_shortcode((string) @file_get_contents($f));
}
add_action('save_post_page', function () { delete_transient('ft4a_page_ids'); });
add_action('deleted_post', function () { delete_transient('ft4a_page_ids'); });
add_action('template_redirect', function () {
	if (!is_page() || get_query_var('ft4a_lang')) return;
	$p = get_queried_object();
	if ($p && get_post_meta($p->ID, '_ft4a_key', true) === 'home' && get_post_meta($p->ID, '_ft4a_lang', true) === 'nl') { wp_redirect(home_url('/'), 301); exit; }
}, 0);
function ft4a_page_title($key) {
	static $t = [];
	$lang = ft4a_lang();
	$p = $key !== 'home' ? ft4a_page_post($key, $lang) : null;
	if ($p) return get_the_title($p);
	if (!isset($t[$lang])) $t[$lang] = json_decode((string) @file_get_contents(ft4a_site_dir() . 'pages/index.json'), true) ?: [];
	return $t[$lang][$key] ?? $key;
}

add_action('template_redirect', function () {
	$key = ft4a_current_key();
	if ($key === null) return;
	if ($key === '404' && get_query_var('ft4a_lang')) status_header(404);
}, 1);
/* taalcookie (voor winkelmand, afrekenen en account) via de browser zetten: zo blijven de pagina's cachebaar (LiteSpeed Cache) */
add_action('wp_footer', function () {
	if (ft4a_current_key() === null) return;
	$l = esc_js(ft4a_lang());
	echo '<script>(function(){var l="' . $l . '";if(!new RegExp("(^|; )ft4a_lang="+l+"(;|$)").test(document.cookie))document.cookie="ft4a_lang="+l+";path=/;max-age=31536000;samesite=lax"+(location.protocol==="https:"?";secure":"");})();</script>' . "\n";
}, 99);

add_filter('pre_get_document_title', function ($t) {
	if (!get_query_var('ft4a_lang')) return $t;
	$key = ft4a_current_key();
	if ($key === 'home') return 'FT4A.com – ' . ft4a_t('Software en voetbaloefeningen voor de moderne voetbaltrainer');
	if ($key === '404') return ft4a_t('Deze pagina bestaat niet') . ' – FT4A.com';
	return ft4a_page_title($key) . ' – FT4A.com';
});

add_filter('language_attributes', function ($out) {
	if (is_admin()) return $out;
	return 'lang="' . esc_attr(FT4A_LANGS[ft4a_lang()][2]) . '" dir="' . (ft4a_is_rtl() ? 'rtl' : 'ltr') . '"';
}, 99);
add_filter('body_class', function ($c) { $c[] = 'ft4a-lang-' . ft4a_lang(); return $c; });

add_action('wp_head', function () {
	$key = ft4a_current_key();
	if ($key === null || in_array($key, ['404','account','inloggen','oefening-toevoegen'], true)) return;
	foreach (FT4A_LANGS as $code => $l) echo '<link rel="alternate" hreflang="' . esc_attr($l[2]) . '" href="' . esc_url(ft4a_url($key, $code)) . '">' . "\n";
	echo '<link rel="alternate" hreflang="x-default" href="' . esc_url(ft4a_url($key, 'en')) . '">' . "\n";
}, 2);

/* Taalmenu */
function ft4a_lang_menu() {
	$key = ft4a_current_key();
	if ($key === null || $key === '404') $key = 'home';
	$cur = FT4A_LANGS[ft4a_lang()];
	$chev = '<svg class="chev" viewBox="0 0 10 10"><path d="M2 3.5l3 3 3-3" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>';
	$o = '<details class="lang"><summary aria-label="' . esc_attr(ft4a_t('Taal kiezen') . ': ' . $cur[3]) . '"><svg class="flag"><use href="#' . $cur[4] . '"/></svg>' . $cur[6] . $chev . '</summary><ul>';
	foreach (FT4A_LANGS as $code => $l) {
		$name = $code === 'ar' ? '<span lang="ar" dir="rtl">' . $l[3] . '</span>' : esc_html($l[3]);
		$o .= '<li><a href="' . esc_url(ft4a_url($key, $code)) . '" hreflang="' . esc_attr($l[2]) . '"' . ($code === ft4a_lang() ? ' aria-current="true"' : '') . '><svg class="flag"><use href="#' . $l[4] . '"/></svg>' . $name . '</a></li>';
	}
	return $o . '</ul></details>';
}

/* Taalpakketten van WordPress en de plugins installeren (beheer) */
function ft4a_missing_locales() {
	$have = get_available_languages();
	$miss = [];
	foreach (FT4A_LANGS as $l) if ($l[1] !== 'en_US' && !in_array($l[1], $have, true)) $miss[] = $l[1];
	return $miss;
}
function ft4a_install_locales($seconds = 20) {
	require_once ABSPATH . 'wp-admin/includes/translation-install.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$start = time(); $done = [];
	foreach (ft4a_missing_locales() as $loc) {
		if (time() - $start > $seconds) break;
		if (wp_download_language_pack($loc)) $done[] = $loc;
	}
	return $done;
}
function ft4a_update_translations() {
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/update.php';
	wp_clean_update_cache();
	wp_update_plugins(); wp_update_themes(); wp_version_check([], true);
	$up = wp_get_translation_updates();
	if (!$up) return 0;
	$skin = new Automatic_Upgrader_Skin();
	$u = new Language_Pack_Upgrader($skin);
	$r = $u->bulk_upgrade($up, ['clear_update_cache' => true]);
	return is_array($r) ? count(array_filter($r)) : 0;
}

/* ---------- Startpagina: bezoekers naar hun eigen taal (3.6.73) ----------
   Wie van buitenaf op ft4a.com/ komt, gaat naar de startpagina in de taal van zijn browser; is die taal er niet,
   dan naar Engels. Nederlandstaligen blijven op ft4a.com/. Geen doorsturing voor zoekmachines, voor klikken binnen de site
   (taalkeuze) of als de bezoeker eerder Nederlands koos. De startpagina wordt daarom niet in de cache bewaard. */
function ft4a_browser_lang() {
	$h = strtolower((string) ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''));
	if ($h === '') return null;
	$best = []; 
	foreach (explode(',', $h) as $i => $part) {
		$bits = explode(';', trim($part)); $tag = trim($bits[0]); $q = 1.0;
		if (isset($bits[1]) && preg_match('/q=([0-9.]+)/', $bits[1], $m)) $q = (float) $m[1];
		if ($tag === '' || $tag === '*') continue;
		$base = explode('-', $tag)[0];
		$l = null;
		if ($tag === 'en-us') $l = 'en-us';
		elseif ($tag === 'pt-br') $l = 'pt-br';
		elseif (in_array($base, ['no', 'nb', 'nn'], true)) $l = 'no';
		elseif (isset(FT4A_LANGS[$base])) $l = $base;
		if ($l) $best[] = [$q, -$i, $l];
	}
	if (!$best) return 'en';
	rsort($best);
	return $best[0][2];
}
add_action('template_redirect', function () {
	if (is_admin() || wp_doing_ajax() || $_SERVER['REQUEST_METHOD'] !== 'GET' || ft4a_path() !== '' || !empty($_GET) || get_query_var('ft4a_lang')) return;
	do_action('litespeed_control_set_nocache', 'ft4a: taal van de bezoeker');
	header('Vary: Accept-Language, Cookie', false);
	$ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
	if ($ua === '' || preg_match('/bot|crawl|spider|slurp|facebookexternalhit|embedly|preview|lighthouse|headless|pingdom|uptime/i', $ua)) return;
	$ref = (string) wp_parse_url((string) ($_SERVER['HTTP_REFERER'] ?? ''), PHP_URL_HOST);
	if ($ref && $ref === wp_parse_url(home_url(), PHP_URL_HOST)) return;
	$cookie = sanitize_key($_COOKIE['ft4a_lang'] ?? '');
	$lang = isset(FT4A_LANGS[$cookie]) ? $cookie : ft4a_browser_lang();
	if (!$lang || $lang === 'nl' || !isset(FT4A_LANGS[$lang])) return;
	wp_safe_redirect(ft4a_url('home', $lang), 302); exit;
}, 2);

/* ---------- Niet-bestaande pagina's: naar de startpagina in de juiste taal (3.6.83) ----------
   Vervangt de plugin "Redirect 404 to Homepage", die alles naar de Nederlandse startpagina stuurde en de
   pagina's met een taalcode (/fr/…, /en/…) oversloeg. Ontbrekende bestanden (afbeeldingen, css, js …) krijgen
   gewoon een 404, zodat de browser en Google niet de startpagina als afbeelding krijgen. */
add_action('template_redirect', function () {
	if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST) || $_SERVER['REQUEST_METHOD'] !== 'GET') return;
	if (ft4a_current_key() !== '404' && !is_404()) return;
	if (preg_match('/\.(png|jpe?g|gif|webp|avif|svg|ico|css|js|map|woff2?|ttf|eot|mp4|webm|mp3|pdf|zip|xml|txt|json|php)$/i', ft4a_path())) return;
	wp_safe_redirect(ft4a_url('home', ft4a_lang()), 301); exit;
}, 0);

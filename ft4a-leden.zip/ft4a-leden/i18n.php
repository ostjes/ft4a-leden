<?php
/* FT4A: meertaligheid. Nederlands staat op de root, de andere talen onder een prefix (/fr/, /en-us/ …). */
if (!defined('ABSPATH')) exit;

// code => [prefix, wp-locale, html-lang, naam, vlag, code op footballtraining4all.com, korte code]
const FT4A_LANGS = [
	'nl'    => ['',      'nl_NL', 'nl',    'Nederlands',     'f-nl', 'nl-nl',  'NL'],
	'en'    => ['en',    'en_GB', 'en-GB', 'English (UK)',   'f-gb', 'en-gb',  'EN'],
	'en-us' => ['en-us', 'en_US', 'en-US', 'English (US)',   'f-us', 'en-us',  'US'],
	'fr'    => ['fr',    'fr_FR', 'fr',    'Français',       'f-fr', 'fr-fr',  'FR'],
	'de'    => ['de',    'de_DE', 'de',    'Deutsch',        'f-de', 'de-de',  'DE'],
	'es'    => ['es',    'es_ES', 'es',    'Español',        'f-es', 'es-es',  'ES'],
	'it'    => ['it',    'it_IT', 'it',    'Italiano',       'f-it', 'it-it',  'IT'],
	'pt'    => ['pt',    'pt_PT', 'pt-PT', 'Português',      'f-pt', 'pt-pt',  'PT'],
	'pt-br' => ['pt-br', 'pt_BR', 'pt-BR', 'Português (BR)', 'f-br', 'pt-br',  'BR'],
	'da'    => ['da',    'da_DK', 'da',    'Dansk',          'f-dk', 'da-dk',  'DA'],
	'sv'    => ['sv',    'sv_SE', 'sv',    'Svenska',        'f-se', 'sv-se',  'SV'],
	'fi'    => ['fi',    'fi',    'fi',    'Finnish',        'f-fi', 'se-fi',  'FI'],
	'no'    => ['no',    'nb_NO', 'nb',    'Norwegian',      'f-no', 'smj-no', 'NO'],
	'pl'    => ['pl',    'pl_PL', 'pl',    'Polski',         'f-pl', 'pl-pl',  'PL'],
	'tr'    => ['tr',    'tr_TR', 'tr',    'Türkçe',         'f-tr', 'tr-tr',  'TR'],
	'ru'    => ['ru',    'ru_RU', 'ru',    'Русский',        'f-ru', 'ru-ru',  'RU'],
	'ro'    => ['ro',    'ro_RO', 'ro',    'Română',         'f-ro', 'en-gb',  'RO'],
	'ar'    => ['ar',    'ar',    'ar',    'العربية',        'f-ar', 'en-gb',  'AR'],
];
const FT4A_KEYS = ['oefeningen','software','prijzen','vragen','handleiding','reviews','contact','ledenoefeningen','oefening-toevoegen','account','inloggen'];

function ft4a_slugs() {
	static $s = null;
	if ($s === null) $s = json_decode((string) @file_get_contents(__DIR__ . '/site/i18n/slugs.json'), true) ?: [];
	return $s;
}
function ft4a_slug($key, $lang) {
	if ($lang === 'nl') return $key;
	return ft4a_slugs()[$lang][$key] ?? $key;
}
function ft4a_key_from_slug($slug, $lang) {
	if ($lang === 'nl') return in_array($slug, FT4A_KEYS, true) ? $slug : null;
	$k = array_search($slug, ft4a_slugs()[$lang] ?? [], true);
	return $k === false ? null : $k;
}
function ft4a_prefixes() {
	$p = [];
	foreach (FT4A_LANGS as $c => $l) if ($l[0] !== '') $p[$l[0]] = $c;
	return $p;
}
function ft4a_path() {
	$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
	$base = rtrim((string) parse_url(home_url('/'), PHP_URL_PATH), '/');
	if ($base && strpos($uri, $base) === 0) $uri = substr($uri, strlen($base));
	return trim($uri, '/');
}

/* Huidige taal: prefix in de URL > Nederlandse pagina > cookie > Nederlands */
function ft4a_lang() {
	static $lang = null;
	if ($lang !== null) return $lang;
	$path = ft4a_path();
	$seg = explode('/', $path)[0];
	$pre = ft4a_prefixes();
	if (isset($pre[$seg])) return $lang = $pre[$seg];
	$cookie = sanitize_key($_COOKIE['ft4a_lang'] ?? '');
	if (($path === '' && empty($_GET)) || in_array($seg, FT4A_KEYS, true)) return $lang = 'nl';
	return $lang = isset(FT4A_LANGS[$cookie]) ? $cookie : 'nl';
}
function ft4a_old_code() { return FT4A_LANGS[ft4a_lang()][5]; }
function ft4a_is_rtl() { return ft4a_lang() === 'ar'; }

function ft4a_t($s) {
	static $dict = [];
	$lang = ft4a_lang();
	if ($lang === 'nl') return $s;
	if (!isset($dict[$lang])) $dict[$lang] = json_decode((string) @file_get_contents(__DIR__ . '/site/i18n/' . $lang . '/php.json'), true) ?: [];
	return $dict[$lang][$s] ?? $s;
}

function ft4a_url($key, $lang = null) {
	$lang = $lang ?: ft4a_lang();
	$frag = '';
	if (strpos($key, '#') !== false) { [$key, $frag] = explode('#', $key, 2); $frag = '#' . $frag; }
	$pre = FT4A_LANGS[$lang][0];
	$parts = [];
	if ($pre !== '') $parts[] = $pre;
	if ($key !== 'home' && $key !== '') $parts[] = ft4a_slug(trim($key, '/'), $lang);
	return home_url($parts ? '/' . implode('/', $parts) . '/' : '/') . $frag;
}

/* WordPress- en WooCommerce-teksten in de taal van de bezoeker */
function ft4a_locale_filter($loc) {
	if (is_admin() && !wp_doing_ajax()) return $loc;
	if (defined('REST_REQUEST') && REST_REQUEST) return $loc;
	$l = ft4a_lang();
	return $l === 'nl' ? $loc : FT4A_LANGS[$l][1];
}
add_filter('locale', 'ft4a_locale_filter', 99);
add_filter('determine_locale', 'ft4a_locale_filter', 99);

/* Routes voor de andere talen */
add_filter('query_vars', function ($v) { $v[] = 'ft4a_lang'; $v[] = 'ft4a_slug'; return $v; });
add_action('init', function () {
	$re = implode('|', array_map('preg_quote', array_keys(ft4a_prefixes())));
	add_rewrite_rule('^(' . $re . ')/?$', 'index.php?ft4a_lang=$matches[1]', 'top');
	add_rewrite_rule('^(' . $re . ')/([^/]+)/?$', 'index.php?ft4a_lang=$matches[1]&ft4a_slug=$matches[2]', 'top');
}, 5);
add_filter('redirect_canonical', function ($r) { return get_query_var('ft4a_lang') ? false : $r; });

/* Welke FT4A-pagina wordt getoond? 'home', een sleutel, '404' of null (geen FT4A-pagina) */
function ft4a_current_key() {
	static $k = false;
	if ($k !== false) return $k;
	if (get_query_var('ft4a_lang')) {
		$slug = get_query_var('ft4a_slug');
		if (!$slug) return $k = 'home';
		return $k = (ft4a_key_from_slug($slug, ft4a_lang()) ?: '404');
	}
	if (is_front_page()) return $k = 'home';
	if (is_404()) return $k = '404';
	if (is_page()) {
		$p = get_queried_object();
		if ($p && get_post_meta($p->ID, '_ft4a_page', true) && in_array($p->post_name, FT4A_KEYS, true)) return $k = $p->post_name;
	}
	return $k = null;
}
function ft4a_site_dir($lang = null) {
	$lang = $lang ?: ft4a_lang();
	return FT4A_DIR . 'site/' . ($lang === 'nl' ? '' : 'i18n/' . $lang . '/');
}
function ft4a_page_title($key) {
	static $t = [];
	$lang = ft4a_lang();
	if (!isset($t[$lang])) $t[$lang] = json_decode((string) @file_get_contents(ft4a_site_dir() . 'pages/index.json'), true) ?: [];
	return $t[$lang][$key] ?? $key;
}

add_action('template_redirect', function () {
	$key = ft4a_current_key();
	if ($key === null) return;
	if ($key === '404' && get_query_var('ft4a_lang')) status_header(404);
	if (!headers_sent() && sanitize_key($_COOKIE['ft4a_lang'] ?? '') !== ft4a_lang()) {
		setcookie('ft4a_lang', ft4a_lang(), time() + YEAR_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true);
	}
}, 1);

add_filter('pre_get_document_title', function ($t) {
	if (!get_query_var('ft4a_lang')) return $t;
	$key = ft4a_current_key();
	if ($key === 'home') return 'FT4A.com – ' . ft4a_t('Software en voetbaloefeningen voor de moderne voetbaltrainer');
	if ($key === '404') return ft4a_t('Deze pagina bestaat niet') . ' – FT4A.com';
	return ft4a_page_title($key) . ' – FT4A.com';
});

add_filter('language_attributes', function ($out) {
	if (is_admin()) return $out;
	return 'lang="' . esc_attr(FT4A_LANGS[ft4a_lang()][2]) . '" dir="' . (ft4a_is_rtl() ? 'rtl' : 'ltr') . '"';
}, 99);
add_filter('body_class', function ($c) { $c[] = 'ft4a-lang-' . ft4a_lang(); return $c; });

add_action('wp_head', function () {
	$key = ft4a_current_key();
	if ($key === null || in_array($key, ['404','account','inloggen','oefening-toevoegen'], true)) return;
	foreach (FT4A_LANGS as $code => $l) echo '<link rel="alternate" hreflang="' . esc_attr($l[2]) . '" href="' . esc_url(ft4a_url($key, $code)) . '">' . "\n";
	echo '<link rel="alternate" hreflang="x-default" href="' . esc_url(ft4a_url($key, 'nl')) . '">' . "\n";
}, 2);

/* Taalmenu */
function ft4a_lang_menu() {
	$key = ft4a_current_key();
	if ($key === null || $key === '404') $key = 'home';
	$cur = FT4A_LANGS[ft4a_lang()];
	$chev = '<svg class="chev" viewBox="0 0 10 10"><path d="M2 3.5l3 3 3-3" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>';
	$o = '<details class="lang"><summary aria-label="' . esc_attr(ft4a_t('Taal kiezen') . ': ' . $cur[3]) . '"><svg class="flag"><use href="#' . $cur[4] . '"/></svg>' . $cur[6] . $chev . '</summary><ul>';
	foreach (FT4A_LANGS as $code => $l) {
		$name = $code === 'ar' ? '<span lang="ar" dir="rtl">' . $l[3] . '</span>' : esc_html($l[3]);
		$o .= '<li><a href="' . esc_url(ft4a_url($key, $code)) . '" hreflang="' . esc_attr($l[2]) . '"' . ($code === ft4a_lang() ? ' aria-current="true"' : '') . '><svg class="flag"><use href="#' . $l[4] . '"/></svg>' . $name . '</a></li>';
	}
	return $o . '</ul></details>';
}

/* Taalpakketten van WordPress en de plugins installeren (beheer) */
function ft4a_missing_locales() {
	$have = get_available_languages();
	$miss = [];
	foreach (FT4A_LANGS as $l) if ($l[1] !== 'en_US' && !in_array($l[1], $have, true)) $miss[] = $l[1];
	return $miss;
}
function ft4a_install_locales($seconds = 20) {
	require_once ABSPATH . 'wp-admin/includes/translation-install.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$start = time(); $done = [];
	foreach (ft4a_missing_locales() as $loc) {
		if (time() - $start > $seconds) break;
		if (wp_download_language_pack($loc)) $done[] = $loc;
	}
	return $done;
}
function ft4a_update_translations() {
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/update.php';
	wp_clean_update_cache();
	wp_update_plugins(); wp_update_themes(); wp_version_check([], true);
	$up = wp_get_translation_updates();
	if (!$up) return 0;
	$skin = new Automatic_Upgrader_Skin();
	$u = new Language_Pack_Upgrader($skin);
	$r = $u->bulk_upgrade($up, ['clear_update_cache' => true]);
	return is_array($r) ? count(array_filter($r)) : 0;
}

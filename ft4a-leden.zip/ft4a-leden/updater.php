<?php
/* FT4A Leden: automatische updates vanaf GitHub (ostjes/ft4a-leden, bestand update.json in de hoofdmap). */
if (!defined('ABSPATH')) exit;

const FT4A_UPDATE_URL = 'https://raw.githubusercontent.com/ostjes/ft4a-leden/main/update.json';

function ft4a_plugin_file() { return plugin_basename(FT4A_DIR . 'ft4a-leden.php'); }
function ft4a_plugin_version() {
	if (!function_exists('get_plugin_data')) require_once ABSPATH . 'wp-admin/includes/plugin.php';
	return get_plugin_data(FT4A_DIR . 'ft4a-leden.php', false, false)['Version'] ?? '0';
}
function ft4a_remote_info($force = false) {
	$info = $force ? false : get_site_transient('ft4a_update_info');
	if ($info === false) {
		$r = wp_remote_get(add_query_arg('t', time(), FT4A_UPDATE_URL), ['timeout' => 10, 'headers' => ['Cache-Control' => 'no-cache']]);
		$info = (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) ? json_decode(wp_remote_retrieve_body($r), true) : null;
		if (!is_array($info) || empty($info['version']) || empty($info['package'])) $info = [];
		set_site_transient('ft4a_update_info', $info, 3 * HOUR_IN_SECONDS);
	}
	return $info;
}

add_filter('pre_set_site_transient_update_plugins', function ($t) {
	if (!is_object($t)) return $t;
	$info = ft4a_remote_info();
	$file = ft4a_plugin_file();
	$obj = (object) ['id' => 'github.com/ostjes/ft4a-leden', 'slug' => 'ft4a-leden', 'plugin' => $file, 'url' => 'https://github.com/ostjes/ft4a-leden',
		'new_version' => $info['version'] ?? ft4a_plugin_version(), 'package' => $info['package'] ?? '', 'tested' => get_bloginfo('version'), 'requires_php' => '7.4', 'icons' => [], 'banners' => []];
	if ($info && version_compare($info['version'], ft4a_plugin_version(), '>')) { $t->response[$file] = $obj; unset($t->no_update[$file]); }
	else { $t->no_update[$file] = $obj; unset($t->response[$file]); }
	return $t;
});

add_filter('plugins_api', function ($res, $action, $args) {
	if ($action !== 'plugin_information' || ($args->slug ?? '') !== 'ft4a-leden') return $res;
	$info = ft4a_remote_info();
	return (object) ['name' => 'FT4A Leden', 'slug' => 'ft4a-leden', 'version' => $info['version'] ?? ft4a_plugin_version(), 'author' => 'OSTJE',
		'homepage' => 'https://ft4a.com/', 'download_link' => $info['package'] ?? '', 'sections' => ['changelog' => wpautop(esc_html($info['notes'] ?? ''))]];
}, 10, 3);

/* Altijd automatisch bijwerken */
add_filter('auto_update_plugin', function ($update, $item) { return (isset($item->plugin) && $item->plugin === ft4a_plugin_file()) ? true : $update; }, 10, 2);

/* Na de update: de map heet altijd ft4a-leden (ook als GitHub een andere mapnaam meegeeft) */
add_filter('upgrader_source_selection', function ($source, $remote, $upgrader, $extra) {
	if (($extra['plugin'] ?? '') !== ft4a_plugin_file() || basename($source) === 'ft4a-leden') return $source;
	$new = trailingslashit($remote) . 'ft4a-leden/';
	return (rename($source, $new)) ? $new : $source;
}, 10, 4);

/* Knop "Nu bijwerken" op de FT4A-beheerpagina */
function ft4a_update_now() {
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	require_once ABSPATH . 'wp-admin/includes/update.php';
	$info = ft4a_remote_info(true);
	if (!$info) return 'Kon update.json op GitHub niet lezen.';
	if (!version_compare($info['version'], ft4a_plugin_version(), '>')) return 'Je hebt al de nieuwste versie (' . esc_html(ft4a_plugin_version()) . ').';
	delete_site_transient('update_plugins');
	wp_update_plugins();
	$up = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
	$ok = $up->upgrade(ft4a_plugin_file());
	// WordPress zet de plugin uit tijdens een handmatige update: meteen weer aanzetten (zonder de oude code opnieuw te laden)
	$act = (array) get_option('active_plugins', []);
	if (!in_array(ft4a_plugin_file(), $act, true)) { $act[] = ft4a_plugin_file(); sort($act); update_option('active_plugins', $act); }
	if (!is_wp_error($ok) && $ok) { return 'Bijgewerkt naar versie ' . esc_html($info['version']) . '.'; }
	return 'Bijwerken is niet gelukt' . (is_wp_error($ok) ? ': ' . esc_html($ok->get_error_message()) : '.');
}
add_action('admin_post_ft4a_update_now', function () {
	if (!current_user_can('update_plugins') || !check_admin_referer('ft4a_update_now')) wp_die('Geen toegang');
	@set_time_limit(180);
	$msg = ft4a_update_now();
	wp_safe_redirect(add_query_arg('ft4a_upd', rawurlencode($msg), admin_url('admin.php?page=ft4a'))); exit;
});
function ft4a_update_box() {
	$info = ft4a_remote_info();
	$cur = ft4a_plugin_version();
	$new = $info && version_compare($info['version'], $cur, '>');
	$o = '<div style="margin-top:16px;padding:16px;background:#fff;border:1px solid #c3c4c7;max-width:760px">';
	if (!empty($_GET['ft4a_upd'])) $o .= '<div class="notice notice-info inline"><p>' . esc_html(wp_unslash($_GET['ft4a_upd'])) . '</p></div>';
	$o .= '<p><strong>Plugin-versie:</strong> ' . esc_html($cur) . ' · <strong>nieuwste op GitHub:</strong> ' . esc_html($info['version'] ?? 'onbekend') . ($new ? ' — <strong style="color:#b32d2e">update beschikbaar</strong>' : '') . '</p>';
	$o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('ft4a_update_now', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ft4a_update_now"><button class="button' . ($new ? ' button-primary' : '') . '">Nu bijwerken</button> <span class="description">Updates gebeuren ook vanzelf (twee keer per dag).</span></form></div>';
	return $o;
}

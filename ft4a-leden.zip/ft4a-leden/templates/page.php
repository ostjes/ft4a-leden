<?php
if (!defined('ABSPATH')) exit;
$ft4a_d = ft4a_site_dir();
$ft4a_key = ft4a_current_key();
$ft4a_lang = ft4a_lang();
$ft4a_header = str_replace('<!--FT4A_LANG-->', ft4a_lang_menu(), file_get_contents($ft4a_d . 'header.html'));
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
<?php echo file_get_contents(FT4A_DIR . 'site/head.html'); ?>
<?php if (ft4a_is_rtl()) echo file_get_contents(FT4A_DIR . 'site/rtl.html'); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php echo file_get_contents(FT4A_DIR . 'site/sprites.html'); ?>
<?php echo $ft4a_header; ?>
<main id="inhoud">
<?php
if ($ft4a_key === 'home') {
	$ft4a_n = (string) ft4a_oefening_count();
	$ft4a_h = str_replace(['<strong>2128</strong>', '>2128</text>'], ['<strong>' . $ft4a_n . '</strong>', '>' . $ft4a_n . '</text>'], ft4a_page_html('home'));
	// nog geen demovideo: de lege video (die telkens een 404 gaf) en de werknotitie weglaten; de geanimeerde tekening blijft
	// demovideo (een oefening uit de database, gemaakt met de eigen tekencode van de software): uit de plugin laden; de tekening blijft als terugval
	$ft4a_h = preg_replace('#\s*<!--[^>]*ft4a-demo\.mp4.*?-->#s', '', $ft4a_h);
	if (file_exists(FT4A_DIR . 'assets/ft4a-demo.mp4')) $ft4a_h = str_replace('src="assets/ft4a-demo.mp4"', 'src="' . esc_url(plugins_url('assets/ft4a-demo.mp4', FT4A_DIR . 'ft4a-leden.php')) . '?v=5"', $ft4a_h);
	else $ft4a_h = preg_replace('#<video id="demo"[^>]*>\s*</video>#', '', $ft4a_h);
	echo ft4a_fix_counts($ft4a_h);
} elseif ($ft4a_key === '404') {
	echo ft4a_404_html();
} elseif ($ft4a_key && $ft4a_lang !== 'nl') {
	echo ft4a_page_html($ft4a_key);
} else {
	while (have_posts()) {
		the_post();
		if (get_post_meta(get_the_ID(), '_ft4a_page', true)) {
			the_content();
		} else {
			$ft4a_wt = (function_exists('is_checkout') && is_checkout()) ? (is_wc_endpoint_url('order-received') ? 'Bestelling ontvangen' : 'Afrekenen') : ((function_exists('is_cart') && is_cart()) ? 'Winkelmand' : ((function_exists('is_account_page') && is_account_page()) ? 'Mijn account' : get_the_title()));
			echo function_exists('ft4a_woo_hero') ? ft4a_woo_hero($ft4a_wt) : '<section class="phero"><div class="wrap"><h1>' . esc_html(ft4a_t($ft4a_wt)) . '</h1></div></section>';
			echo '<section class="pbody"><div class="wrap ft4a-woo">';
			the_content();
			echo '</div></section>';
		}
	}
}
?>
</main>
<?php echo file_get_contents($ft4a_d . 'footer.html'); ?>
<?php wp_footer(); ?>
</body>
</html>

<?php
/* FT4A: eigen pagina "Bestelling ontvangen" (vervangt checkout/thankyou.php van WooCommerce) */
if (!defined('ABSPATH')) exit;
if (!$order) { echo '<p>' . esc_html(ft4a_t('Bedankt voor je bestelling')) . '</p>'; return; }
$paid = $order->is_paid();
$failed = $order->has_status(['failed', 'cancelled']);
$st = $paid ? ['ok', ft4a_t('Betaald')] : ($failed ? ['err', ft4a_t('Niet betaald')] : ['wait', ft4a_t('Wacht op betaling')]);
$ico = function ($d) { return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $d . '</svg>'; };
$icons = ['online' => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 2.5 15.3 0 18M12 3c-2.5 2.7-2.5 15.3 0 18"/>', 'offline' => '<path d="M3 4h18v12H3z"/><path d="M8 20h8M12 16v4"/>', 'compleet' => '<path d="M3 12V3h9l9 9-9 9z"/><circle cx="7.5" cy="7.5" r="1.5"/>'];
// mededelingen van de betaalprovider (bv. overschrijvingsgegevens) alleen tonen als er nog betaald moet worden
ob_start(); do_action('woocommerce_thankyou_' . $order->get_payment_method(), $order->get_id()); $pay_info = trim(ob_get_clean());
?>
<div class="ft4a-ty">
	<div class="ft4a-ty-main ft4a-ty-card">
		<div class="ft4a-ty-h"><h2><?php echo esc_html(ft4a_t('Je bestelling')); ?></h2><span class="ft4a-ty-st <?php echo esc_attr($st[0]); ?>"><?php echo esc_html($st[1]); ?></span></div>
		<ul class="ft4a-ty-items">
		<?php foreach ($order->get_items() as $it) {
			$c = (string) get_post_meta($it->get_product_id(), '_ft4a_pakket', true);
			$type = isset(FT4A_PAKKETTEN[$c]) ? FT4A_PAKKETTEN[$c][3] : 'compleet';
			$name = isset(FT4A_PAKKETTEN[$c]) ? ft4a_pakket_naam($c, true) : $it->get_name();
			echo '<li><span class="ft4a-ty-ico">' . $ico($icons[$type] ?? $icons['compleet']) . '</span><span class="ft4a-ty-name"><b>' . esc_html($name) . '</b>' . ($it->get_quantity() > 1 ? '<small>× ' . (int) $it->get_quantity() . '</small>' : '') . '</span><span class="ft4a-ty-price">' . wp_kses_post($order->get_formatted_line_subtotal($it)) . '</span></li>';
		} ?>
		</ul>
		<div class="ft4a-ty-tot">
			<?php foreach ($order->get_order_item_totals() as $k => $t) { if ($k === 'payment_method') continue; echo '<div class="' . ($k === 'order_total' ? 'big' : '') . '"><span>' . esc_html(rtrim(wp_strip_all_tags($t['label']), ':')) . '</span><span>' . wp_kses_post($t['value']) . '</span></div>'; } ?>
		</div>
		<?php if (!$paid && $pay_info) echo '<div class="ft4a-ty-pay">' . wp_kses_post($pay_info) . '</div>'; ?>
		<?php ob_start(); do_action('woocommerce_order_details_after_order_table', $order); $lic = trim(ob_get_clean()); if ($lic) echo '<div class="ft4a-ty-lic">' . $lic . '</div>'; ?>
	</div>
	<div class="ft4a-ty-side">
		<div class="ft4a-ty-card">
			<h3><?php echo esc_html(rtrim(__('Order details', 'woocommerce'), ':')); ?></h3>
			<dl class="ft4a-ty-dl">
				<div><dt><?php echo esc_html(rtrim(__('Order number:', 'woocommerce'), ':')); ?></dt><dd><?php echo esc_html($order->get_order_number()); ?></dd></div>
				<div><dt><?php echo esc_html(rtrim(__('Date:', 'woocommerce'), ':')); ?></dt><dd><?php echo esc_html(wc_format_datetime($order->get_date_created())); ?></dd></div>
				<?php if ($order->get_payment_method_title()) { ?><div><dt><?php echo esc_html(rtrim(__('Payment method:', 'woocommerce'), ':')); ?></dt><dd><?php echo esc_html($order->get_payment_method_title()); ?></dd></div><?php } ?>
				<div><dt><?php echo esc_html(rtrim(__('Email:', 'woocommerce'), ':')); ?></dt><dd><?php echo esc_html($order->get_billing_email()); ?></dd></div>
			</dl>
		</div>
		<?php if ($addr = $order->get_formatted_billing_address()) { ?>
		<div class="ft4a-ty-card">
			<h3><?php echo esc_html(__('Billing address', 'woocommerce')); ?></h3>
			<address><?php echo wp_kses_post($addr); ?></address>
		</div>
		<?php } ?>
		<p class="ft4a-ty-help"><?php echo esc_html(ft4a_t('Hulp nodig?')); ?> <a href="<?php echo esc_url(ft4a_url('contact')); ?>"><?php echo esc_html(ft4a_t('Contact')); ?></a> · <a href="<?php echo esc_url(ft4a_url('vragen')); ?>"><?php echo esc_html(ft4a_t('Vragen')); ?></a></p>
	</div>
</div>
<style>
.ft4a-woo .woocommerce-order,.ft4a-woo .woocommerce{max-width:none!important;width:100%!important}
.ft4a-ty{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(280px,1fr);gap:22px;align-items:start;margin:4px 0 30px}
@media (max-width:900px){.ft4a-ty{grid-template-columns:1fr}}
.ft4a-ty-card{background:var(--bg-2,#4b5a52);border:1px solid var(--line,#62726a);border-radius:18px;padding:24px 26px;box-shadow:0 2px 4px rgba(0,0,0,.15),0 12px 28px rgba(0,0,0,.18)}
.ft4a-ty-side{display:grid;gap:22px}
.ft4a-ty h2,.ft4a-ty h3{margin:0!important;color:#fff!important;font-weight:700!important;font-size:1.15rem!important;text-transform:none!important;letter-spacing:0!important}
.ft4a-ty h3{margin-bottom:14px!important}
.ft4a-ty-h{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
.ft4a-ty-st{font-size:.82rem;font-weight:800;padding:6px 12px;border-radius:999px}
.ft4a-ty-st.ok{background:rgba(98,220,158,.16);color:#8ef0bd;border:1px solid rgba(98,220,158,.45)}
.ft4a-ty-st.wait{background:rgba(255,196,0,.14);color:#ffd866;border:1px solid rgba(255,196,0,.4)}
.ft4a-ty-st.err{background:rgba(227,52,47,.18);color:#ffb4ab;border:1px solid rgba(255,138,128,.5)}
.ft4a-ty-items{list-style:none;margin:0;padding:0}
.ft4a-ty-items li{display:flex;align-items:center;gap:16px;padding:16px 0;border-top:1px solid var(--line,#62726a)}
.ft4a-ty-items li:first-child{border-top:0;padding-top:4px}
.ft4a-ty-ico{flex:0 0 48px;height:48px;border-radius:12px;display:grid;place-items:center;background:rgba(98,220,158,.12);color:var(--brand,#62dc9e)}
.ft4a-ty-ico svg{width:24px;height:24px}
.ft4a-ty-name{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.ft4a-ty-name b{font-size:1.05rem}.ft4a-ty-name small{color:var(--muted,#c9d6cf)}
.ft4a-ty-price{font-weight:700;font-size:1.05rem;white-space:nowrap}
.ft4a-ty-tot{margin-top:6px;padding-top:14px;border-top:1px solid var(--line,#62726a);display:grid;gap:8px}
.ft4a-ty-tot div{display:flex;justify-content:space-between;gap:16px;color:var(--muted,#c9d6cf)}
.ft4a-ty-tot div.big{color:#fff;font-weight:800;font-size:1.3rem;padding-top:8px}
.ft4a-ty-tot small,.ft4a-ty-tot .includes_tax{font-size:.8rem;font-weight:500;color:var(--muted,#c9d6cf)}
.ft4a-ty-pay{margin-top:18px;padding:16px 18px;border-radius:12px;border:1px solid rgba(255,196,0,.4);background:rgba(255,196,0,.08)}
.ft4a-ty-pay h2{font-size:1rem!important;margin-bottom:8px!important}
.ft4a-ty-dl{margin:0;display:grid;gap:12px}
.ft4a-ty-dl div{display:flex;justify-content:space-between;gap:14px;border-bottom:1px dashed rgba(255,255,255,.12);padding-bottom:10px}
.ft4a-ty-dl div:last-child{border-bottom:0;padding-bottom:0}
.ft4a-ty-dl dt{color:var(--muted,#c9d6cf);margin:0;white-space:nowrap}.ft4a-ty-dl dd{margin:0;font-weight:600;text-align:right;word-break:break-word}
.ft4a-ty address{font-style:normal;line-height:1.7;color:#fff}
.ft4a-ty-help{margin:0;color:var(--muted,#c9d6cf);font-size:.95rem}.ft4a-ty-help a{color:var(--brand,#62dc9e)}
.ft4a-ty-lic{margin-top:20px;padding-top:18px;border-top:1px solid var(--line,#62726a)}.ft4a-ty-lic .ostjes-licences{margin:0!important}.ft4a-ty-lic h2{font-size:1.05rem!important;margin:0 0 10px!important}.ft4a-ty-lic div[style*=monospace]{background:#2c3a33!important;border-color:var(--line,#62726a)!important;color:#fff!important}.ft4a-ty-lic a{color:var(--brand,#62dc9e)}
</style>
<?php
// overige koppelingen (statistieken, conversies …) wel uitvoeren, zonder de standaardtabel van WooCommerce
remove_action('woocommerce_thankyou', 'woocommerce_order_details_table', 10);
do_action('woocommerce_thankyou', $order->get_id());

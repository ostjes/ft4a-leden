<?php
/* FT4A: e-mail na een bestelling (vervangt emails/customer-completed-order.php en customer-processing-order.php in HTML) */
if (!defined('ABSPATH')) exit;
$GLOBALS['ft4a_own_order_mail'] = true;
$types = []; $club = false; $names = [];
foreach ($order->get_items() as $it) {
	$c = (string) get_post_meta($it->get_product_id(), '_ft4a_pakket', true);
	if (isset(FT4A_PAKKETTEN[$c])) { $types[] = FT4A_PAKKETTEN[$c][3]; if (isset(FT4A_CLUB_CODES[$c])) $club = true; $names[] = [ft4a_pakket_naam($c, true), $order->get_formatted_line_subtotal($it)]; }
	else $names[] = [$it->get_name(), $order->get_formatted_line_subtotal($it)];
}
$on = in_array('online', $types, true) || in_array('compleet', $types, true);
$offl = in_array('offline', $types, true) || in_array('compleet', $types, true);
$uid = (int) $order->get_customer_id();
$until = $uid ? max($on ? ft4a_until($uid, '_ft4a_db_tot') : 0, $offl ? ft4a_until($uid, '_ft4a_offline_tot') : 0) : 0;
$first = $order->get_billing_first_name();
$btn = function ($url, $label, $primary = true) { return '<a class="ft4a-btn' . ($primary ? '' : ' ft4a-btn2') . '" style="margin:4px 8px 4px 0" href="' . esc_url($url) . '">' . esc_html($label) . '</a>'; };
$steps = [];
if ($on) {
	$steps[] = sprintf(ft4a_t('Log in op ft4a.com met je e-mailadres %s.'), '<strong>' . esc_html($order->get_billing_email()) . '</strong>');
	$steps[] = esc_html(ft4a_t('Open de online software en teken je eerste oefening, met de oefeningendatabase erbij.'));
}
if ($offl && !$club) {
	$steps[] = esc_html(ft4a_t('Download de software voor Windows of Mac in Mijn account en installeer ze.'));
	$steps[] = esc_html(ft4a_t('Start de software en vul je licentiecode in. Die vind je hieronder.'));
}
if ($club) $steps[] = esc_html(ft4a_t('Geef elke trainer zijn eigen licentiecode. Je vindt ze hieronder.'));
$td = 'padding:10px 0;border-bottom:1px solid #e3ebe6;font-size:14px;vertical-align:top';

do_action('woocommerce_email_header', $email_heading, $email);
?>
<p style="margin:0 0 14px"><?php echo esc_html(sprintf(ft4a_t('Hallo %s'), $first ?: $order->get_billing_email())); ?>,</p>
<p style="margin:0 0 22px"><?php echo esc_html(ft4a_t('Bedankt voor je bestelling bij FT4A.com. We hebben je betaling goed ontvangen en je pakket staat meteen klaar.')); ?></p>

<div style="background:#f2f8f4;border:1px solid #cfe5d8;border-radius:14px;padding:18px 20px;margin:0 0 24px">
	<p style="margin:0 0 6px;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#16924f;font-weight:800"><?php echo esc_html(ft4a_t('Je pakket')); ?></p>
	<?php foreach ($names as $n) echo '<p style="margin:0 0 4px;font-size:17px;font-weight:800;color:#17241e">' . esc_html($n[0]) . '</p>'; ?>
	<?php if ($until > time()) echo '<p style="margin:6px 0 0;color:#4a5a52">' . esc_html(sprintf(ft4a_t('Geldig tot %s'), date_i18n(wc_date_format(), $until))) . '</p>'; ?>
</div>

<?php if ($steps) { ?>
<h2><?php echo esc_html(ft4a_t('Zo ga je aan de slag')); ?></h2>
<table role="presentation" cellspacing="0" cellpadding="0" style="width:100%;margin:0 0 14px;border-collapse:collapse">
<?php foreach ($steps as $i => $s) echo '<tr><td style="width:34px;padding:6px 0;vertical-align:top"><span style="display:inline-block;width:24px;height:24px;line-height:24px;border-radius:50%;background:#16924f;color:#fff;text-align:center;font-weight:800;font-size:13px">' . ($i + 1) . '</span></td><td style="padding:7px 0;font-size:15px;line-height:1.5">' . wp_kses_post($s) . '</td></tr>'; ?>
</table>
<p style="margin:0 0 26px">
<?php
if ($on) echo $btn(ft4a_online_url(), ft4a_t('Open de online software'));
if ($offl) echo $btn(ft4a_url('account') . '#downloaden', ft4a_t('Download de software'), !$on);
if ($on) echo $btn(ft4a_url('ledenoefeningen'), ft4a_t('Ledenoefeningen'), false);
if (!$on && !$offl) echo $btn(ft4a_url('account'), ft4a_t('Naar Mijn account'));
?>
</p>
<?php } ?>

<?php do_action('woocommerce_email_after_order_table', $order, $sent_to_admin, $plain_text, $email); ?>

<h2><?php echo esc_html(ft4a_t('Je bestelling')); ?></h2>
<table role="presentation" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse;margin:0 0 24px">
	<tr><td style="<?php echo $td; ?>;color:#5d6b64"><?php echo esc_html(rtrim(__('Order number:', 'woocommerce'), ':')); ?></td><td style="<?php echo $td; ?>;text-align:right;font-weight:700"><?php echo esc_html($order->get_order_number()); ?></td></tr>
	<tr><td style="<?php echo $td; ?>;color:#5d6b64"><?php echo esc_html(rtrim(__('Date:', 'woocommerce'), ':')); ?></td><td style="<?php echo $td; ?>;text-align:right"><?php echo esc_html(wc_format_datetime($order->get_date_created())); ?></td></tr>
	<?php foreach ($names as $n) { ?><tr><td style="<?php echo $td; ?>"><?php echo esc_html($n[0]); ?></td><td style="<?php echo $td; ?>;text-align:right"><?php echo wp_kses_post($n[1]); ?></td></tr><?php } ?>
	<?php if ($order->get_payment_method_title()) { ?><tr><td style="<?php echo $td; ?>;color:#5d6b64"><?php echo esc_html(rtrim(__('Payment method:', 'woocommerce'), ':')); ?></td><td style="<?php echo $td; ?>;text-align:right"><?php echo esc_html($order->get_payment_method_title()); ?></td></tr><?php } ?>
	<tr><td style="padding:14px 0 0;font-size:17px;font-weight:800"><?php echo esc_html(rtrim(__('Total:', 'woocommerce'), ':')); ?></td><td style="padding:14px 0 0;text-align:right;font-size:17px;font-weight:800"><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td></tr>
</table>

<?php do_action('woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email); ?>

<?php if ($additional_content) echo '<div style="margin:0 0 18px">' . wp_kses_post(wpautop(wptexturize($additional_content))) . '</div>'; ?>

<p style="margin:0 0 6px"><?php echo esc_html(ft4a_t('Vragen? Antwoord gewoon op deze e-mail of bekijk de veelgestelde vragen.')); ?> <a href="<?php echo esc_url(ft4a_url('vragen')); ?>" style="color:#16924f;font-weight:700"><?php echo esc_html(ft4a_t('Vragen')); ?></a></p>
<p style="margin:18px 0 0"><?php echo esc_html(ft4a_t('Sportieve groeten,')); ?><br><strong><?php echo esc_html(ft4a_t('Het team van FT4A.com')); ?></strong></p>
<?php
do_action('woocommerce_email_footer', $email);
unset($GLOBALS['ft4a_own_order_mail']);

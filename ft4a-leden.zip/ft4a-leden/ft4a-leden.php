<?php
/**
 * Plugin Name: FT4A Leden
 * Description: Ledenomgeving voor FT4A.com: registreren, inloggen, verkoop van de pakketten (WooCommerce), lidmaatschap, oefeningen (FT4A-bestanden) uploaden, ledendatabase en contactformulier.
 * Version: 3.6.5
 * Author: OSTJE
 * Text Domain: ft4a-leden
 */
if (!defined('ABSPATH')) exit;
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/seo.php';
require_once __DIR__ . '/updater.php';

const FT4A_CATS = ['Allerlei','Scoren','Passvormen','Conditie','Opwarmingen','Doelmannen','U6 – U9'];
const FT4A_AGES = ['U6 – U9','U10 – U13','U14 – U17','U18 – U21','Senioren','Alle leeftijden'];
const FT4A_MAX_MB = 10;
const FT4A_PUB_VER = '3.4.2';
const FT4A_VIEW_VER = '3.4.8';
const FT4A_SITE_VER = '2.3.8.7';
define('FT4A_DIR', plugin_dir_path(__FILE__));
// code => [naam, looptijd, prijs, soort, dagen]
const FT4A_PAKKETTEN = [
	'P1' => ['Offline pakket', '1 jaar', 35, 'offline', 365],
	'P2' => ['Online pakket', '1 jaar', 38, 'online', 365],
	'P3' => ['Compleet pakket', '1 jaar', 69, 'compleet', 365],
	'P4' => ['Offline pakket', '50 jaar', 149, 'offline', 18263],
	'P5' => ['Online pakket', '50 jaar', 155, 'online', 18263],
	'P6' => ['Compleet pakket', '50 jaar', 279, 'compleet', 18263],
	'TRIAL' => ['Trial', '7 dagen', 0, 'compleet', 7],
	'C1' => ['Clubpakket 5 trainers', '1 jaar', 159, 'offline', 365],
	'C2' => ['Clubpakket 10 trainers', '1 jaar', 310, 'offline', 365],
	'C3' => ['Clubpakket 5 trainers', '50 jaar', 555, 'offline', 18263],
	'C4' => ['Clubpakket 10 trainers', '50 jaar', 999, 'offline', 18263],
];
// clubpakketten: aantal licentiecodes per pakket
const FT4A_CLUB_CODES = ['C1' => 5, 'C2' => 10, 'C3' => 5, 'C4' => 10];
function ft4a_pakket_naam($code, $tr = false) {
	$p = FT4A_PAKKETTEN[$code] ?? null;
	if (!$p) return '';
	$t = function ($x) use ($tr) { return $tr ? ft4a_t($x) : $x; };
	if ($code === 'TRIAL') return 'FT4A Trial (' . $t('7 dagen gratis') . ')';
	if (isset(FT4A_CLUB_CODES[$code])) return 'FT4A ' . $t($p[0]) . ' (' . $t($p[1]) . ')';
	return 'FT4A ' . $t('Pakket') . ' ' . substr($code, 1) . ' – ' . $t($p[0]) . ' (' . $t($p[1]) . ')';
}
const FT4A_DESC = [
	'offline' => 'Download de software van de website, installeer ze op je computer en gebruik de voetbalsoftware op je computer.',
	'online' => 'Gebruik de software op de website, krijg toegang tot de oefeningen-database en publiceer oefeningen op de website.',
	'compleet' => 'Offline pakket en online pakket samen: de software op je computer én online, met toegang tot de oefeningen-database.',
];

/* ---------- Lidmaatschap ---------- */
function ft4a_until($uid, $key) { return (int) get_user_meta($uid, $key, true); }
function ft4a_has_db($uid = 0) {
	$uid = $uid ?: get_current_user_id();
	if (!$uid) return false;
	if (user_can($uid, 'edit_posts')) return true;
	return ft4a_until($uid, '_ft4a_db_tot') > time();
}
function ft4a_grant($uid, $code) {
	$p = FT4A_PAKKETTEN[$code] ?? null;
	if (!$p) return;
	$add = $p[4] * DAY_IN_SECONDS;
	foreach (['offline' => ['offline','compleet'], 'db' => ['online','compleet']] as $k => $types) {
		if (in_array($p[3], $types, true)) {
			$meta = '_ft4a_' . $k . '_tot';
			update_user_meta($uid, $meta, max(time(), ft4a_until($uid, $meta)) + $add);
		}
	}
	update_user_meta($uid, '_ft4a_pakket', $code);
	if ($code === 'TRIAL') update_user_meta($uid, '_ft4a_trial_used', 1);
}
function ft4a_status_label($ts) {
	if ($ts <= time()) return '<span class="ft4a-pill wait">' . ft4a_t('Niet actief') . '</span>';
	return '<span class="ft4a-pill ok">' . esc_html(sprintf(ft4a_t('Actief tot %s'), date_i18n(ft4a_t('j F Y'), $ts))) . '</span>';
}
function ft4a_product_id($code) {
	$ids = get_posts(['post_type'=>'product','post_status'=>'publish','numberposts'=>1,'fields'=>'ids','meta_key'=>'_ft4a_pakket','meta_value'=>$code]);
	return $ids ? (int) $ids[0] : 0;
}
function ft4a_only_pakket($order) {
	foreach ($order->get_items() as $it) { if (!get_post_meta($it->get_product_id(), '_ft4a_pakket', true)) return false; }
	return true;
}
// Betaalde pakketten meteen afronden en lidmaatschap toekennen
add_filter('woocommerce_payment_complete_order_status', function ($status, $order_id, $order = null) {
	$order = $order ?: (function_exists('wc_get_order') ? wc_get_order($order_id) : null);
	return ($order && ft4a_only_pakket($order)) ? 'completed' : $status;
}, 10, 3);
add_action('woocommerce_order_status_completed', function ($order_id) {
	$o = wc_get_order($order_id);
	if (!$o || $o->get_meta('_ft4a_granted')) return;
	$uid = $o->get_user_id();
	if (!$uid) return;
	foreach ($o->get_items() as $it) {
		$code = get_post_meta($it->get_product_id(), '_ft4a_pakket', true);
		if ($code) for ($i = 0; $i < max(1, (int) $it->get_quantity()); $i++) ft4a_grant($uid, $code);
	}
	$o->update_meta_data('_ft4a_granted', 1);
	$o->save();
	$o->add_order_note('FT4A-lidmaatschap toegekend.');
	$club = 0;
	foreach ($o->get_items() as $it) $club += (FT4A_CLUB_CODES[get_post_meta($it->get_product_id(), '_ft4a_pakket', true)] ?? 0) * max(1, (int) $it->get_quantity());
	if ($club) {
		$o->add_order_note(sprintf('Clubpakket: stuur %d licentiecodes op naam van de club naar %s.', $club, $o->get_billing_email()));
		wp_mail(get_option('admin_email'), sprintf('FT4A clubpakket besteld (#%s): %d licentiecodes sturen', $o->get_order_number(), $club), sprintf("Bestelling #%s\nKlant: %s %s (%s)\nClub/bedrijf: %s\nAantal licentiecodes: %d\n\n%s", $o->get_order_number(), $o->get_billing_first_name(), $o->get_billing_last_name(), $o->get_billing_email(), $o->get_billing_company(), $club, $o->get_edit_order_url()));
	}
});
// Trial maar één keer
add_filter('woocommerce_add_to_cart_validation', function ($ok, $pid) {
	if (get_post_meta($pid, '_ft4a_pakket', true) === 'TRIAL' && get_user_meta(get_current_user_id(), '_ft4a_trial_used', true)) {
		wc_add_notice(ft4a_t('Je hebt de gratis proefperiode al gebruikt. Kies een pakket om verder te gaan.'), 'error');
		return false;
	}
	return $ok;
}, 10, 2);

// Productnaam in de taal van de bezoeker (winkelmand, afrekenen, bestellingen)
add_filter('woocommerce_product_get_name', function ($name, $prod) {
	if (is_admin() || ft4a_lang() === 'nl') return $name;
	$code = get_post_meta($prod->get_id(), '_ft4a_pakket', true);
	$p = FT4A_PAKKETTEN[$code] ?? null;
	if (!$p) return $name;
	return ft4a_pakket_naam($code, true);
}, 10, 2);
add_filter('woocommerce_product_get_short_description', function ($d, $prod) {
	if (is_admin() || ft4a_lang() === 'nl' || !get_post_meta($prod->get_id(), '_ft4a_pakket', true)) return $d;
	return '';
}, 10, 2);
add_filter('woocommerce_order_item_name', function ($name, $item) {
	if (is_admin() || ft4a_lang() === 'nl' || !is_callable([$item, 'get_product']) || !($prod = $item->get_product())) return $name;
	return $prod->get_name();
}, 10, 2);

/* ---------- Winkel instellen (eenmalig) ---------- */
/* Een tekstkader (vcard-txt) wordt een videokaart: het kader direct vóór de kaart met een van de video-nummers in $next ('id1|id2'). */
function ft4a_txt_to_video($html, $vid, $next) {
	$ids = implode('|', array_map(function ($i) { return preg_quote($i, '~'); }, explode('|', $next)));
	$pre = preg_match('~class="vf" data-v="\d+" aria-label="([^":]+):~', $html, $m) ? $m[1] : 'Video';
	$html = preg_replace_callback('~<article class="vcard vcard-txt">(?:(?!</article>).)*?<h3>(.*?)</h3>(?:(?!</article>).)*?</article>(\s*<article class="vcard"><button type="button" class="vf" data-v="(?:' . $ids . ')")~s', function ($m) use ($vid, $pre) {
		$t = trim(wp_strip_all_tags($m[1]));
		$a = esc_attr($pre . ': ' . $t); $h = esc_html($t);
		return '<article class="vcard"><button type="button" class="vf" data-v="' . $vid . '" aria-label="' . $a . '"><span class="vf-play"></span><span class="vf-t">' . $h . '</span></button><div class="vc-b"><h3>' . $h . '</h3></div></article>' . $m[2];
	}, $html, 1);
	return ft4a_vf_fill($html);
}
/* Een tekstkader wordt een videokaart: het kader direct ná de kaart met een van de video-nummers in $prev ('id1|id2'). */
function ft4a_txt_after_video($html, $vid, $prev) {
	$ids = implode('|', array_map(function ($i) { return preg_quote($i, '~'); }, explode('|', $prev)));
	$pre = preg_match('~class="vf" data-v="\d+" aria-label="([^":]+):~', $html, $m) ? $m[1] : 'Video';
	$html = preg_replace_callback('~(<button type="button" class="vf" data-v="(?:' . $ids . ')"(?:(?!</article>).)*</article>\s*)<article class="vcard vcard-txt">(?:(?!</article>).)*?<h3>(.*?)</h3>(?:(?!</article>).)*?</article>~s', function ($m) use ($vid, $pre) {
		$t = trim(wp_strip_all_tags($m[2]));
		$a = esc_attr($pre . ': ' . $t); $h = esc_html($t);
		return $m[1] . '<article class="vcard"><button type="button" class="vf" data-v="' . $vid . '" aria-label="' . $a . '"><span class="vf-play"></span><span class="vf-t">' . $h . '</span></button><div class="vc-b"><h3>' . $h . '</h3></div></article>';
	}, $html, 1);
	return ft4a_vf_fill($html);
}
/* Videoknoppen zonder achtergrond en afspeelicoon krijgen die van een andere videoknop op dezelfde pagina. */
function ft4a_vf_fill($html) {
	if (!preg_match('~<button type="button" class="vf" data-v="\d+" aria-label="[^"]*">(<svg class="vf-bg".*?<span class="vf-play">.*?</span>)<span class="vf-t">~s', $html, $n)) return $html;
	return preg_replace('~(<button type="button" class="vf" data-v="\d+" aria-label="[^"]*">)<span class="vf-play"></span>(<span class="vf-t">)~', '$1' . str_replace(['\\', '$'], ['\\\\', '\\$'], $n[1]) . '$2', $html);
}
/* Video's vervangen in de FT4A-pagina's, ook als die in de editor zijn aangepast (alleen het video-nummer wordt gewisseld). */
const FT4A_VIDEO_SWAPS = ['1041093530' => '1246189153', '1041094615' => '1246213715', '1041124658' => '1246212372', '1041126827' => '1246228561', '1041128451' => '1246220608', '1041133513' => '1246241188', '1041134416' => '1246241192', '1040376504' => '1246497996', '1040750701' => '1246498020', '1017956127' => '1246504447', '1246504447' => '1017956127', '1017576809' => '1246504447', '1017956127#2' => '1246509473', '1029183704' => '1246512993', '1023922450' => '1246516704', '1029537307' => '1246518527', 'txt:1246520081' => '1033805766|1246521331', '1033805766' => '1246521331', 'txt:fill' => 'none', 'after:1246523192' => '1246521331|1033805766', 'after:1246524991' => '1246523192', 'after:1246528121' => '1246524991', '1034115541' => '1246530168', 'after:1246530188' => '1034115541|1246530168', '1034441788' => '1246530191', '1034128060' => '1246530194', '1034737992' => '1246530074', '1034727399' => '1246530075', '1034732682' => '1246530077', '1034450214' => '1246530078', '1246504447@nl' => '1246805929', '1246509473@nl' => '1246806113', '1246512993@nl' => '1246806093', '1246516704@nl' => '1246806081', '1246518527@nl' => '1246806065', '1246520081@nl' => '1246806053', '1246521331@nl' => '1246806047', '1246523192@nl' => '1246806036', '1246524991@nl' => '1246806017', '1246528121@nl' => '1246806016', '1246530168@nl' => '1246805997', '1246530188@nl' => '1246805979', '1246530191@nl' => '1246805974', '1246530194@nl' => '1246805959', '1246530074@nl' => '1246805955', '1246530075@nl' => '1246805931', '1246530077@nl' => '1246805933', '1246530078@nl' => '1246805932', '1037148074' => '1246867094', 'after:1246867075' => '1246867094|1037148074', '1037155573' => '1246867024', '1037156213' => '1246867025', '1037154440' => '1246867022', '1037153009' => '1246867023', '1037157435' => '1246867182', 'after:1246867172' => '1246867182|1037157435', 'after:1246867154' => '1246867172', 'after:1246867133' => '1246867154', 'after:1246867111' => '1246867133', 'after:1246867106' => '1246867111'];
add_action('admin_init', function () {
	if (!current_user_can('manage_options')) return;
	$done = (array) get_option('ft4a_video_swaps', []);
	$todo = array_diff_key(FT4A_VIDEO_SWAPS, array_flip($done));
	if (!$todo) return;
	global $wpdb;
	$ids = get_posts(['post_type' => 'page', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => '_ft4a_page', 'meta_value' => 1]);
	foreach ($ids as $id) {
		$old = (string) get_post_field('post_content', $id, 'raw');
		$new = $old;
		$plang = get_post_meta($id, '_ft4a_lang', true) ?: 'nl';
		foreach ($todo as $from => $to) { $from = preg_replace('/#.*/', '', (string) $from); if (preg_match('/@(\w+)$/', $from, $lm)) { if ($lm[1] !== $plang) continue; $from = substr($from, 0, -strlen($lm[0])); } if (strpos($from, 'txt:') === 0) { $new = ft4a_txt_to_video($new, substr($from, 4), $to); continue; } if (strpos($from, 'after:') === 0) { $new = ft4a_txt_after_video($new, substr($from, 6), $to); continue; } $new = str_replace('data-v="' . $from . '"', 'data-v="' . $to . '"', $new); }
		if ($new === $old) continue;
		$h = get_post_meta($id, '_ft4a_hash', true);
		$wpdb->update($wpdb->posts, ['post_content' => $new], ['ID' => $id]);
		clean_post_cache($id);
		if ($h === md5($old)) update_post_meta($id, '_ft4a_hash', md5($new));
	}
	update_option('ft4a_video_swaps', array_merge($done, array_map('strval', array_keys($todo))));
});

add_action('admin_init', function () {
	if (!class_exists('WC_Product_Simple') || get_option('ft4a_shop_v2') || !current_user_can('manage_woocommerce')) return;
	foreach (['woocommerce_currency'=>'EUR','woocommerce_default_country'=>'BE','woocommerce_price_num_decimals'=>'0','woocommerce_price_thousand_sep'=>'.','woocommerce_price_decimal_sep'=>',','woocommerce_currency_pos'=>'left_space','woocommerce_enable_guest_checkout'=>'no','woocommerce_enable_signup_and_login_from_checkout'=>'yes','woocommerce_enable_checkout_login_reminder'=>'yes','woocommerce_calc_taxes'=>'no','woocommerce_enable_coupons'=>'no','woocommerce_enable_reviews'=>'no'] as $k => $v) update_option($k, $v);
	update_option('woocommerce_onboarding_profile', ['skipped' => true, 'completed' => true]);
	update_option('woocommerce_coming_soon', 'no');
	update_option('woocommerce_store_pages_only', 'no');
	foreach (FT4A_PAKKETTEN as $code => $p) {
		if (isset(FT4A_CLUB_CODES[$code]) || ft4a_product_id($code)) continue;
		$prod = new WC_Product_Simple();
		$nr = $code === 'TRIAL' ? 'Trial' : 'Pakket ' . substr($code, 1);
		$prod->set_name('FT4A ' . $nr . ' – ' . $p[0] . ($code === 'TRIAL' ? ' (7 dagen gratis)' : ' (' . strtolower($p[1]) . ')'));
		$prod->set_regular_price((string) $p[2]);
		$prod->set_virtual(true);
		$prod->set_sold_individually(true);
		$prod->set_status('publish');
		$prod->set_catalog_visibility('hidden');
		$prod->set_short_description(FT4A_DESC[$p[3]] . ' Looptijd: ' . $p[1] . ($p[1] === '50 jaar' ? ', met alle updates van de software.' : '.'));
		$pid = $prod->save();
		update_post_meta($pid, '_ft4a_pakket', $code);
	}
	update_option('ft4a_shop_v2', 1);
});

/* Clubpakketten (14/11/2026): ontbrekende producten C1–C4 aanmaken */
add_action('admin_init', function () {
	if (!class_exists('WC_Product_Simple') || get_option('ft4a_club_v1') || !current_user_can('manage_woocommerce')) return;
	foreach (FT4A_CLUB_CODES as $code => $n) {
		if (ft4a_product_id($code)) continue;
		$p = FT4A_PAKKETTEN[$code];
		$prod = new WC_Product_Simple();
		$prod->set_name(ft4a_pakket_naam($code));
		$prod->set_regular_price((string) $p[2]);
		$prod->set_virtual(true);
		$prod->set_sold_individually(true);
		$prod->set_status('publish');
		$prod->set_catalog_visibility('hidden');
		$prod->set_short_description($n . ' licentiecodes op naam van je club: elke trainer krijgt een eigen code voor de offline software. Looptijd: ' . $p[1] . ($p[1] === '50 jaar' ? ', met alle updates van de software.' : '.'));
		$pid = $prod->save();
		update_post_meta($pid, '_ft4a_pakket', $code);
	}
	update_option('ft4a_club_v1', 1);
}, 20);

/* Nieuwe prijzen (12/11/2026): bestaande WooCommerce-producten eenmalig bijwerken */
add_action('admin_init', function () {
	if (!class_exists('WC_Product_Simple') || get_option('ft4a_prices_2026_11') || !current_user_can('manage_woocommerce')) return;
	foreach (FT4A_PAKKETTEN as $code => $p) {
		if ($code === 'TRIAL' || !($pid = ft4a_product_id($code)) || !($prod = wc_get_product($pid))) continue;
		$prod->set_regular_price((string) $p[2]);
		$prod->set_sale_price('');
		$prod->save();
	}
	update_option('ft4a_prices_2026_11', 1);
});

// Proefperiode is 7 dagen (vanaf plugin 1.6.0): bestaand trial-product bijwerken
add_action('admin_init', function () {
	if (!class_exists('WC_Product_Simple') || get_option('ft4a_trial7_50j') || !current_user_can('manage_woocommerce')) return;
	if (($pid = ft4a_product_id('TRIAL')) && ($prod = wc_get_product($pid))) {
		$prod->set_name('FT4A Trial – Trial (7 dagen gratis)');
		$prod->set_short_description(FT4A_DESC['compleet'] . ' Looptijd: 7 dagen.');
		$prod->save();
	}
	foreach (['P4','P5','P6'] as $c) if (($pid = ft4a_product_id($c)) && ($prod = wc_get_product($pid))) {
		$p = FT4A_PAKKETTEN[$c];
		$prod->set_name('FT4A Pakket ' . substr($c, 1) . ' – ' . $p[0] . ' (50 jaar)');
		$prod->set_short_description(FT4A_DESC[$p[3]] . ' Looptijd: 50 jaar, met alle updates van de software.');
		$prod->save();
	}
	update_option('ft4a_trial7_50j', 1);
});

/* ---------- Leden beheren in het profiel ---------- */
function ft4a_profile_fields($user) {
	if (!current_user_can('edit_users')) return;
	$f = function ($k) use ($user) { $t = ft4a_until($user->ID, $k); return $t ? wp_date('Y-m-d', $t) : ''; };
	echo '<h2>FT4A-lidmaatschap</h2><table class="form-table"><tr><th><label for="ft4a_db_tot">Online / database tot</label></th><td><input type="date" name="ft4a_db_tot" id="ft4a_db_tot" value="' . esc_attr($f('_ft4a_db_tot')) . '"></td></tr><tr><th><label for="ft4a_offline_tot">Offline software tot</label></th><td><input type="date" name="ft4a_offline_tot" id="ft4a_offline_tot" value="' . esc_attr($f('_ft4a_offline_tot')) . '"><p class="description">Leeg laten = geen toegang. Handig om bestaande leden van footballtraining4all.com over te zetten.</p></td></tr></table>';
}
add_action('show_user_profile', 'ft4a_profile_fields');
add_action('edit_user_profile', 'ft4a_profile_fields');
function ft4a_profile_save($uid) {
	if (!current_user_can('edit_users')) return;
	foreach (['ft4a_db_tot' => '_ft4a_db_tot', 'ft4a_offline_tot' => '_ft4a_offline_tot'] as $in => $meta) {
		if (!isset($_POST[$in])) continue;
		$v = sanitize_text_field(wp_unslash($_POST[$in]));
		if ($v === '') delete_user_meta($uid, $meta); else update_user_meta($uid, $meta, strtotime($v . ' 23:59:59'));
	}
}
add_action('personal_options_update', 'ft4a_profile_save');
add_action('edit_user_profile_update', 'ft4a_profile_save');

/* ---------- Types ---------- */
function ft4a_register_types() {
	register_post_type('ft4a_oefening', [
		'labels' => ['name'=>'Ledenoefeningen','singular_name'=>'Ledenoefening','add_new_item'=>'Nieuwe oefening','edit_item'=>'Oefening bewerken','menu_name'=>'Ledenoefeningen','all_items'=>'Alle oefeningen'],
		'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'show_in_rest' => true,
		'menu_icon' => 'dashicons-awards', 'menu_position' => 21,
		'supports' => ['title','editor','author','thumbnail'],
	]);
	register_taxonomy('ft4a_categorie', 'ft4a_oefening', [
		'labels' => ['name'=>'Categorieën','singular_name'=>'Categorie'],
		'public' => false, 'show_ui' => true, 'show_admin_column' => true, 'show_in_rest' => true, 'hierarchical' => true,
	]);
}
add_action('init', 'ft4a_register_types');

register_activation_hook(__FILE__, function () {
	ft4a_register_types();
	foreach (FT4A_CATS as $c) { if (!term_exists($c, 'ft4a_categorie')) wp_insert_term($c, 'ft4a_categorie'); }
	ft4a_setup_site();
});

/* ---------- Website: pagina's en opmaak ---------- */
/* Alle FT4A-pagina's (startpagina + 11 pagina's, in alle 18 talen) staan als gewone WordPress-pagina's
   en zijn in de WordPress-editor te bewerken. Nederlands: /<sleutel>/ (startpagina: 'startpagina', getoond op /).
   Andere talen: bovenliggende pagina met de taalprefix (= startpagina van die taal, /de/) met de pagina's
   eronder (/de/uebungen/). De teksten in de plugin dienen alleen als beginversie: een pagina die in de editor
   is aangepast wordt bij updates niet meer overschreven (behalve met 'Pagina's opnieuw instellen'). */
function ft4a_write_page($page, $data, $force, $key, $lang) {
	if ($page) {
		$h = get_post_meta($page->ID, '_ft4a_hash', true);
		$cur = md5($page->post_content);
		/* oefeningenpagina's waarvan buiten de plugin om enkel video-ID's gewisseld zijn (12/11/2026): niet als handmatige aanpassing beschouwen */
		$known = ['bf7b1f77832606d705561b2f2cae246e','b563cb4010c5016b81185f61359e9a4d','633845138e3dccb4884fcc7396fa2855','a98f0e23fdfdcff4815795ebf525c497','4bd5c8a20ae4e8ef24716b9b421873a1','7a0bccb24ea332a059e1460b2365544c','8f5893635fee752813179c1e19be77a6','79e1b50b0c632a1fef9eabbe8d541152','655dabce97e149dcda7c52d75d9f7521','ae5d540913ff3b331ebfada1354dc68f','a6bd5d9e500bf3d7a57b585222ae2f6f','2c49d6a73ac8de7bc3e22f90f6c4ecfb','4e222e59ebc939b1062c833da44a4d2a','54a592292ed2d471b861b6989ee6dd2b','ebdc19cae2363f7d19142b47d7159f2f','d78c3bd9f05b48edbb585aaccb052419','6eda357859e3891041f8beaacb4e1078','6adf15800011d4f5a60839c0a56cf582','3cf0ce9a864c9953cde27f072fc7e6a3','122ab206007944ce21306a991c4a7778','96691d0d5b4fbc1f604b690a94f2c2ff','4c15e23454fff02c1902919488e37507','f34ea455de6e7ea37054ed5c4bcefc57','46151632c753f6bf8cde7f8ffa0e49fc','b5bb78ca814d1f6c37181d9df08797ea','7737afa20abaec29e9b81c6bd61817a4','ec04ba2c8b3f8710dda9f7a1ec51fd2b','8694f1d12e5e943f294312a345178f1b','93ab719bf5a8a2253d85af73878411b6','41b5a3c6030168baefcd50516a684fec','2948d2a1c6c99b09cb61b122b585eee5','dcdb4e014ea6f72fc0b1e50f48549e77','68417d1d8b8c93c064c49ee6f9e7a4af','b9885f25b8080c367af650a161d5e61b','56334c77d0d5de4acaa766a28c5451c4','2b3ed4bf0f8c7bfa9c4647e431059ae1'];
		if (!$force && $h && $h !== $cur && !in_array($cur, $known, true)) $id = $page->ID; // aangepast in de editor: laten staan
		else { $data['ID'] = $page->ID; $id = wp_update_post(wp_slash($data)); $upd = true; }
	} else { $id = wp_insert_post(wp_slash($data)); $upd = true; }
	if (!$id || is_wp_error($id)) return 0;
	update_post_meta($id, '_ft4a_page', 1);
	update_post_meta($id, '_ft4a_key', $key);
	update_post_meta($id, '_ft4a_lang', $lang);
	if (!empty($upd)) update_post_meta($id, '_ft4a_hash', md5(get_post_field('post_content', $id, 'raw')));
	return (int) $id;
}
function ft4a_find_page($key, $lang) {
	$q = get_posts(['post_type' => 'page', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids',
		'meta_query' => [['key' => '_ft4a_key', 'value' => $key], ['key' => '_ft4a_lang', 'value' => $lang]]]);
	return $q ? get_post($q[0]) : null;
}
function ft4a_setup_site($force = false) {
	kses_remove_filters();
	foreach (FT4A_LANGS as $lang => $l) {
		$dir = ft4a_site_dir($lang);
		$titles = json_decode((string) @file_get_contents($dir . 'pages/index.json'), true) ?: [];
		$wrap = function ($html) { return "<!-- wp:html -->\n" . $html . "\n<!-- /wp:html -->"; };
		/* startpagina van de taal */
		$home = @file_get_contents($dir . 'home.html');
		$parent = 0;
		if ($home !== false) {
			$page = ft4a_find_page('home', $lang) ?: ($lang === 'nl' ? get_page_by_path('startpagina', OBJECT, 'page') : get_page_by_path($l[0], OBJECT, 'page'));
			$slug = $lang === 'nl' ? 'startpagina' : $l[0];
			$title = $lang === 'nl' ? 'Startpagina' : 'Home – ' . $l[3];
			$parent = ft4a_write_page($page, ['post_title'=>$title,'post_name'=>$slug,'post_content'=>$wrap($home),'post_status'=>'publish','post_type'=>'page','post_parent'=>0,'comment_status'=>'closed'], $force, 'home', $lang);
		}
		if ($lang !== 'nl' && !$parent) continue;
		foreach ($titles as $key => $title) {
			$html = @file_get_contents($dir . 'pages/' . $key . '.html');
			if ($html === false) continue;
			$slug = ft4a_slug($key, $lang);
			$page = ft4a_find_page($key, $lang);
			if (!$page && $lang === 'nl') $page = get_page_by_path($key, OBJECT, 'page');
			if (!$page && $lang !== 'nl') $page = get_page_by_path($l[0] . '/' . $slug, OBJECT, 'page');
			ft4a_write_page($page, ['post_title'=>$title,'post_name'=>$slug,'post_content'=>$wrap($html),'post_status'=>'publish','post_type'=>'page','post_parent'=>$lang === 'nl' ? 0 : $parent,'comment_status'=>'closed'], $force, $key, $lang);
		}
	}
	delete_transient('ft4a_page_ids');
	kses_init_filters();
	if (!get_option('permalink_structure')) update_option('permalink_structure', '/%postname%/');
	if (in_array(get_option('blogname'), ['', 'Software and Football Software', 'My WordPress Site', 'Mijn WordPress site'], true)) update_option('blogname', 'FT4A.com');
	update_option('blogdescription', 'Software en voetbaloefeningen voor de moderne voetbaltrainer');
	if (get_option('WPLANG') !== 'nl_NL') {
		require_once ABSPATH . 'wp-admin/includes/translation-install.php';
		if (function_exists('wp_download_language_pack')) { $l = wp_download_language_pack('nl_NL'); if ($l) update_option('WPLANG', $l); }
	}
	update_option('ft4a_site_version', FT4A_SITE_VER);
	flush_rewrite_rules();
}
add_action('admin_init', function () {
	if (current_user_can('manage_options') && get_option('ft4a_site_version') !== FT4A_SITE_VER) ft4a_setup_site();
});
add_filter('template_include', function ($tpl) {
	$ours = ft4a_current_key() !== null
		|| (function_exists('is_cart') && (is_cart() || is_checkout() || is_account_page()));
	return $ours ? FT4A_DIR . 'templates/page.php' : $tpl;
}, 99);
add_action('template_redirect', function () {
	if (function_exists('is_shop') && (is_shop() || is_singular('product') || is_product_category())) { wp_safe_redirect(ft4a_url('prijzen')); exit; }
}, 5);
add_filter('document_title_parts', function ($t) { if (is_front_page()) { $t['title'] = 'FT4A.com'; $t['tagline'] = 'Software en voetbaloefeningen voor de moderne voetbaltrainer'; } return $t; });

/* ---------- Hulp-links in de software (vanaf 2.39.3, 09/11/2026) ----------
   ft4a.com/instructievideos/?video=tekenprogramma|animatie&lang=<taal van het programma>
   -> softwarepagina in die taal, bij de instructievideo's (#instructievideos). */
add_action('init', function () {
	$path = strtolower(trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/'));
	if (!preg_match('#^(?:([a-z]{2}(?:-[a-z]{2})?)/)?instructievideos$#', $path, $m)) return;
	$l = strtolower(sanitize_text_field(wp_unslash($_GET['lang'] ?? ($m[1] ?? ''))));
	$map = ['nb' => 'no', 'nn' => 'no', 'en-gb' => 'en', 'pt-pt' => 'pt'];
	if (isset($map[$l])) $l = $map[$l];
	if (!isset(FT4A_LANGS[$l])) { $s = substr($l, 0, 2); $l = isset(FT4A_LANGS[$s]) ? $s : ($l === '' ? 'nl' : 'en'); }
	nocache_headers();
	wp_redirect(ft4a_url('software#instructievideos', $l), 302);
	exit;
}, 1);
add_action('template_redirect', function () {
	if (ft4a_current_key() !== 'software') return;
	ob_start(function ($html) {
		/* het anker staat sinds 2.7.1 in de pagina zelf; alleen voor oude (in de editor aangepaste) pagina's zonder anker: bij de video's zetten */
		if (strpos($html, 'id="instructievideos"') !== false) return $html;
		$i = strpos($html, 'class="vcard"');
		if ($i === false) return $html;
		$k = strrpos(substr($html, 0, $i), '<div><span class="eyebrow">');
		return $k === false ? $html : substr_replace($html, '<div id="instructievideos" style="scroll-margin-top:96px"><span class="eyebrow">', $k, strlen('<div><span class="eyebrow">'));
	});
}, 20);

/* ---------- Beheerpagina ---------- */
add_action('admin_menu', function () {
	add_menu_page('FT4A', 'FT4A', 'manage_options', 'ft4a', 'ft4a_admin_page', 'dashicons-superhero', 3);
	add_submenu_page('ft4a', 'Leden importeren', 'Leden importeren', 'manage_options', 'ft4a-import', 'ft4a_import_page');
});

/* ---------- Leden importeren (overzetten van de oude site) ---------- */
function ft4a_import_date($v) {
	$v = strtolower(trim((string) $v));
	if ($v === '' || $v === '-') return 0;
	if ($v === 'onbeperkt' || $v === 'levenslang') return time() + 50 * YEAR_IN_SECONDS;
	$t = strtotime($v . ' 23:59:59');
	return $t ?: 0;
}
function ft4a_import_rows($file) {
	$rows = [];
	if (!$file || !is_readable($file)) return $rows;
	$fh = fopen($file, 'r');
	$head = null;
	while (($r = fgetcsv($fh, 0, ',', '"', '\\')) !== false) {
		if (count($r) === 1 && strpos($r[0], ';') !== false) $r = str_getcsv($r[0], ';', '"', '\\');
		$r = array_map('trim', $r);
		if ($head === null) { $r[0] = preg_replace('/^\xEF\xBB\xBF/', '', $r[0]); $head = array_map('strtolower', $r); continue; }
		if (count(array_filter($r, 'strlen')) === 0) continue;
		$rows[] = array_combine($head, array_pad(array_slice($r, 0, count($head)), count($head), ''));
	}
	fclose($fh);
	return $rows;
}
function ft4a_import_run($rows, $save) {
	$res = ['nieuw' => [], 'bijgewerkt' => [], 'overgeslagen' => []];
	$seen = [];
	foreach ($rows as $r) {
		$email = sanitize_email($r['email'] ?? '');
		$naam = sanitize_text_field($r['naam'] ?? '');
		if (!$email || !is_email($email)) { $res['overgeslagen'][] = ($naam ?: '?') . ' — geen geldig e-mailadres'; continue; }
		$off = ft4a_import_date($r['offline_tot'] ?? '');
		$db  = ft4a_import_date($r['online_tot'] ?? '');
		$key = strtolower($email);
		if (isset($seen[$key])) { $off = max($off, $seen[$key][0]); $db = max($db, $seen[$key][1]); }
		$seen[$key] = [$off, $db];
		if ($off <= time() && $db <= time()) { $res['overgeslagen'][] = $email . ' — lidmaatschap verlopen'; continue; }
		$user = get_user_by('email', $email);
		$label = $email . ' (' . ($off ? 'offline ' . ($off - time() > 40 * YEAR_IN_SECONDS ? '50 jaar' : date('d-m-Y', $off)) : 'geen offline') . ', ' . ($db ? 'online ' . ($db - time() > 40 * YEAR_IN_SECONDS ? '50 jaar' : date('d-m-Y', $db)) : 'geen online') . ')';
		if (!$save) { $res[$user ? 'bijgewerkt' : 'nieuw'][] = $label; continue; }
		if (!$user) {
			$login = sanitize_user($r['gebruikersnaam'] ?? '', true);
			if (!$login || username_exists($login)) $login = sanitize_user($email, true);
			if (username_exists($login)) $login = sanitize_user(strstr($email, '@', true) . '_' . wp_rand(100, 999), true);
			$uid = wp_insert_user([
				'user_login' => $login, 'user_email' => $email, 'user_pass' => wp_generate_password(24),
				'display_name' => $naam ?: $login, 'first_name' => $naam, 'nickname' => $naam ?: $login,
				'role' => get_role('customer') ? 'customer' : 'subscriber',
			]);
			if (is_wp_error($uid)) { $res['overgeslagen'][] = $email . ' — ' . $uid->get_error_message(); continue; }
			$user = get_user_by('id', $uid);
			$bucket = 'nieuw';
		} else { $bucket = 'bijgewerkt'; }
		if ($off) update_user_meta($user->ID, '_ft4a_offline_tot', max($off, ft4a_until($user->ID, '_ft4a_offline_tot')));
		if ($db)  update_user_meta($user->ID, '_ft4a_db_tot', max($db, ft4a_until($user->ID, '_ft4a_db_tot')));
		update_user_meta($user->ID, '_ft4a_pakket', 'MIGRATIE');
		update_user_meta($user->ID, '_ft4a_migrated', time());
		$res[$bucket][] = $label;
	}
	return $res;
}
function ft4a_import_page() {
	if (!current_user_can('manage_options')) return;
	echo '<div class="wrap"><h1>Leden importeren</h1><p>Zet actieve leden van de oude website over. Upload een CSV-bestand met de kolommen <code>email, gebruikersnaam, naam, offline_tot, online_tot</code> (datum als JJJJ-MM-DD, leeg = geen, <code>onbeperkt</code> = 50 jaar).</p>';
	echo '<p>Bestaande accounts (zelfde e-mailadres) worden bijgewerkt; de langste looptijd blijft behouden. Verlopen leden en rijen zonder e-mailadres worden overgeslagen. <strong>Er worden geen e-mails verstuurd.</strong></p>';
	if (isset($_POST['ft4a_import']) && check_admin_referer('ft4a_import')) {
		$save = !empty($_POST['ft4a_save']);
		$rows = ft4a_import_rows($_FILES['ft4a_csv']['tmp_name'] ?? '');
		if (!$rows) {
			echo '<div class="notice notice-error"><p>Geen rijen gevonden in het bestand.</p></div>';
		} else {
			$res = ft4a_import_run($rows, $save);
			echo '<div class="notice ' . ($save ? 'notice-success' : 'notice-info') . '"><p><strong>' . ($save ? 'Import uitgevoerd.' : 'Proefrun — er is niets opgeslagen.') . '</strong> ' . count($rows) . ' rijen: ' . count($res['nieuw']) . ' nieuw, ' . count($res['bijgewerkt']) . ' bijgewerkt, ' . count($res['overgeslagen']) . ' overgeslagen.</p></div>';
			foreach (['nieuw' => 'Nieuwe accounts', 'bijgewerkt' => 'Bestaande accounts bijgewerkt', 'overgeslagen' => 'Overgeslagen'] as $k => $t) {
				if (!$res[$k]) continue;
				echo '<details style="margin:8px 0"' . ($k === 'overgeslagen' ? ' open' : '') . '><summary><strong>' . esc_html($t) . ' (' . count($res[$k]) . ')</strong></summary><ul style="list-style:disc;margin-left:24px">';
				foreach ($res[$k] as $l) echo '<li>' . esc_html($l) . '</li>';
				echo '</ul></details>';
			}
		}
	}
	echo '<form method="post" enctype="multipart/form-data" style="margin-top:16px;padding:16px;background:#fff;border:1px solid #c3c4c7;max-width:760px">';
	wp_nonce_field('ft4a_import');
	echo '<p><input type="file" name="ft4a_csv" accept=".csv,text/csv" required></p>';
	echo '<p><label><input type="checkbox" name="ft4a_save" value="1"> Echt opslaan (zonder vinkje is het een proefrun)</label></p>';
	echo '<p><button class="button button-primary" name="ft4a_import" value="1">Importeren</button></p></form>';

	if (isset($_POST['ft4a_mail']) && check_admin_referer('ft4a_mail') && !empty($_POST['ft4a_mail_ok'])) {
		$n = 0;
		foreach (get_users(['meta_key' => '_ft4a_migrated', 'fields' => ['ID', 'user_login']]) as $u) {
			if (get_user_meta($u->ID, '_ft4a_pw_mail', true)) continue;
			if (function_exists('retrieve_password') && retrieve_password($u->user_login) === true) { update_user_meta($u->ID, '_ft4a_pw_mail', time()); $n++; }
		}
		echo '<div class="notice notice-success"><p>' . (int) $n . ' e-mails verstuurd om een wachtwoord in te stellen.</p></div>';
	}
	$mig = get_users(['meta_key' => '_ft4a_migrated', 'fields' => 'ID']);
	$sent = get_users(['meta_key' => '_ft4a_pw_mail', 'fields' => 'ID']);
	echo '<h2 style="margin-top:32px">Overgezette leden</h2><p>' . count($mig) . ' overgezette leden, waarvan ' . count($sent) . ' al een e-mail kregen om een wachtwoord in te stellen. Leden kunnen ook zelf op <em>Wachtwoord vergeten</em> klikken bij het inloggen.</p>';
	if (count($mig) > count($sent)) {
		echo '<form method="post" style="padding:16px;background:#fff;border:1px solid #c3c4c7;max-width:760px">';
		wp_nonce_field('ft4a_mail');
		echo '<p><label><input type="checkbox" name="ft4a_mail_ok" value="1" required> Ja, stuur de overgezette leden die nog geen e-mail kregen een link om hun wachtwoord in te stellen.</label></p><p><button class="button" name="ft4a_mail" value="1">E-mails versturen</button></p></form>';
	}
	echo '</div>';
}
function ft4a_admin_page() {
	if (isset($_POST['ft4a_reset']) && check_admin_referer('ft4a_reset')) { ft4a_setup_site(true); echo '<div class="notice notice-success"><p>De pagina’s zijn opnieuw ingesteld.</p></div>'; }
	if (isset($_POST['ft4a_langs']) && check_admin_referer('ft4a_langs')) {
		@set_time_limit(120);
		$done = ft4a_install_locales(25);
		$left = ft4a_missing_locales();
		$n = $left ? 0 : ft4a_update_translations();
		echo '<div class="notice notice-success"><p>Geïnstalleerd: ' . esc_html($done ? implode(', ', $done) : 'niets nieuws') . '. ' . ($left ? 'Nog te doen: ' . esc_html(implode(', ', $left)) . ' — klik nog eens.' : 'Alle WordPress-talen staan erop; ' . (int) $n . ' vertalingen van plugins en thema bijgewerkt.') . '</p></div>';
	}
	$ok = function ($b) { return $b ? '<span style="color:#008a20">✔</span>' : '<span style="color:#d63638">✘</span>'; };
	$woo = class_exists('WooCommerce');
	$mollie = defined('M4W_FILE') || class_exists('Mollie\\WooCommerce\\Plugin') || is_plugin_active('mollie-payments-for-woocommerce/mollie-payments-for-woocommerce.php');
	$prods = $woo && ft4a_product_id('P1') && ft4a_product_id('P6');
	echo '<div class="wrap"><h1>FT4A.com</h1><p>Overzicht van je website. De pagina’s worden door de plugin <strong>FT4A Leden</strong> beheerd.</p><table class="widefat striped" style="max-width:760px"><tbody>';
	echo '<tr><td>' . $ok(true) . ' Pagina’s en ledendatabase</td><td><a href="' . esc_url(home_url('/')) . '" target="_blank">Bekijk de website</a></td></tr>';
	echo '<tr><td>' . $ok($woo) . ' WooCommerce (verkoop van de pakketten)</td><td>' . ($woo ? 'Actief' : '<a href="' . esc_url(admin_url('plugin-install.php?s=woocommerce&tab=search&type=term')) . '">Installeer WooCommerce</a>') . '</td></tr>';
	echo '<tr><td>' . $ok($prods) . ' De 6 pakketten en de trial</td><td>' . ($prods ? '<a href="' . esc_url(admin_url('edit.php?post_type=product')) . '">Bekijk de producten</a>' : 'Worden aangemaakt zodra WooCommerce actief is') . '</td></tr>';
	echo '<tr><td>' . $ok($mollie) . ' Mollie (online betalen)</td><td>' . ($mollie ? '<a href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=mollie_settings')) . '">Mollie instellen</a>' : '<a href="' . esc_url(admin_url('plugin-install.php?s=mollie+payments+for+woocommerce&tab=search&type=term')) . '">Installeer Mollie</a>') . '</td></tr>';
	$miss = ft4a_missing_locales();
	echo '<tr><td>' . $ok(!$miss) . ' Taalpakketten voor de 18 talen (WooCommerce, inloggen, datums)</td><td>' . ($miss ? count($miss) . ' talen ontbreken nog' : 'Alles geïnstalleerd') . '</td></tr>';
	echo '<tr><td>' . $ok(true) . ' Ledenoefeningen</td><td><a href="' . esc_url(admin_url('edit.php?post_type=ft4a_oefening')) . '">Oefeningen beheren</a></td></tr>';
	echo '</tbody></table><form method="post" style="margin-top:20px">';
	wp_nonce_field('ft4a_reset');
	echo '<button class="button" name="ft4a_reset" value="1">Pagina’s opnieuw instellen</button> <span class="description">Zet de teksten van alle FT4A-pagina’s (alle talen) terug naar de beginversie uit de plugin. Let op: alles wat in de WordPress-editor is aangepast gaat dan verloren. Bij gewone updates blijven je aanpassingen bewaard.</span></form>';
	echo '<form method="post" style="margin-top:12px">';
	wp_nonce_field('ft4a_langs');
	echo '<button class="button" name="ft4a_langs" value="1">Taalpakketten installeren</button> <span class="description">Installeert de WordPress- en WooCommerce-vertalingen voor alle talen van de website.</span></form>' . ft4a_update_box() . '</div>';
}

/* ---------- Online software: /online/ toont de web-app (ft4a.com/app/) in de browser ----------
   /online/?oefening=<id> opent die oefening meteen. Alleen voor leden met een online of compleet pakket. */
/* ---------- Vertalingen van oefeningen ----------
   _ft4a_i18n (JSON): { taal: { t: titel, desc, coach, vari, players, txt: { origineel: vertaling } } }
   Nederlands = het origineel; andere talen zonder vertaling vallen terug op Engels, daarna op het origineel. */
function ft4a_oef_lang() {
	$l = sanitize_key(wp_unslash($_GET['lang'] ?? ''));
	return isset(FT4A_LANGS[$l]) ? $l : ft4a_lang();
}
function ft4a_oef_tr($id, $lang = null) {
	$lang = $lang ?: ft4a_oef_lang();
	if ($lang === 'nl') return null;
	$all = json_decode((string) get_post_meta($id, '_ft4a_i18n', true), true);
	if (!is_array($all)) return null;
	foreach ([$lang, $lang === 'en-us' ? 'en' : '', $lang === 'pt-br' ? 'pt' : '', 'en'] as $k) if ($k && !empty($all[$k]) && is_array($all[$k])) return $all[$k];
	return null;
}
function ft4a_oef_title($p) {
	$tr = ft4a_oef_tr($p->ID);
	return wp_strip_all_tags(!empty($tr['t']) ? $tr['t'] : $p->post_title);
}
/* Vertaling toepassen op de inhoud van een .ft4a-bestand (JSON) */
function ft4a_oef_apply($json, $tr) {
	$d = json_decode($json, true);
	if (!is_array($d) || !$tr) return $json;
	if (!empty($tr['t'])) $d['title'] = $tr['t'];
	if (isset($d['meta']) && is_array($d['meta'])) foreach (['desc', 'coach', 'vari', 'players', 'age', 'minutes'] as $k) if (isset($tr[$k]) && $tr[$k] !== '') $d['meta'][$k] = $tr[$k];
	if (!empty($tr['txt']) && isset($d['items']) && is_array($d['items'])) foreach ($d['items'] as &$it) if (is_array($it) && ($it['type'] ?? '') === 'text' && isset($tr['txt'][$it['text'] ?? ''])) $it['text'] = $tr['txt'][$it['text']];
	unset($it);
	return wp_json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
}
/* ---------- Herkomst van oefeningen uit de ledendatabase ----------
   Opent een lid een oefening uit de ledendatabase, dan krijgt het bestand "ft4aDb": <id van de oefening> mee
   (in de download en in de online software). Dat merkteken blijft bij aanpassen, bewaren in de bibliotheek,
   kopiëren en exporteren. Zo'n oefening mag het lid niet (opnieuw) publiceren in de ledenoefeningen, ook niet aangepast;
   bewaren in de eigen bibliotheek kan wel. Uitzondering: een ledenoefening die het lid zelf publiceerde.
   De FT4A-bibliotheek (geïmporteerde oefeningen, _ft4a_bron_nr) telt voor niemand als eigen oefening. */
function ft4a_db_mark_for($id, $uid = 0) {
	$id = (int) $id;
	$uid = (int) ($uid ?: get_current_user_id());
	if (!$id) return 0;
	if (get_post_meta($id, '_ft4a_bron_nr', true)) return $id;
	return (int) get_post_field('post_author', $id) === $uid ? 0 : $id;
}
function ft4a_db_blocked($d, $uid = 0) {
	$id = is_array($d) ? absint($d['ft4aDb'] ?? 0) : 0;
	if (!$id) return false;
	$p = get_post($id);
	if (!$p || $p->post_type !== 'ft4a_oefening') return false; // oefening bestaat niet meer: merkteken vervallen
	return ft4a_db_mark_for($id, $uid) > 0;
}
/* merkteken in de inhoud van een .ft4a-bestand (JSON) zetten of weghalen */
function ft4a_oef_mark($json, $mark) {
	$d = json_decode($json, true);
	if (!is_array($d)) return $json;
	if ($mark) $d['ft4aDb'] = (int) $mark;
	elseif (array_key_exists('ft4aDb', $d)) unset($d['ft4aDb']);
	else return $json;
	return wp_json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
}
/* de online software opent altijd in de taal van de pagina waarop het lid klikte */
function ft4a_online_url($id = 0) { $a = ['lang' => ft4a_lang()]; if ($id) $a = ['oefening' => (int) $id] + $a; return add_query_arg($a, home_url('/online/')); }
/* taalcode van de software bij een taal van de website */
function ft4a_app_lang($l) { return ['en-us' => 'en', 'pt-br' => 'pt', 'no' => 'nb'][$l] ?? $l; }
/* ---------- Voorbeeldoefeningen in de viewer, ook voor bezoekers ----------
   Op de pagina Oefeningen staat onder elk voorbeeld de shortcode [ft4a_viewer nr="73127"] (nr = nummer in de FT4A-bibliotheek,
   of id="<post-ID>"). Die toont de link "Oefening openen in de viewer". De link draagt een handtekening (vb=…), zodat iedereen
   precies díe oefening in de viewer (/online/?view=1) mag bekijken, zonder in te loggen. Andere oefeningen blijven voor leden. */
function ft4a_vb_sig($id) { return substr(hash_hmac('sha256', 'ft4a_view|' . (int) $id, wp_salt('auth')), 0, 20); }
function ft4a_vb_ok($id) {
	$s = (string) wp_unslash($_GET['vb'] ?? '');
	if (!$id || $s === '' || !hash_equals(ft4a_vb_sig($id), $s)) return false;
	$p = get_post($id);
	return $p && $p->post_type === 'ft4a_oefening' && $p->post_status === 'publish';
}
function ft4a_vb_find($nr) {
	global $wpdb;
	return (int) $wpdb->get_var($wpdb->prepare("SELECT m.post_id FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id AND p.post_type = 'ft4a_oefening' AND p.post_status = 'publish' WHERE m.meta_key = '_ft4a_bron_nr' AND m.meta_value = %s LIMIT 1", (string) (int) $nr));
}
function ft4a_vb_url($id) { return add_query_arg(['oefening' => (int) $id, 'view' => 1, 'vb' => ft4a_vb_sig($id), 'lang' => ft4a_lang()], home_url('/online/')); }
add_shortcode('ft4a_viewer', function ($atts) {
	$a = shortcode_atts(['nr' => '', 'id' => '', 'tekst' => ''], $atts, 'ft4a_viewer');
	$id = $a['id'] !== '' ? absint($a['id']) : ($a['nr'] !== '' ? ft4a_vb_find($a['nr']) : 0);
	$p = $id ? get_post($id) : null;
	if (!$p || $p->post_type !== 'ft4a_oefening' || $p->post_status !== 'publish') return current_user_can('edit_pages') ? '<p class="vc-open"><em>[ft4a_viewer: oefening ' . esc_html($a['nr'] ?: $a['id']) . ' niet gevonden]</em></p>' : '';
	// leden met een online of compleet pakket kunnen vanuit de viewer meteen bewerken
	$edit = is_user_logged_in() && ft4a_has_db() ? add_query_arg('from', 'view', ft4a_online_url($id)) : '';
	$label = $a['tekst'] !== '' ? $a['tekst'] : ft4a_t('Oefening openen in de viewer');
	ft4a_pop_footer();
	return '<p class="vc-open"><a href="' . esc_url(ft4a_vb_url($id)) . '" target="_blank" rel="noopener nofollow" data-ft4a-pop="1" data-view="1" data-edit="' . esc_attr($edit) . '" data-title="' . esc_attr(ft4a_oef_title($p)) . '"><svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M1.5 8s2.4-4.5 6.5-4.5S14.5 8 14.5 8s-2.4 4.5-6.5 4.5S1.5 8 1.5 8z" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="8" cy="8" r="2" fill="currentColor"/></svg>' . esc_html($label) . '</a></p>';
});
add_action('init', function () {
	if (trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/') !== 'online') return;
	$here = home_url(add_query_arg([]));
	// voorbeeldoefening met geldige handtekening: enkel bekijken, voor iedereen
	$pub = !empty($_GET['view']) && ft4a_vb_ok(absint($_GET['oefening'] ?? 0));
	if (!$pub && !is_user_logged_in()) { wp_safe_redirect(add_query_arg('redirect_to', urlencode($here), ft4a_url('inloggen'))); exit; }
	if (!$pub && !ft4a_has_db()) { wp_safe_redirect(add_query_arg('ft4a', 'geen_lid', ft4a_url('prijzen'))); exit; }
	$html = is_readable(ABSPATH . 'app/index.html') ? file_get_contents(ABSPATH . 'app/index.html') : '';
	if (!$html) { wp_safe_redirect(ft4a_url('software')); exit; }
	// geen installatiescherm in de browser; bestanden van /app/ met een absoluut adres
	$html = str_replace(['OSTJES_TABLET = true', 'href="icons/', "'serviceWorker' in navigator", '<link rel="manifest" href="manifest.webmanifest">'],
		['OSTJES_TABLET = false', 'href="' . esc_url(home_url('/app/icons/')), 'false', ''], $html);
	// oefeningen uit de ledendatabase na elkaar bekijken zonder telkens 'opslaan?': een ongewijzigde database-oefening telt als opgeslagen.
	// Na het openen krijgt de oefening het merkteken ft4aDb (zie ft4a_db_mark_for), ook bij een oud .fta-bestand.
	$html = str_replace(
		['if (!isDirty() || isBlank()) return true;', '.then(content => importTexts([{name, content}]))'],
		["if (!isDirty() || isBlank() || snapshot() === store.get('ft4a.dbSnap', '')) return true;", ".then(content => { const b4 = snapshot(); return Promise.resolve(importTexts([{name, content}])).then(() => { if (snapshot() !== b4) { if (window.FT4A_DB_MARK) doc.ft4aDb = window.FT4A_DB_MARK; else delete doc.ft4aDb; store.set('ft4a.dbSnap', snapshot()); } if (typeof window.ft4aOpened === 'function') window.ft4aOpened(); }); })"],
		$html);
	// De database-oefeningen openen in een venster (iframe) op ft4a.com zelf. De software zag dat als "ingebed op een vreemde pagina"
	// en verborg dan Video en Oefenblad afdrukken, en gaf bij Opslaan als bestand enkel tekst om te kopiëren. Een venster van
	// dezelfde website telt niet als ingebed.
	$html = str_replace('const FRAMED = (() => { try { return window.self !== window.top; } catch(e){ return true; } })();',
		'const FRAMED = (() => { try { return window.self !== window.top && window.top.location.origin !== window.location.origin; } catch(e){ return true; } })();', $html);
	// Leden met een online of compleet pakket: het lidmaatschap is de licentie. Geen proefperiode van 7 dagen in de browser,
	// geen opschrift "proefversie" en geen licentieknop (zie window.FT4A_MEMBER hieronder).
	$member = is_user_logged_in() && ft4a_has_db();
	if ($member) $html = str_replace("  function status(){\n", "  function status(){\n    if (window.FT4A_MEMBER) return { state: 'licensed', info: window.FT4A_MEMBER, left: Infinity, soon: false };\n", $html);
	// taal van de website gaat voor op de laatst gebruikte taal van de software
	$html = str_replace('let LANG = pickLang();', 'let LANG = (window.FT4A_SITE_LANG && I18N[window.FT4A_SITE_LANG]) ? window.FT4A_SITE_LANG : pickLang();', $html);
	// ?view=1: enkel bekijken (veld met animatie en de gegevens van de oefening), zie assets/ft4a-view.js
	$view = !empty($_GET['view']);
	$open = '<script>window.FT4A_SITE_LANG=' . wp_json_encode(ft4a_app_lang(ft4a_oef_lang())) . ';' . ($view ? 'window.FT4A_VIEW=true;' : '')
		. ($member ? 'window.FT4A_MEMBER=' . wp_json_encode(['n' => wp_get_current_user()->display_name, 'e' => '', 'p' => 'online'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) . ';' : '') . '</script>'
		. ($member ? '<style>#btnLic,#licBar,#licSoon{display:none!important}</style>' : '');
	if ($id = absint($_GET['oefening'] ?? 0)) {
		$p = get_post($id);
		$rel = $p ? get_post_meta($id, '_ft4a_path', true) : '';
		$att = $p ? (int) get_post_meta($id, '_ft4a_file', true) : 0;
		$ext = $rel ? pathinfo($rel, PATHINFO_EXTENSION) : ($att ? pathinfo((string) get_attached_file($att), PATHINFO_EXTENSION) : 'ft4a');
		if ($p && $p->post_type === 'ft4a_oefening') {
			// Bewerken na de viewer (from=view): de oefening is al geteld als geopend
			$url = $pub ? add_query_arg(['ft4a_download' => $id, 'lang' => ft4a_oef_lang(), 'vb' => ft4a_vb_sig($id)], home_url('/'))
				: wp_nonce_url(add_query_arg(array_filter(['ft4a_download' => $id, 'lang' => ft4a_oef_lang(), 'nc' => ($_GET['from'] ?? '') === 'view' ? 1 : 0]), home_url('/')), 'ft4a_dl_' . $id);
			$open .= '<script>window.FT4A_DB_MARK=' . ft4a_db_mark_for($id) . ';try{history.replaceState(null,"",location.pathname+"#open="+encodeURIComponent(' . wp_json_encode(html_entity_decode($url)) . ')+"&name="+encodeURIComponent(' . wp_json_encode(ft4a_oef_title($p) . '.' . ($ext ?: 'ft4a')) . '))}catch(e){}</script>';
		}
	}
	$html = preg_replace_callback('/<head([^>]*)>/i', function ($m) use ($open) { return $m[0] . $open; }, $html, 1);
	$html = $view ? ft4a_view_inject($html) : ft4a_publish_inject($html);
	nocache_headers();
	header('Content-Type: text/html; charset=utf-8');
	header('X-Robots-Tag: noindex');
	echo $html; exit;
}, 20);

/* ---------- Publiceren vanuit de online software ----------
   In /online/ komt in het menu Exporteren de knop "Publiceren op FT4A.com" (assets/ft4a-publish.js).
   De software stuurt de oefening (.ft4a-inhoud) en een voorbeeldafbeelding naar admin-ajax.php?action=ft4a_publish;
   de oefening wordt meteen een gepubliceerde ledenoefening van het ingelogde lid. Publiceert het lid dezelfde oefening
   (zelfde id in de bibliotheek van de software) opnieuw, dan kiest het: de vorige versie bijwerken of een nieuwe oefening. */
const FT4A_APP_SITE_LANG = ['nl'=>'nl','en'=>'en','fr'=>'fr','de'=>'de','es'=>'es','it'=>'it','pt'=>'pt','ro'=>'ro','pl'=>'pl','tr'=>'tr','ru'=>'ru','sv'=>'sv','da'=>'da','nb'=>'no','fi'=>'fi','ar'=>'ar'];
const FT4A_PUB_PER_HOUR = 20;
function ft4a_t_in($s, $lang) {
	static $dict = [];
	if ($lang === 'nl') return $s;
	if (!isset($dict[$lang])) $dict[$lang] = json_decode((string) @file_get_contents(__DIR__ . '/site/i18n/' . $lang . '/php.json'), true) ?: [];
	return $dict[$lang][$s] ?? $s;
}
function ft4a_publish_inject($html) {
	$names = function ($s) { $n = []; foreach (FT4A_APP_SITE_LANG as $a => $l) $n[$a] = ft4a_t_in($s, $l); return $n; };
	$cats = [];
	foreach (get_terms(['taxonomy' => 'ft4a_categorie', 'hide_empty' => false]) as $t) $cats[] = ['id' => (int) $t->term_id, 'name' => $t->name, 'n' => $names($t->name)];
	$ages = [];
	foreach (FT4A_AGES as $a) $ages[] = ['v' => $a, 'n' => $names($a)];
	$cfg = ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('ft4a_publish'), 'cats' => $cats, 'ages' => $ages, 'max' => FT4A_MAX_MB];
	$tag = '<script>window.FT4A_PUB=' . wp_json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) . ';</script>'
		. '<script src="' . esc_url(plugins_url('assets/ft4a-publish.js', __FILE__)) . '?v=' . FT4A_PUB_VER . '"></script>';
	$pos = strripos($html, '</body>');
	return $pos === false ? $html . $tag : substr_replace($html, $tag, $pos, 0);
}
/* viewer (/online/?view=1): na de software het script dat werkbalken en panelen verbergt en de gegevens van de oefening toont */
function ft4a_view_inject($html) {
	$tag = '<script src="' . esc_url(plugins_url('assets/ft4a-view.js', __FILE__)) . '?v=' . FT4A_VIEW_VER . '"></script>';
	$pos = strripos($html, '</body>');
	return $pos === false ? $html . $tag : substr_replace($html, $tag, $pos, 0);
}
add_action('wp_ajax_nopriv_ft4a_publish', function () { wp_send_json(['ok' => false, 'error' => 'login']); });
add_action('wp_ajax_nopriv_ft4a_pub_nonce', function () { wp_send_json(['ok' => false, 'error' => 'login']); });
/* nieuwe sleutel voor het formulier als de online software lang open stond */
add_action('wp_ajax_ft4a_pub_nonce', function () {
	nocache_headers();
	if (!ft4a_has_db()) wp_send_json(['ok' => false, 'error' => 'member']);
	wp_send_json(['ok' => true, 'nonce' => wp_create_nonce('ft4a_publish')]);
});
add_action('wp_ajax_ft4a_publish', function () {
	nocache_headers();
	$fail = function ($e, $x = []) { wp_send_json(['ok' => false, 'error' => $e] + $x); };
	if (!ft4a_has_db()) $fail('member');
	if (!wp_verify_nonce($_POST['_ft4a'] ?? '', 'ft4a_publish')) $fail('nonce');
	$uid = get_current_user_id();
	$json = (string) wp_unslash($_POST['bestand'] ?? '');
	if (strlen($json) > FT4A_MAX_MB * 1048576) $fail('size');
	$d = json_decode($json, true);
	// oefening uit de ledendatabase (ook aangepast): niet opnieuw publiceren, wel bewaren in de bibliotheek
	if (ft4a_db_blocked($d, $uid)) $fail('dbcopy');
	$title = sanitize_text_field(wp_unslash($_POST['titel'] ?? ''));
	$desc = sanitize_textarea_field(wp_unslash($_POST['beschrijving'] ?? ''));
	$cat = absint($_POST['categorie'] ?? 0);
	$age = sanitize_text_field(wp_unslash($_POST['leeftijd'] ?? ''));
	if (mb_strlen($title) < 3 || mb_strlen($title) > 120) $fail('title');
	if (!$cat || !term_exists($cat, 'ft4a_categorie')) $fail('cat');
	if (!in_array($age, FT4A_AGES, true)) $fail('age');
	if (!is_array($d) || empty($d['items']) || !is_array($d['items'])) $fail('file');
	unset($d['ft4aDb']);
	$d['app'] = 'FT4A.com';
	$d['title'] = $title;
	$json = wp_json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
	/* voorbeeldafbeelding (webp of png als data-URL) */
	$img = null;
	if (preg_match('#^data:image/(webp|png|jpeg);base64,([A-Za-z0-9+/=\s]+)$#', (string) ($_POST['afbeelding'] ?? ''), $m)) {
		$bin = base64_decode(preg_replace('/\s+/', '', $m[2]), true);
		if ($bin !== false && strlen($bin) <= 5 * 1048576 && @getimagesizefromstring($bin)) $img = [$m[1] === 'jpeg' ? 'jpg' : $m[1], $bin];
	}
	/* zelfde oefening al eerder gepubliceerd door dit lid? */
	$src = substr(preg_replace('/[^A-Za-z0-9_-]/', '', (string) ($d['id'] ?? '')), 0, 40);
	$mode = sanitize_key($_POST['mode'] ?? '');
	$old = 0;
	if ($src) {
		$q = get_posts(['post_type' => 'ft4a_oefening', 'author' => $uid, 'post_status' => ['publish', 'pending', 'draft'], 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_ft4a_src', 'meta_value' => $src]);
		$old = $q ? (int) $q[0] : 0;
	}
	if ($old && $mode !== 'update' && $mode !== 'new') $fail('exists', ['title' => html_entity_decode(get_the_title($old), ENT_QUOTES, 'UTF-8')]);
	if ($mode !== 'update') $old = 0;
	$count = (int) get_transient('ft4a_pub_' . $uid);
	if (!$old && $count >= FT4A_PUB_PER_HOUR && !current_user_can('edit_posts')) $fail('limit');
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	if ($old) {
		$pid = wp_update_post(['ID' => $old, 'post_title' => $title, 'post_content' => $desc], true);
	} else {
		$pid = wp_insert_post(['post_type' => 'ft4a_oefening', 'post_status' => 'publish', 'post_title' => $title, 'post_content' => $desc, 'post_author' => $uid], true);
	}
	if (is_wp_error($pid) || !$pid) $fail('save');
	$base = sanitize_file_name(remove_accents($title)) ?: 'oefening';
	$tmp = wp_tempnam($base . '.ft4a');
	file_put_contents($tmp, $json);
	$aid = media_handle_sideload(['name' => $base . '.ft4a', 'tmp_name' => $tmp], $pid);
	if (is_wp_error($aid)) { @unlink($tmp); if (!$old) wp_delete_post($pid, true); $fail('save'); }
	$prev = (int) get_post_meta($pid, '_ft4a_file', true);
	if ($old && $prev && $prev !== (int) $aid) wp_delete_attachment($prev, true);
	update_post_meta($pid, '_ft4a_file', (int) $aid);
	update_post_meta($pid, '_ft4a_anim', ft4a_detect_anim(get_attached_file($aid)) ? '1' : '0');
	update_post_meta($pid, '_ft4a_leeftijd', $age);
	if ($src) update_post_meta($pid, '_ft4a_src', $src);
	delete_post_meta($pid, '_ft4a_i18n'); // eventuele oude vertalingen passen niet meer bij de nieuwe tekst
	wp_set_object_terms($pid, [$cat], 'ft4a_categorie');
	if ($img) {
		$ti = wp_tempnam($base . '.' . $img[0]);
		file_put_contents($ti, $img[1]);
		$iid = media_handle_sideload(['name' => $base . '.' . $img[0], 'tmp_name' => $ti], $pid);
		if (!is_wp_error($iid)) {
			$pt = (int) get_post_thumbnail_id($pid);
			set_post_thumbnail($pid, $iid);
			if ($old && $pt && $pt !== (int) $iid) wp_delete_attachment($pt, true);
		} else @unlink($ti);
	}
	if (!$old) set_transient('ft4a_pub_' . $uid, $count + 1, HOUR_IN_SECONDS);
	$u = wp_get_current_user();
	wp_mail(get_option('admin_email'), $old ? 'FT4A: ledenoefening bijgewerkt' : 'FT4A: nieuwe ledenoefening',
		($old ? "Een oefening is bijgewerkt" : "Er is een nieuwe oefening gepubliceerd") . " door {$u->display_name} ({$u->user_email}), rechtstreeks vanuit de online software.\n\nTitel: $title\n\nBekijken of aanpassen in het beheer:\n" . admin_url('post.php?post=' . $pid . '&action=edit'));
	wp_send_json(['ok' => true, 'id' => (int) $pid, 'updated' => (bool) $old, 'list' => ft4a_url('ledenoefeningen'), 'open' => ft4a_online_url($pid)]);
});

/* ---------- FT4A-bestanden toelaten ---------- */
add_filter('upload_mimes', function ($m) { $m['ft4a'] = 'application/octet-stream'; $m['fta'] = 'application/octet-stream'; return $m; });
add_filter('wp_check_filetype_and_ext', function ($data, $file, $filename) {
	if (in_array($e = strtolower(pathinfo($filename, PATHINFO_EXTENSION)), ['ft4a', 'fta'], true)) {
		$data['ext'] = $e; $data['type'] = 'application/octet-stream'; $data['proper_filename'] = false;
	}
	return $data;
}, 10, 3);

/* ---------- Leden uit het beheer houden ---------- */
add_filter('show_admin_bar', function ($show) { return current_user_can('edit_posts') ? $show : false; });
add_action('admin_init', function () {
	if (!current_user_can('edit_posts') && !wp_doing_ajax()) { wp_safe_redirect(ft4a_url('account')); exit; }
});
add_filter('login_redirect', function ($to, $req, $user) {
	if ($user instanceof WP_User && !user_can($user, 'edit_posts')) return ft4a_url('account');
	return $to;
}, 10, 3);

/* ---------- Hulpjes ---------- */
function ft4a_flash($key) {
	$msgs = [
		'ingediend' => ['ok','Bedankt! Je oefening staat nu in de ledendatabase.'],
		'welkom'    => ['ok','Welkom bij FT4A! Je account is aangemaakt en je bent ingelogd.'],
		'verzonden' => ['ok','Bedankt voor je bericht. We antwoorden zo snel mogelijk.'],
		'uitgelogd' => ['ok','Je bent uitgelogd.'],
		'eerst_account' => ['ok','Maak eerst een gratis account aan of log in. Daarna ga je meteen verder naar betalen.'],
		'trial_gebruikt' => ['err','Je hebt de gratis proefperiode al gebruikt. Kies een pakket om verder te gaan.'],
		'geen_lid' => ['err','Voor de ledendatabase heb je een online of compleet pakket nodig.'],
		'winkel_dicht' => ['err','Bestellen is tijdelijk niet mogelijk. Neem contact met ons op.'],
	];
	if (!isset($msgs[$key])) return '';
	return '<div class="ft4a-msg ft4a-' . $msgs[$key][0] . '">' . esc_html(ft4a_t($msgs[$key][1])) . '</div>';
}
function ft4a_errors($errors) {
	if (!$errors) return '';
	$o = '<div class="ft4a-msg ft4a-err"><ul>';
	foreach ($errors as $e) $o .= '<li>' . esc_html($e) . '</li>';
	return $o . '</ul></div>';
}
function ft4a_select($name, $options, $selected = '', $placeholder = '') {
	if ($placeholder === '') $placeholder = ft4a_t('Kies…');
	$o = '<select name="' . esc_attr($name) . '" id="' . esc_attr($name) . '" required><option value="">' . esc_html($placeholder) . '</option>';
	foreach ($options as $v => $l) { $o .= '<option value="' . esc_attr($v) . '"' . selected($selected, $v, false) . '>' . esc_html(ft4a_t($l)) . '</option>'; }
	return $o . '</select>';
}
function ft4a_val($k) { return isset($_POST[$k]) ? esc_attr(wp_unslash($_POST[$k])) : ''; }
$GLOBALS['ft4a_errors'] = [];

/* ---------- Formulieren verwerken (voor de pagina wordt getoond) ---------- */
add_action('template_redirect', function () {
	// Pakket kopen: ?ft4a_koop=P1..P6 of TRIAL
	if (isset($_GET['ft4a_koop'])) {
		$code = strtoupper(sanitize_key($_GET['ft4a_koop']));
		if (!isset(FT4A_PAKKETTEN[$code])) { wp_safe_redirect(ft4a_url('prijzen')); exit; }
		if (!is_user_logged_in()) { wp_safe_redirect(add_query_arg(['ft4a'=>'eerst_account','redirect_to'=>urlencode(ft4a_url('home') . '?ft4a_koop=' . $code)], ft4a_url('account'))); exit; }
		if ($code === 'TRIAL' && get_user_meta(get_current_user_id(), '_ft4a_trial_used', true)) { wp_safe_redirect(add_query_arg('ft4a', 'trial_gebruikt', ft4a_url('prijzen'))); exit; }
		$pid = ft4a_product_id($code);
		if (!$pid || !function_exists('WC') || !WC()->cart) { wp_safe_redirect(add_query_arg('ft4a', 'winkel_dicht', ft4a_url('prijzen'))); exit; }
		WC()->cart->empty_cart();
		WC()->cart->add_to_cart($pid, 1);
		wp_safe_redirect(wc_get_checkout_url()); exit;
	}
	// Download
	if (isset($_GET['ft4a_download'])) {
		$id = absint($_GET['ft4a_download']);
		// voorbeeldoefening (viewer voor bezoekers): geldige handtekening volstaat, telt niet als geopend
		$pub = isset($_GET['vb']) && ft4a_vb_ok($id);
		if ($pub) $_GET['nc'] = 1;
		if (!$pub && !is_user_logged_in()) { wp_safe_redirect(add_query_arg('redirect_to', urlencode(ft4a_url('ledenoefeningen')), ft4a_url('inloggen'))); exit; }
		if (!$pub && !ft4a_has_db()) { wp_safe_redirect(add_query_arg('ft4a', 'geen_lid', ft4a_url('prijzen'))); exit; }
		if (!$pub && !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'ft4a_dl_' . $id)) wp_die(esc_html(ft4a_t('Deze downloadlink is verlopen. Vernieuw de pagina en probeer opnieuw.')));
		$p = get_post($id);
		$att = (int) get_post_meta($id, '_ft4a_file', true);
		$path = ($rel = get_post_meta($id, '_ft4a_path', true)) ? ft4a_bib_dir() . basename($rel) : '';
		if (!$p || $p->post_type !== 'ft4a_oefening' || ($p->post_status !== 'publish' && (int)$p->post_author !== get_current_user_id()) || (!$att && !($path && is_readable($path)))) wp_die(esc_html(ft4a_t('Deze oefening bestaat niet (meer).')));
		if (empty($_GET['nc'])) update_post_meta($id, '_ft4a_downloads', (int) get_post_meta($id, '_ft4a_downloads', true) + 1);
		$name = sanitize_file_name(remove_accents(ft4a_oef_title($p))) ?: 'oefening';
		$mark = ft4a_db_mark_for($id);
		// door een lid geüpload bestand (bijlage): een .ft4a-bestand ook via hier, met het merkteken
		if (!$path && ($af = (string) get_attached_file($att)) && strtolower(pathinfo($af, PATHINFO_EXTENSION)) === 'ft4a' && is_readable($af)) $path = $af;
		if ($path) {
			$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
			$body = $ext === 'ft4a' ? ft4a_oef_mark(ft4a_oef_apply((string) file_get_contents($path), ft4a_oef_tr($id)), $mark) : null;
			nocache_headers();
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="' . $name . '.' . $ext . '"');
			if ($body !== null) { header('Content-Length: ' . strlen($body)); echo $body; exit; }
			header('Content-Length: ' . filesize($path));
			readfile($path); exit;
		}
		wp_redirect(wp_get_attachment_url($att)); exit;
	}
	if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['ft4a_action'])) return;
	$action = sanitize_key($_POST['ft4a_action']);
	$errors = [];

	if ($action === 'register') {
		if (!wp_verify_nonce($_POST['_ft4a'] ?? '', 'ft4a_register')) $errors[] = ft4a_t('Het formulier is verlopen. Probeer opnieuw.');
		if (!empty($_POST['website'])) $errors[] = ft4a_t('Er ging iets mis. Probeer opnieuw.');
		$email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
		$user = $email;
		$first = sanitize_text_field(wp_unslash($_POST['voornaam'] ?? ''));
		$last = sanitize_text_field(wp_unslash($_POST['naam'] ?? ''));
		$name = trim($first . ' ' . $last);
		$land = strtoupper(sanitize_key($_POST['land'] ?? ''));
		$pw = (string) ($_POST['password'] ?? '');
		if ($first === '' || $last === '') $errors[] = ft4a_t('Vul je voornaam en naam in.');
		if ($land === '' || (function_exists('WC') && WC()->countries && !isset(WC()->countries->get_countries()[$land]))) $errors[] = ft4a_t('Kies je land.');
		if (!is_email($email)) $errors[] = ft4a_t('Vul een geldig e-mailadres in.');
		elseif (email_exists($email)) $errors[] = ft4a_t('Er bestaat al een account met dit e-mailadres. Log in of vraag een nieuw wachtwoord aan.');
		if (strlen($pw) < 8) $errors[] = ft4a_t('Kies een wachtwoord van minstens 8 tekens.');
		if ($pw !== (string) ($_POST['password2'] ?? '')) $errors[] = ft4a_t('De twee wachtwoorden zijn niet gelijk.');
		if (empty($_POST['akkoord'])) $errors[] = ft4a_t('Ga akkoord met de gebruikersovereenkomst om verder te gaan.');
		if (!$errors) {
			$uid = wp_insert_user(['user_login'=>$user,'user_email'=>$email,'user_pass'=>$pw,'display_name'=>$name,'nickname'=>$name,'first_name'=>$first,'last_name'=>$last,'role'=>get_option('default_role','subscriber')]);
			if (is_wp_error($uid)) { $errors[] = $uid->get_error_message(); }
			else {
				foreach (['billing_first_name' => $first, 'billing_last_name' => $last, 'billing_email' => $email, 'billing_country' => $land, '_ft4a_land' => $land] as $k => $v) update_user_meta($uid, $k, $v);
				wp_set_current_user($uid); wp_set_auth_cookie($uid, true);
				wp_mail(get_option('admin_email'), 'FT4A: nieuw lid ' . $name, "Er heeft zich een nieuw lid geregistreerd op FT4A.com.\n\nNaam: $last\nVoornaam: $first\nLand: $land\nE-mail: $email");
				$to = wp_validate_redirect(wp_unslash($_POST['redirect_to'] ?? ''), '');
				wp_safe_redirect($to ?: add_query_arg('ft4a', 'welkom', ft4a_url('account'))); exit;
			}
		}
	}

	if ($action === 'upload') {
		if (!is_user_logged_in()) $errors[] = ft4a_t('Log in om een oefening toe te voegen.');
		elseif (!ft4a_has_db()) $errors[] = ft4a_t('Voor het delen van oefeningen heb je een online of compleet pakket nodig.');
		if (!wp_verify_nonce($_POST['_ft4a'] ?? '', 'ft4a_upload')) $errors[] = ft4a_t('Het formulier is verlopen. Probeer opnieuw.');
		$title = sanitize_text_field(wp_unslash($_POST['titel'] ?? ''));
		$desc = wp_kses_post(wp_unslash($_POST['beschrijving'] ?? ''));
		$cat = absint($_POST['categorie'] ?? 0);
		$age = sanitize_text_field(wp_unslash($_POST['leeftijd'] ?? ''));
		if (strlen($title) < 3) $errors[] = ft4a_t('Geef je oefening een titel.');
		if (!$cat || !term_exists($cat, 'ft4a_categorie')) $errors[] = ft4a_t('Kies een categorie.');
		if (!in_array($age, FT4A_AGES, true)) $errors[] = ft4a_t('Kies een leeftijd.');
		$f = $_FILES['bestand'] ?? null;
		if (!$f || empty($f['name']) || $f['error'] !== UPLOAD_ERR_OK) $errors[] = ft4a_t('Kies het FT4A-bestand van je oefening.');
		elseif (!in_array(strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)), ['ft4a', 'fta'], true)) $errors[] = ft4a_t('Het bestand moet een FT4A-bestand zijn (eindigt op .ft4a).');
		elseif ($f['size'] > FT4A_MAX_MB * 1048576) $errors[] = sprintf(ft4a_t('Het bestand is groter dan %d MB.'), FT4A_MAX_MB);
		elseif (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) === 'ft4a' && ft4a_db_blocked(json_decode((string) @file_get_contents($f['tmp_name']), true))) $errors[] = ft4a_t('Deze oefening komt uit de oefeningendatabase. Je kunt ze aanpassen en in je bibliotheek bewaren, maar niet opnieuw delen in de ledenoefeningen.');
		$img = $_FILES['afbeelding'] ?? null;
		if ($img && !empty($img['name'])) {
			$ext = strtolower(pathinfo($img['name'], PATHINFO_EXTENSION));
			if (!in_array($ext, ['png','jpg','jpeg','webp'], true)) $errors[] = ft4a_t('De voorbeeldafbeelding moet een PNG, JPG of WEBP zijn.');
			elseif ($img['size'] > 5 * 1048576) $errors[] = ft4a_t('De voorbeeldafbeelding is groter dan 5 MB.');
		}
		if (!$errors) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$pid = wp_insert_post(['post_type'=>'ft4a_oefening','post_status'=>'publish','post_title'=>$title,'post_content'=>$desc,'post_author'=>get_current_user_id()], true);
			if (is_wp_error($pid)) { $errors[] = ft4a_t('Opslaan is niet gelukt. Probeer opnieuw.'); }
			else {
				wp_set_object_terms($pid, [$cat], 'ft4a_categorie');
				update_post_meta($pid, '_ft4a_leeftijd', $age);
				$aid = media_handle_upload('bestand', $pid);
				if (is_wp_error($aid)) { wp_delete_post($pid, true); $errors[] = ft4a_t('Uploaden van het bestand is niet gelukt:') . ' ' . $aid->get_error_message(); }
				else {
					update_post_meta($pid, '_ft4a_file', $aid);
					update_post_meta($pid, '_ft4a_anim', ft4a_detect_anim(get_attached_file($aid)) ? '1' : '0');
					if ($img && !empty($img['name'])) { $iid = media_handle_upload('afbeelding', $pid); if (!is_wp_error($iid)) set_post_thumbnail($pid, $iid); }
					$u = wp_get_current_user();
					wp_mail(get_option('admin_email'), 'FT4A: nieuwe ledenoefening', "Er is een nieuwe oefening ingediend door {$u->display_name} ({$u->user_email}).\n\nTitel: $title\n\nBekijken of aanpassen in het beheer:\n" . admin_url('post.php?post=' . $pid . '&action=edit'));
					wp_safe_redirect(add_query_arg('ft4a', 'ingediend', ft4a_url('account'))); exit;
				}
			}
		}
	}

	if ($action === 'contact') {
		if (!wp_verify_nonce($_POST['_ft4a'] ?? '', 'ft4a_contact')) $errors[] = ft4a_t('Het formulier is verlopen. Probeer opnieuw.');
		if (!empty($_POST['website'])) $errors[] = ft4a_t('Er ging iets mis. Probeer opnieuw.');
		$naam = sanitize_text_field(wp_unslash($_POST['naam'] ?? ''));
		$mail = sanitize_email(wp_unslash($_POST['email'] ?? ''));
		$onderwerp = sanitize_text_field(wp_unslash($_POST['onderwerp'] ?? ''));
		$bericht = sanitize_textarea_field(wp_unslash($_POST['bericht'] ?? ''));
		if (!$naam) $errors[] = ft4a_t('Vul je naam in.');
		if (!is_email($mail)) $errors[] = ft4a_t('Vul een geldig e-mailadres in.');
		if (strlen($bericht) < 10) $errors[] = ft4a_t('Schrijf een bericht van minstens 10 tekens.');
		if (!$errors) {
			$ok = wp_mail(get_option('admin_email'), 'FT4A contact: ' . ($onderwerp ?: 'Nieuw bericht'), "Naam: $naam\nE-mail: $mail\nOnderwerp: $onderwerp\n\n$bericht", ['Reply-To: ' . $naam . ' <' . $mail . '>']);
			if ($ok) { wp_safe_redirect(add_query_arg('ft4a', 'verzonden', ft4a_url('contact'))); exit; }
			$errors[] = ft4a_t('Je bericht kon niet worden verzonden. Stuur ons een WhatsApp-bericht op +32 456 41 11 84.');
		}
	}
	$GLOBALS['ft4a_errors'] = $errors;
});

/* ---------- Wisselkoersen (ECB, dagelijks automatisch bijgewerkt) voor prijzen in de eigen munt ---------- */
function ft4a_fx_rates() {
	$want = ['USD', 'GBP', 'PLN', 'SEK', 'NOK', 'DKK', 'RON', 'TRY', 'BRL'];
	$fx = get_transient('ft4a_fx');
	if (is_array($fx) && $fx) return $fx;
	$saved = get_option('ft4a_fx_last', []);
	$r = wp_remote_get('https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml', ['timeout' => 5]);
	if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200 && preg_match_all("/currency='([A-Z]{3})' rate='([0-9.]+)'/", wp_remote_retrieve_body($r), $m, PREG_SET_ORDER)) {
		$fx = [];
		foreach ($m as $x) if (in_array($x[1], $want, true)) $fx[$x[1]] = (float) $x[2];
		if (count($fx) >= 5) {
			if (preg_match("/time='([0-9-]+)'/", wp_remote_retrieve_body($r), $d)) $fx['_date'] = $d[1];
			update_option('ft4a_fx_last', $fx, false);
			set_transient('ft4a_fx', $fx, 12 * HOUR_IN_SECONDS);
			return $fx;
		}
	}
	/* bij een fout: laatst gekende koersen, en binnen een uur opnieuw proberen */
	$fx = $saved ?: ['USD' => 1.1193, 'GBP' => 0.8343, 'PLN' => 4.3843, 'SEK' => 10.996, 'NOK' => 10.5325, 'DKK' => 7.4753, 'RON' => 5.343, 'TRY' => 56.1199, 'BRL' => 6.1748, '_date' => '2026-11-09'];
	set_transient('ft4a_fx', $fx, HOUR_IN_SECONDS);
	return $fx;
}
add_action('wp_head', function () {
	if (ft4a_current_key() !== 'prijzen') return;
	echo '<script>window.FT4A_FX=' . wp_json_encode(ft4a_fx_rates()) . ';</script>' . "\n";
}, 1);

/* ---------- Software downloaden (versie uit /updates/versie.json, bestanden in /bestanden/) ---------- */
function ft4a_software_files() {
	$v = json_decode((string) @file_get_contents(ABSPATH . 'updates/versie.json'), true) ?: [];
	$ver = $v['ft4a']['version'] ?? ($v['version'] ?? '');
	if (!$ver) return ['', []];
	$out = [];
	$list = [
		'win'     => ["FT4A-Setup-$ver.exe", 'Windows', 'Windows 10 en 11', 'monitor'],
		'mac-arm' => ["FT4A-$ver-mac-arm64.zip", 'Mac met Apple-chip', 'M1, M2, M3, M4 en nieuwer', 'laptop'],
		'mac-x64' => ["FT4A-$ver-mac-x64.zip", 'Mac met Intel-processor', 'Oudere Macs met een Intel-processor', 'laptop'],
	];
	foreach ($list as $k => $f) {
		$p = ABSPATH . 'bestanden/' . $f[0];
		if (is_readable($p)) $out[$k] = ['url' => home_url('/bestanden/' . rawurlencode($f[0])), 'name' => $f[1], 'sub' => $f[2], 'ico' => $f[3], 'mb' => round(filesize($p) / 1048576)];
	}
	if (is_readable(ABSPATH . 'app/index.html')) $out['tablet'] = ['url' => home_url('/app/'), 'name' => 'Tablet-app', 'sub' => 'Open de app in de browser van je tablet en zet ze op je beginscherm.', 'ico' => 'tablet', 'mb' => 0];
	return [$ver, $out];
}
function ft4a_download_html($compact = false) {
	[$ver, $files] = ft4a_software_files();
	if (!$files) return '';
	$ico = [
		'monitor' => '<path d="M3 4h18v12H3z"/><path d="M8 20h8M12 16v4"/>',
		'laptop'  => '<path d="M5 5h14v10H5z"/><path d="M2 19h20l-2-4H4z"/>',
		'tablet'  => '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M11 18h2"/>',
	];
	$o = '';
	foreach ($files as $k => $f) {
		$btn = $k === 'tablet' ? ft4a_t('Openen') : ft4a_t('Download');
		$meta = $k === 'tablet' ? '' : '<span class="dl-meta">' . esc_html(sprintf(ft4a_t('Versie %s'), $ver)) . ' · ' . (int) $f['mb'] . ' MB</span>';
		$o .= '<article class="dl-card" data-k="' . esc_attr($k) . '"><svg class="dl-ico" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $ico[$f['ico']] . '</svg><div class="dl-b"><h3>' . esc_html(ft4a_t($f['name'])) . '</h3><p>' . esc_html(ft4a_t($f['sub'])) . '</p>' . $meta . '</div><a class="btn ' . ($k === 'tablet' ? 'btn-outline' : 'btn-primary') . ' btn-sm" href="' . esc_url($f['url']) . '"' . ($k === 'tablet' ? '' : ' download') . '>' . esc_html($btn) . '</a></article>';
	}
	$grid = '<div class="dl-grid' . ($compact ? ' dl-compact' : '') . '" data-rec="' . esc_attr(ft4a_t('Aanbevolen voor jouw toestel')) . '">' . $o . '</div>' . ft4a_dl_detect_js();
	if ($compact) return $grid;
	return '<div class="dl"><span class="eyebrow">' . esc_html(ft4a_t('Download')) . '</span><h2 class="ph2">' . esc_html(ft4a_t('Download de software')) . '</h2><p class="plead">' . esc_html(ft4a_t('Kies de versie voor je computer. Het programma start in de taal van je computer. Na je aankoop activeer je het met de licentiecode uit je e-mail.')) . '</p>' . $grid . '</div>';
}
/* Herkent het toestel van de bezoeker en zet de juiste download vooraan, met een label. Alle versies blijven zichtbaar. */
function ft4a_dl_detect_js() {
	static $done = false;
	if ($done) return '';
	$done = true;
	return <<<'JS'
<script>(function(){function det(){var n=navigator,ua=n.userAgent||'',p=(n.userAgentData&&n.userAgentData.platform)||n.platform||'';
if(/Android|iPhone|iPad|iPod/i.test(ua)||(/Mac/i.test(p)&&n.maxTouchPoints>1))return Promise.resolve('tablet');
if(/Win/i.test(p)||/Windows/i.test(ua))return Promise.resolve('win');
if(!/Mac/i.test(p)&&!/Macintosh/i.test(ua))return Promise.resolve('');
var gl=function(){try{var c=document.createElement('canvas').getContext('webgl'),d=c&&c.getExtension('WEBGL_debug_renderer_info'),r=d?String(c.getParameter(d.UNMASKED_RENDERER_WEBGL)):'';if(/Apple M\d/i.test(r))return 'mac-arm';if(/Intel|AMD|Radeon|NVIDIA/i.test(r))return 'mac-x64';}catch(e){}return 'mac';};
if(n.userAgentData&&n.userAgentData.getHighEntropyValues)return n.userAgentData.getHighEntropyValues(['architecture']).then(function(h){return h.architecture==='arm'?'mac-arm':(h.architecture==='x86'?'mac-x64':gl());},function(){return gl();});
return Promise.resolve(gl());}
function run(){det().then(function(k){if(!k)return;document.querySelectorAll('.dl-grid[data-rec]').forEach(function(g){var c=[].slice.call(g.querySelectorAll('.dl-card'));var m=c.filter(function(e){var d=e.getAttribute('data-k');return k==='mac'?d.indexOf('mac')===0:d===k;});if(!m.length)return;m.reverse().forEach(function(e){g.insertBefore(e,g.firstChild);});if(k==='mac')return;var e=m[0];e.classList.add('dl-rec');var b=document.createElement('span');b.className='dl-badge';b.textContent=g.getAttribute('data-rec');e.insertBefore(b,e.firstChild);});});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run);else run();})();</script>
JS;
}
add_shortcode('ft4a_download', function () { return ft4a_download_html(false); });

/* ---------- Oefeningenbibliotheek importeren (2128 oefeningen van footballtraining4all.com) ---------- */
function ft4a_bib_dir() {
	$key = get_option('ft4a_bib_key');
	if (!$key) { $key = wp_generate_password(16, false); update_option('ft4a_bib_key', $key, false); }
	$d = trailingslashit(wp_upload_dir()['basedir']) . 'ft4a-bib-' . $key . '/';
	if (!is_dir($d)) {
		wp_mkdir_p($d);
		@file_put_contents($d . '.htaccess', "Require all denied\nDeny from all\n");
		@file_put_contents($d . 'index.php', "<?php // stil\n");
	}
	return $d;
}
function ft4a_prev_dir() { $d = trailingslashit(wp_upload_dir()['basedir']) . 'ft4a-voorbeelden/'; if (!is_dir($d)) wp_mkdir_p($d); return $d; }
function ft4a_prev_url() { return trailingslashit(wp_upload_dir()['baseurl']) . 'ft4a-voorbeelden/'; }
/* Bevat de oefening een animatie? (.fta: AnimationStates met stappen, .ft4a: items met keys) */
function ft4a_detect_anim($path) {
	$txt = @file_get_contents($path, false, null, 0, 4194304);
	if ($txt === false || $txt === '') return false;
	$txt = preg_replace('/^\xEF\xBB\xBF/', '', $txt);
	if (ltrim($txt)[0] === '{') {
		$d = json_decode($txt, true);
		foreach ((array) ($d['items'] ?? []) as $it) if (!empty($it['keys'])) return true;
		return false;
	}
	return (bool) preg_match('/<AnimationStates>\s*</', $txt);
}
function ft4a_post_anim($pid) {
	$v = get_post_meta($pid, '_ft4a_anim', true);
	if ($v !== '') return $v === '1';
	$path = ($rel = get_post_meta($pid, '_ft4a_path', true)) ? ft4a_bib_dir() . basename($rel) : (($att = (int) get_post_meta($pid, '_ft4a_file', true)) ? get_attached_file($att) : '');
	$a = $path && is_readable($path) && ft4a_detect_anim($path);
	update_post_meta($pid, '_ft4a_anim', $a ? '1' : '0');
	return $a;
}
// Eenmalig alle bestaande oefeningen nakijken (in stappen, bij het openen van het beheer)
add_action('admin_init', function () {
	if (get_option('ft4a_anim_scan_v1') || !current_user_can('manage_options')) return;
	$ids = get_posts(['post_type' => 'ft4a_oefening', 'post_status' => 'any', 'posts_per_page' => 800, 'fields' => 'ids', 'meta_query' => [['key' => '_ft4a_anim', 'compare' => 'NOT EXISTS']]]);
	if (!$ids) { update_option('ft4a_anim_scan_v1', 1); return; }
	$start = microtime(true);
	foreach ($ids as $id) { ft4a_post_anim($id); if (microtime(true) - $start > 20) break; }
});
function ft4a_anim_icon() { return '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><circle cx="8" cy="8" r="7.2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M6.4 5v6l5-3z" fill="currentColor"/></svg>'; }
/* "meer dan 2100 oefeningen" in de teksten volgt het echte aantal (afgerond op honderdtallen) zolang er minder zijn */
function ft4a_fix_counts($s) {
	static $r = null;
	if ($r === null) { $n = (int) ft4a_oefening_count(); $r = $n >= 2100 || $n < 1 ? false : ($n < 100 ? $n : intdiv($n, 100) * 100); }
	if ($r === false || !is_string($s) || strpos($s, '2') === false) return $s;
	return preg_replace_callback('/(?<![\d.,])2([.,\x{00A0}\x{202F} ]?)100(?!\d)/u', function ($m) use ($r) {
		return $r >= 1000 ? intdiv($r, 1000) . $m[1] . str_pad((string) ($r % 1000), 3, '0', STR_PAD_LEFT) : (string) $r;
	}, $s);
}
/* Pagina met een formulier (beveiligingscode die na 12-24 uur verloopt): niet laten cachen door LiteSpeed Cache */
function ft4a_nocache() {
	if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
	do_action('litespeed_control_set_nocache', 'FT4A-formulier met beveiligingscode');
	return '';
}
function ft4a_oefening_count() {
	$n = get_transient('ft4a_count');
	if ($n === false) { $n = (int) (wp_count_posts('ft4a_oefening')->publish ?? 0); set_transient('ft4a_count', $n, HOUR_IN_SECONDS); }
	return (int) $n;
}
add_action('transition_post_status', function ($new, $old, $post) { if ($post->post_type === 'ft4a_oefening' && ($new === 'publish' || $old === 'publish')) delete_transient('ft4a_count'); }, 10, 3);
add_action('admin_menu', function () { add_submenu_page('ft4a', 'Oefeningen importeren', 'Oefeningen importeren', 'manage_options', 'ft4a-bib', 'ft4a_bib_page'); }, 20);
function ft4a_bib_page() {
	if (!current_user_can('manage_options')) return;
	$msg = '';
	if (isset($_POST['ft4a_bib_upload']) && check_admin_referer('ft4a_bib')) {
		$f = $_FILES['ft4a_bib_zip'] ?? null;
		if (!$f || $f['error'] || !class_exists('ZipArchive')) $msg = '<div class="notice notice-error"><p>Uploaden is niet gelukt' . (class_exists('ZipArchive') ? '' : ' (ZipArchive ontbreekt op de server)') . '.</p></div>';
		else {
			$z = new ZipArchive();
			if ($z->open($f['tmp_name']) !== true || ($man = $z->getFromName('manifest.json')) === false) $msg = '<div class="notice notice-error"><p>Dit is geen geldig importbestand (manifest.json ontbreekt).</p></div>';
			else {
				$dir = ft4a_bib_dir(); $n = 0;
				for ($i = 0; $i < $z->numFiles; $i++) {
					$name = $z->getNameIndex($i);
					if (preg_match('#^previews/(\d+\.webp)$#', $name, $pm)) { file_put_contents(ft4a_prev_dir() . $pm[1], $z->getFromIndex($i)); $np = ($np ?? 0) + 1; continue; }
					if (!preg_match('#^files/(\d+\.(?:fta|ft4a))$#', $name, $m)) continue;
					file_put_contents($dir . $m[1], $z->getFromIndex($i)); $n++;
				}
				$ni = 0;
				if (($tj = $z->getFromName('i18n.json')) !== false && is_array($tr = json_decode($tj, true))) {
					global $wpdb;
					foreach ($tr as $nr => $langs) {
						$pid = (int) $wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_ft4a_bron_nr' AND meta_value = %s LIMIT 1", (string) $nr));
						if (!$pid || !is_array($langs)) continue;
						$cur = json_decode((string) get_post_meta($pid, '_ft4a_i18n', true), true) ?: [];
						foreach ($langs as $l => $v) if (isset(FT4A_LANGS[$l]) && is_array($v)) $cur[$l] = $v;
						update_post_meta($pid, '_ft4a_i18n', wp_slash(wp_json_encode($cur, JSON_UNESCAPED_UNICODE)));
						$ni++;
					}
				}
				$z->close();
				if ($man !== '[]' || !$ni) file_put_contents($dir . 'manifest.json', $man);
				$msg = '<div class="notice notice-success"><p>' . (int) $n . ' bestanden en ' . (int) ($np ?? 0) . ' voorbeeldafbeeldingen uitgepakt' . ($ni ? ', vertalingen bijgewerkt voor ' . (int) $ni . ' oefeningen' : '') . '.' . ($n ? ' Klik nu op <strong>Oefeningen aanmaken</strong>.' : '') . '</p></div>';
			}
		}
	}
	$dir = ft4a_bib_dir();
	$items = is_readable($dir . 'manifest.json') ? (json_decode(file_get_contents($dir . 'manifest.json'), true) ?: []) : [];
	global $wpdb;
	$done = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_ft4a_bron_nr'");
	echo '<div class="wrap"><h1>Oefeningen importeren</h1>' . $msg . '<p>Zet de oefeningenbibliotheek in de ledendatabase. Elke oefening wordt een gepubliceerde ledenoefening (auteur: FT4A.com) met titel, categorie, leeftijd en omschrijving. De bestanden staan in een afgeschermde map en zijn alleen te downloaden voor leden met een online of compleet pakket. Opnieuw importeren maakt geen dubbele oefeningen.</p>';
	echo '<p><strong>In de database:</strong> ' . $done . ' geïmporteerde oefeningen' . ($items ? ' · <strong>klaar om te importeren:</strong> ' . count($items) : '') . '. Teller op de homepage: ' . ft4a_oefening_count() . '.</p>';
	echo '<form method="post" enctype="multipart/form-data" style="padding:16px;background:#fff;border:1px solid #c3c4c7;max-width:760px">';
	wp_nonce_field('ft4a_bib');
	echo '<p><strong>Stap 1.</strong> Kies het importbestand (ft4a-oefeningen-import.zip).</p><p><input type="file" name="ft4a_bib_zip" accept=".zip" required></p><p><button class="button button-primary" name="ft4a_bib_upload" value="1">Uploaden en uitpakken</button></p></form>';
	if ($items) {
		echo '<div style="padding:16px;background:#fff;border:1px solid #c3c4c7;max-width:760px;margin-top:12px"><p><strong>Stap 2.</strong> Maak de oefeningen aan (in stappen van 150, laat deze pagina open).</p><p><button class="button button-primary" id="ft4a-bib-go">Oefeningen aanmaken</button> <span id="ft4a-bib-st"></span></p><progress id="ft4a-bib-pr" max="' . count($items) . '" value="0" style="width:100%"></progress></div>';
		echo '<script>document.getElementById("ft4a-bib-go").onclick=async function(){this.disabled=true;let off=0,tot=' . count($items) . ',made=0,skip=0;const st=document.getElementById("ft4a-bib-st"),pr=document.getElementById("ft4a-bib-pr");while(off<tot){const fd=new FormData();fd.append("action","ft4a_bib_batch");fd.append("off",off);fd.append("_wpnonce","' . wp_create_nonce('ft4a_bib_batch') . '");let r;try{r=await (await fetch(ajaxurl,{method:"POST",body:fd,credentials:"same-origin"})).json();}catch(e){st.textContent="Fout, probeer opnieuw vanaf "+off;this.disabled=false;return;}if(!r.success){st.textContent="Fout: "+(r.data||"");this.disabled=false;return;}off=r.data.next;made+=r.data.made;skip+=r.data.skip;pr.value=off;st.textContent=off+" / "+tot+" · nieuw "+made+" · al aanwezig "+skip;}st.textContent+=" · klaar!";};</script>';
	}
	$tot = 0; foreach ((array) wp_count_posts('ft4a_oefening') as $c) $tot += (int) $c;
	echo '<div style="padding:16px;background:#fff;border:1px solid #d63638;max-width:760px;margin-top:24px"><h2 style="margin-top:0;color:#b32d2e">Database leegmaken</h2><p>Verwijdert <strong>alle ' . $tot . ' oefeningen</strong> uit de ledendatabase (geïmporteerde én door leden geüploade, elke status), met hun FT4A-bestanden, voorbeeldafbeeldingen en het importbestand op de server. Categorieën blijven bestaan. <strong>Dit kan niet ongedaan gemaakt worden.</strong></p><p><label>Typ <code>LEEGMAKEN</code> om te bevestigen: <input type="text" id="ft4a-wipe-ok" autocomplete="off"></label> <button class="button" id="ft4a-wipe-go" style="color:#b32d2e;border-color:#b32d2e">Database leegmaken</button> <span id="ft4a-wipe-st"></span></p></div>';
	echo '<script>document.getElementById("ft4a-wipe-go").onclick=async function(){if(document.getElementById("ft4a-wipe-ok").value!=="LEEGMAKEN"){alert("Typ LEEGMAKEN om te bevestigen.");return;}this.disabled=true;const st=document.getElementById("ft4a-wipe-st");let gone=0;for(;;){const fd=new FormData();fd.append("action","ft4a_bib_wipe");fd.append("_wpnonce","' . wp_create_nonce('ft4a_bib_wipe') . '");let r;try{r=await (await fetch(ajaxurl,{method:"POST",body:fd,credentials:"same-origin"})).json();}catch(e){st.textContent="Fout na "+gone+" verwijderd, klik opnieuw.";this.disabled=false;return;}if(!r.success){st.textContent="Fout: "+(r.data||"");this.disabled=false;return;}gone+=r.data.deleted;st.textContent=gone+" verwijderd, nog "+r.data.left;if(r.data.done){st.textContent="Klaar: "+gone+" oefeningen verwijderd, bestanden opgeruimd.";return;}}};</script>';
	echo '</div>';
}
add_action('wp_ajax_ft4a_bib_batch', function () {
	if (!current_user_can('manage_options') || !wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ft4a_bib_batch')) wp_send_json_error('geen toegang');
	@set_time_limit(120);
	$dir = ft4a_bib_dir();
	$items = json_decode((string) @file_get_contents($dir . 'manifest.json'), true) ?: [];
	$off = absint($_POST['off'] ?? 0); $slice = array_slice($items, $off, 150);
	global $wpdb;
	$have = array_flip($wpdb->get_col("SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_ft4a_bron_nr'"));
	$terms = [];
	foreach (get_terms(['taxonomy' => 'ft4a_categorie', 'hide_empty' => false]) as $t) $terms[$t->name] = (int) $t->term_id;
	wp_defer_term_counting(true); wp_suspend_cache_invalidation(true);
	$made = 0; $skip = 0;
	foreach ($slice as $it) {
		if (isset($have[(string) $it['nr']]) || !is_readable($dir . basename($it['f']))) { $skip++; continue; }
		$pid = wp_insert_post(['post_type' => 'ft4a_oefening', 'post_status' => 'publish', 'post_title' => wp_strip_all_tags($it['t']), 'post_content' => sanitize_textarea_field($it['d']), 'post_author' => get_current_user_id(), 'menu_order' => (int) $it['nr']], true);
		if (is_wp_error($pid)) continue;
		if (isset($terms[$it['c']])) wp_set_object_terms($pid, [$terms[$it['c']]], 'ft4a_categorie');
		if ($it['a']) update_post_meta($pid, '_ft4a_leeftijd', $it['a']);
		update_post_meta($pid, '_ft4a_path', basename($it['f']));
		update_post_meta($pid, '_ft4a_anim', ft4a_detect_anim($dir . basename($it['f'])) ? '1' : '0');
		update_post_meta($pid, '_ft4a_bron_nr', (string) $it['nr']);
		$made++;
	}
	wp_suspend_cache_invalidation(false); wp_defer_term_counting(false);
	delete_transient('ft4a_count');
	wp_send_json_success(['next' => $off + count($slice), 'made' => $made, 'skip' => $skip]);
});

/* Volgorde in de ledendatabase: geïmporteerde oefeningen krijgen hun bronnummer als menu_order (eenmalig voor bestaande oefeningen) */
add_action('init', function () {
	if (get_option('ft4a_volgorde') === '1') return;
	global $wpdb;
	$wpdb->query("UPDATE {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_ft4a_bron_nr' SET p.menu_order = CAST(m.meta_value AS UNSIGNED) WHERE p.post_type = 'ft4a_oefening'");
	if (function_exists('wp_cache_set_posts_last_changed')) wp_cache_set_posts_last_changed(); else wp_cache_set('last_changed', microtime(), 'posts');
	update_option('ft4a_volgorde', '1', true);
});

/* Ledendatabase volledig leegmaken (in stappen) */
add_action('wp_ajax_ft4a_bib_wipe', function () {
	if (!current_user_can('manage_options') || !wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ft4a_bib_wipe')) wp_send_json_error('geen toegang');
	@set_time_limit(120);
	$ids = get_posts(['post_type' => 'ft4a_oefening', 'post_status' => 'any', 'numberposts' => 200, 'fields' => 'ids', 'suppress_filters' => true, 'orderby' => 'ID']);
	$n = 0;
	wp_defer_term_counting(true);
	foreach ($ids as $id) {
		$att = array_filter(array_merge([(int) get_post_meta($id, '_ft4a_file', true), (int) get_post_thumbnail_id($id)], get_posts(['post_type' => 'attachment', 'post_parent' => $id, 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids'])));
		foreach (array_unique($att) as $a) wp_delete_attachment($a, true);
		if (wp_delete_post($id, true)) $n++;
	}
	wp_defer_term_counting(false);
	if ($ids && !$n) wp_send_json_error('oefeningen konden niet verwijderd worden');
	$left = 0; foreach ((array) wp_count_posts('ft4a_oefening') as $c) $left += (int) $c;
	$done = !$ids || !$left;
	if ($done) {
		foreach ([ft4a_bib_dir(), ft4a_prev_dir()] as $d) foreach ((array) glob($d . '*') as $f) if (is_file($f) && !in_array(basename($f), ['.htaccess', 'index.php'], true)) @unlink($f);
		delete_option('ft4a_anim_scan_v1');
	}
	delete_transient('ft4a_count');
	wp_send_json_success(['deleted' => $n, 'left' => $left, 'done' => $done]);
});

/* ---------- Shortcodes ---------- */
function ft4a_terms_link() { return 'https://www.footballtraining4all.com/' . ft4a_old_code() . '/'; }
function ft4a_login_form() {
	$redirect = isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : ft4a_url('account');
	return '<div class="ft4a-card"><h3>' . esc_html(ft4a_t('Inloggen')) . '</h3>' . wp_login_form(['echo'=>false,'redirect'=>$redirect,'label_username'=>ft4a_t('Gebruikersnaam of e-mailadres'),'label_password'=>ft4a_t('Wachtwoord'),'label_remember'=>ft4a_t('Ingelogd blijven'),'label_log_in'=>ft4a_t('Inloggen'),'remember'=>true])
		. '<p class="ft4a-small"><a href="' . esc_url(wp_lostpassword_url(ft4a_url('inloggen'))) . '">' . esc_html(ft4a_t('Wachtwoord vergeten?')) . '</a> · <a href="' . esc_url(ft4a_url('account')) . '#registreren">' . esc_html(ft4a_t('Nog geen account? Registreer je')) . '</a></p></div>';
}
/* landkeuze bij registreren: landen van WooCommerce (in de taal van de site), anders een tekstveld */
function ft4a_land_field() {
	$cur = strtoupper(sanitize_key($_POST['land'] ?? ''));
	$label = '<label for="land">' . esc_html(ft4a_t('Land')) . '</label>';
	if (!function_exists('WC') || !WC()->countries) return '<p>' . $label . '<input type="text" name="land" id="land" required maxlength="2" value="' . esc_attr($cur) . '" autocomplete="country"></p>';
	$o = '<option value="">' . esc_html(ft4a_t('Kies je land')) . '</option>';
	foreach (WC()->countries->get_countries() as $code => $nm) $o .= '<option value="' . esc_attr($code) . '"' . selected($cur, $code, false) . '>' . esc_html(html_entity_decode($nm)) . '</option>';
	return '<p>' . $label . '<select name="land" id="land" required autocomplete="country">' . $o . '</select></p>';
}
function ft4a_register_form() {
	$terms = sprintf(ft4a_t('Ik ga akkoord met de %1$sgebruikersovereenkomst%2$s en het %3$sprivacybeleid%4$s.'), '<a href="' . esc_url(ft4a_terms_link() . 'termsofuse.aspx') . '" target="_blank" rel="noopener">', '</a>', '<a href="' . esc_url(ft4a_terms_link() . 'privacy.aspx') . '" target="_blank" rel="noopener">', '</a>');
	return '<div class="ft4a-card" id="registreren"><h3>' . esc_html(ft4a_t('Account aanmaken')) . '</h3><form method="post" class="ft4a-form">'
		. ft4a_nocache() . wp_nonce_field('ft4a_register', '_ft4a', true, false) . '<input type="hidden" name="ft4a_action" value="register"><input type="hidden" name="redirect_to" value="' . esc_attr(isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : '') . '">'
		. '<p class="ft4a-hp"><label for="website">' . esc_html(ft4a_t('Laat dit veld leeg')) . '</label><input type="text" name="website" id="website" tabindex="-1" autocomplete="off"></p>'
		. '<div class="ft4a-row"><p><label for="naam">' . esc_html(ft4a_lang() === 'nl' ? 'Naam' : ft4a_t('Achternaam')) . '</label><input type="text" name="naam" id="naam" required value="' . ft4a_val('naam') . '" autocomplete="family-name"></p>'
		. '<p><label for="voornaam">' . esc_html(ft4a_t('Voornaam')) . '</label><input type="text" name="voornaam" id="voornaam" required value="' . ft4a_val('voornaam') . '" autocomplete="given-name"></p></div>'
		. ft4a_land_field()
		. '<p><label for="email">' . esc_html(ft4a_t('E-mailadres')) . '</label><input type="email" name="email" id="email" required value="' . ft4a_val('email') . '" autocomplete="email"></p>'
		. '<div class="ft4a-row"><p><label for="password">' . esc_html(ft4a_t('Wachtwoord')) . '</label><input type="password" name="password" id="password" required minlength="8" autocomplete="new-password"></p>'
		. '<p><label for="password2">' . esc_html(ft4a_t('Herhaal wachtwoord')) . '</label><input type="password" name="password2" id="password2" required minlength="8" autocomplete="new-password"></p></div>'
		. '<p class="ft4a-check"><input type="checkbox" name="akkoord" id="akkoord" value="1" required><label for="akkoord">' . $terms . '</label></p>'
		. '<p><button type="submit" class="btn btn-primary">' . esc_html(ft4a_t('Account aanmaken')) . '</button></p></form></div>';
}
add_shortcode('ft4a_login', function () {
	if (is_user_logged_in()) { $u = wp_get_current_user(); return '<div class="ft4a-card"><p>' . sprintf(esc_html(ft4a_t('Je bent ingelogd als %s.')), '<strong>' . esc_html($u->display_name) . '</strong>') . '</p><p><a class="btn btn-primary" href="' . esc_url(ft4a_url('account')) . '">' . esc_html(ft4a_t('Naar mijn account')) . '</a> <a class="btn btn-outline" href="' . esc_url(wp_logout_url(add_query_arg('ft4a','uitgelogd',ft4a_url('inloggen')))) . '">' . esc_html(ft4a_t('Uitloggen')) . '</a></p></div>'; }
	return ft4a_flash(sanitize_key($_GET['ft4a'] ?? '')) . ft4a_login_form();
});
add_shortcode('ft4a_account', function () {
	$out = ft4a_flash(sanitize_key($_GET['ft4a'] ?? '')) . ft4a_errors($GLOBALS['ft4a_errors']);
	if (!is_user_logged_in()) return $out . '<div class="ft4a-grid2">' . ft4a_login_form() . ft4a_register_form() . '</div>';
	$u = wp_get_current_user();
	$out .= '<div class="ft4a-card ft4a-hello"><div><h3>' . esc_html(sprintf(ft4a_t('Hallo %s'), $u->display_name)) . '</h3><p class="ft4a-small">' . esc_html(sprintf(ft4a_t('Ingelogd als %s'), $u->user_login)) . ($u->user_login !== $u->user_email ? ' · ' . esc_html($u->user_email) : '') . '</p></div><div class="ft4a-actions"><a class="btn btn-primary" href="' . esc_url(ft4a_url('oefening-toevoegen')) . '">' . esc_html(ft4a_t('Oefening toevoegen')) . '</a><a class="btn btn-outline" href="' . esc_url(ft4a_url('ledenoefeningen')) . '">' . esc_html(ft4a_t('Ledenoefeningen')) . '</a><a class="btn btn-outline" href="' . esc_url(wp_logout_url(add_query_arg('ft4a','uitgelogd',ft4a_url('inloggen')))) . '">' . esc_html(ft4a_t('Uitloggen')) . '</a></div></div>';
	$orders = function_exists('wc_get_account_endpoint_url') ? '<a class="btn btn-outline btn-sm" href="' . esc_url(wc_get_account_endpoint_url('orders')) . '">' . esc_html(ft4a_t('Mijn bestellingen')) . '</a>' : '';
	$out .= '<div class="ft4a-card"><h3>' . esc_html(ft4a_t('Mijn lidmaatschap')) . '</h3><table class="ft4a-table"><tbody><tr><td>' . esc_html(ft4a_t('Online software en oefeningen-database')) . '</td><td>' . ft4a_status_label(ft4a_until($u->ID, '_ft4a_db_tot')) . '</td></tr><tr><td>' . esc_html(ft4a_t('Offline software op je computer')) . '</td><td>' . ft4a_status_label(ft4a_until($u->ID, '_ft4a_offline_tot')) . '</td></tr></tbody></table><p class="ft4a-actions" style="margin-top:16px"><a class="btn btn-primary btn-sm" href="' . esc_url(ft4a_url('prijzen')) . '">' . esc_html(ft4a_t('Pakket kopen of verlengen')) . '</a>' . $orders . '</p></div>';
	if (($dl = ft4a_download_html(true)) && (ft4a_until($u->ID, '_ft4a_offline_tot') > time() || current_user_can('manage_options'))) $out .= '<div class="ft4a-card"><h3>' . esc_html(ft4a_t('Software downloaden')) . '</h3>' . $dl . '</div>';
	$q = new WP_Query(['post_type'=>'ft4a_oefening','author'=>$u->ID,'post_status'=>['publish','pending','draft'],'posts_per_page'=>50]);
	$out .= '<div class="ft4a-card"><h3>' . esc_html(ft4a_t('Mijn oefeningen')) . '</h3>';
	if (!$q->have_posts()) { $out .= '<p>' . esc_html(ft4a_t('Je hebt nog geen oefeningen ingediend.')) . ' <a href="' . esc_url(ft4a_url('oefening-toevoegen')) . '">' . esc_html(ft4a_t('Voeg je eerste oefening toe')) . '</a>.</p>'; }
	else {
		$out .= '<table class="ft4a-table"><thead><tr><th>' . esc_html(ft4a_t('Titel')) . '</th><th>' . esc_html(ft4a_t('Categorie')) . '</th><th>' . esc_html(ft4a_t('Status')) . '</th><th>' . esc_html(ft4a_t('Downloads')) . '</th></tr></thead><tbody>';
		foreach ($q->posts as $p) {
			$t = array_map('ft4a_t', wp_get_post_terms($p->ID, 'ft4a_categorie', ['fields'=>'names']));
			$st = $p->post_status === 'publish' ? '<span class="ft4a-pill ok">' . esc_html(ft4a_t('Gepubliceerd')) . '</span>' : '<span class="ft4a-pill wait">' . esc_html(ft4a_t('Wacht op goedkeuring')) . '</span>';
			$out .= '<tr><td>' . esc_html($p->post_title) . '</td><td>' . esc_html(implode(', ', $t)) . '</td><td>' . $st . '</td><td>' . (int) get_post_meta($p->ID, '_ft4a_downloads', true) . '</td></tr>';
		}
		$out .= '</tbody></table>';
	}
	return $out . '</div>';
});
add_shortcode('ft4a_upload', function () {
	if (!is_user_logged_in()) return '<div class="ft4a-card"><h3>' . esc_html(ft4a_t('Log in om een oefening toe te voegen')) . '</h3><p>' . esc_html(ft4a_t('Alleen leden kunnen oefeningen in de database plaatsen.')) . '</p><p><a class="btn btn-primary" href="' . esc_url(add_query_arg('redirect_to', urlencode(ft4a_url('oefening-toevoegen')), ft4a_url('inloggen'))) . '">' . esc_html(ft4a_t('Inloggen')) . '</a> <a class="btn btn-outline" href="' . esc_url(ft4a_url('account')) . '#registreren">' . esc_html(ft4a_t('Account aanmaken')) . '</a></p></div>';
	if (!ft4a_has_db()) return '<div class="ft4a-card"><h3>' . esc_html(ft4a_t('Kies een online of compleet pakket')) . '</h3><p>' . esc_html(ft4a_t('Met een online of compleet pakket kun je oefeningen delen in de ledendatabase en de oefeningen van andere leden downloaden.')) . '</p><p><a class="btn btn-primary" href="' . esc_url(ft4a_url('prijzen')) . '">' . esc_html(ft4a_t('Bekijk de pakketten')) . '</a></p></div>';
	$cats = [];
	foreach (get_terms(['taxonomy'=>'ft4a_categorie','hide_empty'=>false]) as $t) $cats[$t->term_id] = $t->name;
	$ages = array_combine(FT4A_AGES, FT4A_AGES);
	return ft4a_errors($GLOBALS['ft4a_errors']) . '<div class="ft4a-card"><form method="post" enctype="multipart/form-data" class="ft4a-form">'
		. ft4a_nocache() . wp_nonce_field('ft4a_upload', '_ft4a', true, false) . '<input type="hidden" name="ft4a_action" value="upload">'
		. '<p><label for="titel">' . esc_html(ft4a_t('Titel van de oefening')) . '</label><input type="text" name="titel" id="titel" required maxlength="120" value="' . ft4a_val('titel') . '" placeholder="' . esc_attr(ft4a_t('Bijvoorbeeld: Positiespel 4 tegen 2 met omschakeling')) . '"></p>'
		. '<div class="ft4a-row"><p><label for="categorie">' . esc_html(ft4a_t('Categorie')) . '</label>' . ft4a_select('categorie', $cats, ft4a_val('categorie')) . '</p><p><label for="leeftijd">' . esc_html(ft4a_t('Leeftijd')) . '</label>' . ft4a_select('leeftijd', $ages, ft4a_val('leeftijd')) . '</p></div>'
		. '<p><label for="beschrijving">' . esc_html(ft4a_t('Uitleg')) . '</label><textarea name="beschrijving" id="beschrijving" rows="6" placeholder="' . esc_attr(ft4a_t('Organisatie, verloop, aantal spelers, coachingspunten…')) . '">' . (isset($_POST['beschrijving']) ? esc_textarea(wp_unslash($_POST['beschrijving'])) : '') . '</textarea></p>'
		. '<p><label for="bestand">' . esc_html(ft4a_t('FT4A-bestand')) . ' <span class="ft4a-small">(.ft4a / .fta, max. ' . FT4A_MAX_MB . ' MB)</span></label><input type="file" name="bestand" id="bestand" accept=".ft4a,.fta" required></p>'
		. '<p><label for="afbeelding">' . esc_html(ft4a_t('Voorbeeldafbeelding')) . ' <span class="ft4a-small">(' . esc_html(ft4a_t('wordt automatisch gemaakt uit je bestand; je kunt ook zelf een PNG of JPG kiezen')) . ')</span></label><input type="file" name="afbeelding" id="afbeelding" accept=".png,.jpg,.jpeg,.webp"><span id="ft4a-autoprev" class="ft4a-autoprev" hidden><img alt=""><span class="ft4a-small">' . esc_html(ft4a_t('Voorbeeld gemaakt uit je oefening.')) . '</span></span></p>'
		. '<p class="ft4a-small">' . esc_html(ft4a_t('Maak je oefening in de FT4A-software en sla ze op via Bestand → Opslaan. Na het indienen staat je oefening meteen in de ledendatabase.')) . '</p>'
		. '<p><button type="submit" class="btn btn-primary">' . esc_html(ft4a_t('Oefening indienen')) . '</button></p></form></div>'
		. '<script src="' . esc_url(plugins_url('assets/ft4a-preview.js', __FILE__)) . '?v=' . FT4A_SITE_VER . '" defer></script>'
		. '<script>document.addEventListener("DOMContentLoaded",function(){var f=document.getElementById("bestand"),a=document.getElementById("afbeelding"),box=document.getElementById("ft4a-autoprev"),own=false;if(!f||!a)return;'
		. 'a.addEventListener("change",function(){if(a.files.length&&!a.dataset.auto){own=true;box.hidden=true;}delete a.dataset.auto;});'
		. 'f.addEventListener("change",async function(){if(own||!f.files.length||!window.FT4ARender||typeof DataTransfer==="undefined")return;try{var file=f.files[0],txt=await file.text(),blob=await window.FT4ARender(txt,file.name,640);if(!blob)return;'
		. 'var dt=new DataTransfer();dt.items.add(new File([blob],file.name.replace(/\\.[^.]+$/,"")+".webp",{type:"image/webp"}));a.dataset.auto="1";a.files=dt.files;a.dispatchEvent(new Event("change"));'
		. 'box.querySelector("img").src=URL.createObjectURL(blob);box.hidden=false;}catch(e){console.log("FT4A voorbeeld:",e);}});});</script>';
});
/* Venster met de viewer (veld met animatie en de gegevens van de oefening, /online/?view=1), voor links met data-ft4a-pop.
   data-view="1": de href is al het adres van de viewer (voorbeeldoefeningen); anders wordt view=1 toegevoegd.
   data-edit: adres voor "Bewerken" (leeg = geen knop); zonder data-edit wordt het de href met from=view. Eén keer per pagina. */
/* voor shortcodes in paginateksten: het venster onderaan de pagina (wp_footer), want de inhoud kan meer dan eens opgebouwd worden */
function ft4a_pop_footer() {
	static $hooked = false;
	if ($hooked) return;
	$hooked = true;
	add_action('wp_footer', function () { echo ft4a_pop_dialog(); }, 5);
}
function ft4a_pop_dialog() {
	$o = '';
	$pl = ['max' => ft4a_t('Volledig scherm'), 'min' => ft4a_t('Kleiner venster')];
	$o .= '<dialog class="ft4a-pop" aria-labelledby="ft4a-pop-t"><div class="ft4a-pop-bar"><strong class="ft4a-pop-t" id="ft4a-pop-t"></strong>'
		. '<button type="button" class="ft4a-pop-edit">' . esc_html(ft4a_t('Bewerken')) . '</button>'
		. '<button type="button" class="ft4a-pop-max" aria-pressed="false">' . esc_html($pl['max']) . '</button>'
		. '<button type="button" class="ft4a-pop-x" aria-label="' . esc_attr(ft4a_t('Sluiten')) . '">&times;</button></div><div class="ft4a-pop-f"></div></dialog>'
		. '<script>(function(){var d=document.querySelector(".ft4a-pop");if(!d||!d.showModal)return;if(d.parentNode!==document.body)document.body.appendChild(d);var L=' . wp_json_encode($pl, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ',box=d.querySelector(".ft4a-pop-f"),t=d.querySelector(".ft4a-pop-t"),mx=d.querySelector(".ft4a-pop-max"),ed=d.querySelector(".ft4a-pop-edit"),fr=null,busy=false,cur="";'
		. 'function setMax(on){d.classList.toggle("is-max",on);mx.setAttribute("aria-pressed",on?"true":"false");mx.textContent=on?L.min:L.max;}'
		. 'function frame(src){if(fr)fr.remove();fr=document.createElement("iframe");fr.title=t.textContent||"FT4A";fr.setAttribute("allow","fullscreen; clipboard-read; clipboard-write");fr.setAttribute("allowfullscreen","");fr.src=src;box.appendChild(fr);}'
		. 'function arg(u,k){return u+(u.indexOf("?")<0?"?":"&")+k;}'
		. 'document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("a[data-ft4a-pop]");if(!a||e.defaultPrevented||e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;e.preventDefault();t.textContent=a.dataset.title||"";cur=a.dataset.edit!==undefined?a.dataset.edit:arg(a.href,"from=view");ed.hidden=!cur;setMax(false);frame(a.dataset.view?a.href:arg(a.href,"view=1"));document.documentElement.classList.add("ft4a-pop-open");d.showModal();});'
		. 'ed.onclick=function(){if(!cur)return;ed.hidden=true;setMax(true);frame(cur);};'
		. 'mx.onclick=function(){setMax(!d.classList.contains("is-max"));};'
		. 'function ok(){try{var w=fr&&fr.contentWindow;if(w&&typeof w.guardUnsaved==="function")return Promise.resolve(w.guardUnsaved());}catch(x){}return Promise.resolve(true);}'
		. 'function shut(){if(busy)return;busy=true;ok().then(function(r){busy=false;if(r!==false)d.close();},function(){busy=false;d.close();});}'
		. 'd.querySelector(".ft4a-pop-x").onclick=shut;d.addEventListener("cancel",function(e){e.preventDefault();shut();});'
		. 'd.addEventListener("close",function(){if(fr){fr.remove();fr=null;}document.documentElement.classList.remove("ft4a-pop-open");});})();</script>';
	return $o;
}
add_shortcode('ft4a_oefeningen', function () {
	// Alleen leden met een online of compleet pakket zien de database; anderen zien de voorbeelden
	if (!ft4a_has_db()) {
		$n = ft4a_oefening_count();
		$in = is_user_logged_in();
		$txt = $in ? sprintf(ft4a_t('Met je huidige pakket heb je geen toegang tot de oefeningendatabase. Kies een online of compleet pakket om alle %s oefeningen te bekijken en te downloaden.'), $n)
			: sprintf(ft4a_t('Log in met een online of compleet pakket om alle %s oefeningen te bekijken en te downloaden. Bekijk intussen de voorbeeldoefeningen.'), $n);
		$btn = $in ? '<a class="btn btn-primary" href="' . esc_url(ft4a_url('prijzen')) . '">' . esc_html(ft4a_t('Bekijk de pakketten')) . '</a>'
			: '<a class="btn btn-primary" href="' . esc_url(add_query_arg('redirect_to', urlencode(ft4a_url('ledenoefeningen')), ft4a_url('inloggen'))) . '">' . esc_html(ft4a_t('Inloggen')) . '</a><a class="btn btn-outline" href="' . esc_url(ft4a_url('prijzen')) . '">' . esc_html(ft4a_t('Bekijk de pakketten')) . '</a>';
		return '<div class="ft4a-card ft4a-empty"><h3>' . esc_html(ft4a_t('De oefeningendatabase is alleen voor leden')) . '</h3><p>' . esc_html($txt) . '</p><p class="ft4a-actions">' . $btn . '<a class="btn btn-outline" href="' . esc_url(ft4a_url('oefeningen')) . '">' . esc_html(ft4a_t('Bekijk de voorbeeldoefeningen')) . '</a></p></div>';
	}
	$terms = get_terms(['taxonomy'=>'ft4a_categorie','hide_empty'=>false]);
	$cur = sanitize_title(wp_unslash($_GET['cat'] ?? ''));
	$s = sanitize_text_field(wp_unslash($_GET['q'] ?? ''));
	$paged = max(1, absint($_GET['pg'] ?? 1));
	$anim = !empty($_GET['anim']);
	$base = ft4a_url('ledenoefeningen');
	$o = '<form class="ft4a-filter" method="get" action="' . esc_url($base) . '"><input type="search" name="q" id="ft4a-q" value="' . esc_attr($s) . '" placeholder="' . esc_attr(ft4a_t('Zoek een oefening…')) . '" aria-label="' . esc_attr(ft4a_t('Zoek een oefening')) . '">' . ($cur ? '<input type="hidden" name="cat" value="' . esc_attr($cur) . '">' : '') . '<button class="btn btn-primary btn-sm" type="submit">' . esc_html(ft4a_t('Zoeken')) . '</button></form>';
	$ab = $anim ? add_query_arg('anim', 1, $base) : $base;
	$o .= '<nav class="ft4a-chips" aria-label="' . esc_attr(ft4a_t('Categorieën')) . '"><a href="' . esc_url($ab) . '"' . (!$cur ? ' aria-current="true"' : '') . '>' . esc_html(ft4a_t('Alle')) . '</a>';
	foreach ($terms as $t) $o .= '<a href="' . esc_url(add_query_arg('cat', $t->slug, $ab)) . '"' . ($cur === $t->slug ? ' aria-current="true"' : '') . '>' . esc_html(ft4a_t($t->name)) . '</a>';
	$o .= '<a class="ft4a-chip-anim" href="' . esc_url($anim ? remove_query_arg('anim', add_query_arg(array_filter(['cat' => $cur]), $base)) : add_query_arg(array_filter(['cat' => $cur, 'anim' => 1]), $base)) . '"' . ($anim ? ' aria-current="true"' : '') . '>' . ft4a_anim_icon() . esc_html(ft4a_t('Met animatie')) . '</a>';
	$o .= '</nav>';
	// volgorde: eerst eigen oefeningen van leden (nieuwste eerst), daarna de FT4A-reeks op nummer (Conditie, Passvormen, Opwarmingen, Afwerkvormen, Allerlei; telkens 001, 002, …)
	$args = ['post_type'=>'ft4a_oefening','post_status'=>'publish','posts_per_page'=>12,'paged'=>$paged,'s'=>$s,'orderby'=>['menu_order'=>'ASC','date'=>'DESC']];
	if ($cur) $args['tax_query'] = [['taxonomy'=>'ft4a_categorie','field'=>'slug','terms'=>$cur]];
	if ($anim) $args['meta_query'] = [['key' => '_ft4a_anim', 'value' => '1']];
	$q = new WP_Query($args);
	if (!$q->have_posts()) return $o . '<div class="ft4a-card ft4a-empty"><h3>' . esc_html(ft4a_t('Nog geen oefeningen gevonden')) . '</h3><p>' . esc_html($s || $cur ? ft4a_t('Probeer een andere zoekterm of categorie.') : ft4a_t('Hier verschijnen de oefeningen die leden delen. Wees de eerste!')) . '</p><p><a class="btn btn-primary" href="' . esc_url(ft4a_url('oefening-toevoegen')) . '">' . esc_html(ft4a_t('Oefening toevoegen')) . '</a></p></div>';
	$o .= '<div class="ft4a-cards">';
	foreach ($q->posts as $p) {
		$t = wp_get_post_terms($p->ID, 'ft4a_categorie', ['fields'=>'names']);
		$age = get_post_meta($p->ID, '_ft4a_leeftijd', true);
		$img = get_the_post_thumbnail_url($p, 'medium_large');
		$prev = (!$img && ($nr = get_post_meta($p->ID, '_ft4a_bron_nr', true)) && is_readable(ft4a_prev_dir() . $nr . '.webp')) ? ft4a_prev_url() . $nr . '.webp' : '';
		$pic = $prev ? '<a href="' . esc_url($prev) . '" target="_blank" rel="noopener" class="ft4a-zoom" data-title="' . esc_attr(ft4a_oef_title($p)) . '"><img class="ft4a-prev" src="' . esc_url($prev) . '" alt="' . esc_attr(ft4a_oef_title($p)) . '" loading="lazy" width="640" height="480"></a>' : ($img ? '<a href="' . esc_url(get_the_post_thumbnail_url($p, 'full')) . '" target="_blank" rel="noopener" class="ft4a-zoom" data-title="' . esc_attr(ft4a_oef_title($p)) . '"><img class="ft4a-prev" src="' . esc_url($img) . '" alt="' . esc_attr(ft4a_oef_title($p)) . '" loading="lazy" width="640" height="480"></a>' : '<svg viewBox="0 0 200 110" aria-hidden="true"><rect width="200" height="110" fill="#1f774c"/><g fill="none" stroke="#fff" stroke-opacity=".6" stroke-width="1.2"><rect x="6" y="6" width="188" height="98"/><path d="M100 6v98"/><circle cx="100" cy="55" r="14"/></g><circle cx="60" cy="40" r="6" fill="#d93b34"/><circle cx="140" cy="70" r="6" fill="#d93b34"/><circle cx="100" cy="80" r="6" fill="#fff"/></svg>');
		$dl = !is_user_logged_in() ? null : (!ft4a_has_db() ? '<a class="btn btn-outline btn-sm" href="' . esc_url(ft4a_url('prijzen')) . '">' . esc_html(ft4a_t('Kies een online pakket om te openen')) . '</a>' : null);
		$dl = $dl ?: (is_user_logged_in()
			? '<a class="btn btn-primary btn-sm" href="' . esc_url(ft4a_online_url($p->ID)) . '" target="ft4a-online" data-ft4a-pop="1" data-title="' . esc_attr(ft4a_oef_title($p)) . '">' . esc_html(ft4a_t('Open oefening')) . '</a>'
			: '<a class="btn btn-outline btn-sm" href="' . esc_url(add_query_arg('redirect_to', urlencode($base), ft4a_url('inloggen'))) . '">' . esc_html(ft4a_t('Log in om te openen')) . '</a>');
		$meta = sprintf(ft4a_t('Door %1$s · %2$s · %3$d keer geopend'), get_post_meta($p->ID, '_ft4a_bron_nr', true) ? 'FT4A.com' : get_the_author_meta('display_name', $p->post_author), get_the_date(ft4a_t('j F Y'), $p), (int) get_post_meta($p->ID, '_ft4a_downloads', true));
		$badge = ft4a_post_anim($p->ID) ? '<span class="ft4a-anim" title="' . esc_attr(ft4a_t('Deze oefening bevat een animatie')) . '">' . ft4a_anim_icon() . esc_html(ft4a_t('Animatie')) . '</span>' : '';
		$o .= '<article class="ft4a-ex"><div class="ft4a-ex-pic">' . $pic . $badge . '</div><div class="ft4a-ex-body ft4a-ex-row" title="' . esc_attr(ft4a_oef_title($p)) . '"><div class="ft4a-tags">' . ($t ? '<span>' . esc_html(ft4a_t($t[0])) . '</span>' : '') . '</div>' . $dl . '</div></article>';
	}
	$o .= '</div>';
	if ($q->max_num_pages > 1) {
		$o .= '<nav class="ft4a-pages" aria-label="' . esc_attr(ft4a_t('Pagina’s')) . '">';
		$max = (int) $q->max_num_pages; $last = 0;
		$link = function ($i, $label = null) use ($cur, $s, $base, $paged, $anim) { return '<a href="' . esc_url(add_query_arg(array_filter(['pg'=>$i,'cat'=>$cur,'q'=>$s,'anim'=>$anim ? 1 : 0]), $base)) . '"' . ($i === $paged ? ' aria-current="true"' : '') . '>' . ($label ?? $i) . '</a>'; };
		if ($paged > 1) $o .= $link($paged - 1, '‹');
		for ($i = 1; $i <= $max; $i++) {
			if ($i === 1 || $i === $max || abs($i - $paged) <= 2) { if ($last && $i - $last > 1) $o .= '<span class="ft4a-gap">…</span>'; $o .= $link($i); $last = $i; }
		}
		if ($paged < $max) $o .= $link($paged + 1, '›');
		$o .= '</nav>';
	}
	// klik op een afbeelding: groot tonen in een venster dat je kunt sluiten
	$o .= '<dialog class="ft4a-lb" aria-label="' . esc_attr(ft4a_t('Afbeelding')) . '"><button type="button" class="ft4a-lb-x" aria-label="' . esc_attr(ft4a_t('Sluiten')) . '">&times;</button><img alt=""><p class="ft4a-lb-t"></p></dialog>'
		. '<script>(function(){var d=document.querySelector(".ft4a-lb");if(!d||!d.showModal)return;var im=d.querySelector("img"),t=d.querySelector(".ft4a-lb-t");'
		. 'document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("a.ft4a-zoom");if(!a||e.ctrlKey||e.metaKey||e.shiftKey)return;e.preventDefault();im.src=a.href;im.alt=a.dataset.title||"";t.textContent=a.dataset.title||"";d.showModal();});'
		. 'd.querySelector(".ft4a-lb-x").onclick=function(){d.close();};d.addEventListener("click",function(e){if(e.target===d)d.close();});d.addEventListener("close",function(){im.removeAttribute("src");});})();</script>';
	// "Open oefening": een venster op deze pagina met een viewer (veld met animatie en de gegevens van de oefening, /online/?view=1).
	// "Bewerken" opent in hetzelfde venster de gewone software, op volledig scherm. Sluiten vraagt eerst de software of er
	// niet-bewaarde wijzigingen zijn (de viewer verandert niets). Ctrl/Cmd-klik opent zoals vroeger de software in een nieuw tabblad.
	if (is_user_logged_in() && ft4a_has_db()) $o .= ft4a_pop_dialog();
	return $o;
});
add_shortcode('ft4a_melding', function () { return ft4a_flash(sanitize_key($_GET['ft4a'] ?? '')); });
add_shortcode('ft4a_contact', function () {
	return ft4a_flash(sanitize_key($_GET['ft4a'] ?? '')) . ft4a_errors($GLOBALS['ft4a_errors']) . '<div class="ft4a-card"><h3>' . esc_html(ft4a_t('Stuur ons een bericht')) . '</h3><form method="post" class="ft4a-form">'
		. ft4a_nocache() . wp_nonce_field('ft4a_contact', '_ft4a', true, false) . '<input type="hidden" name="ft4a_action" value="contact">'
		. '<p class="ft4a-hp"><label for="website">' . esc_html(ft4a_t('Laat dit veld leeg')) . '</label><input type="text" name="website" id="website" tabindex="-1" autocomplete="off"></p>'
		. '<div class="ft4a-row"><p><label for="naam">' . esc_html(ft4a_t('Naam')) . '</label><input type="text" name="naam" id="naam" required value="' . ft4a_val('naam') . '" autocomplete="name"></p><p><label for="email">' . esc_html(ft4a_t('E-mailadres')) . '</label><input type="email" name="email" id="email" required value="' . ft4a_val('email') . '" autocomplete="email"></p></div>'
		. '<p><label for="onderwerp">' . esc_html(ft4a_t('Onderwerp')) . '</label><input type="text" name="onderwerp" id="onderwerp" value="' . ft4a_val('onderwerp') . '"></p>'
		. '<p><label for="bericht">' . esc_html(ft4a_t('Bericht')) . '</label><textarea name="bericht" id="bericht" rows="6" required>' . (isset($_POST['bericht']) ? esc_textarea(wp_unslash($_POST['bericht'])) : '') . '</textarea></p>'
		. '<p><button type="submit" class="btn btn-primary">' . esc_html(ft4a_t('Bericht versturen')) . '</button></p></form></div>';
});

/* ---------- Beheer: kolommen ---------- */
add_filter('manage_ft4a_oefening_posts_columns', function ($c) { $c['ft4a_file'] = 'Bestand'; $c['ft4a_age'] = 'Leeftijd'; $c['ft4a_dl'] = 'Downloads'; return $c; });
add_action('manage_ft4a_oefening_posts_custom_column', function ($col, $id) {
	if ($col === 'ft4a_file') { $a = (int) get_post_meta($id, '_ft4a_file', true); echo $a ? '<a href="' . esc_url(wp_get_attachment_url($a)) . '">' . esc_html(basename(get_attached_file($a))) . '</a>' : '—'; }
	if ($col === 'ft4a_age') echo esc_html(get_post_meta($id, '_ft4a_leeftijd', true) ?: '—');
	if ($col === 'ft4a_dl') echo (int) get_post_meta($id, '_ft4a_downloads', true);
}, 10, 2);
add_action('add_meta_boxes', function () {
	add_meta_box('ft4a_file', 'FT4A-bestand', function ($p) {
		$a = (int) get_post_meta($p->ID, '_ft4a_file', true);
		echo $a ? '<p><a class="button" href="' . esc_url(wp_get_attachment_url($a)) . '">Download ' . esc_html(basename(get_attached_file($a))) . '</a></p>' : '<p>Geen bestand.</p>';
		echo '<p>Leeftijd: <strong>' . esc_html(get_post_meta($p->ID, '_ft4a_leeftijd', true) ?: '—') . '</strong></p><p>Downloads: ' . (int) get_post_meta($p->ID, '_ft4a_downloads', true) . '</p><p class="description">Klik op <em>Publiceren</em> om de oefening goed te keuren.</p>';
	}, 'ft4a_oefening', 'side');
});
add_action('admin_menu', function () {
	$n = (int) wp_count_posts('ft4a_oefening')->pending;
	if ($n) { global $menu; foreach ($menu as $k => $m) { if (($m[2] ?? '') === 'edit.php?post_type=ft4a_oefening') $menu[$k][0] .= ' <span class="awaiting-mod">' . $n . '</span>'; } }
});

/* ---------- Opmaak van de ledenonderdelen ---------- */
add_action('wp_head', function () { ?>
<style id="ft4a-leden-css">
.ft4a-card{background:var(--bg-2,#4b5a52);border:1px solid var(--line,#62726a);border-radius:14px;padding:28px;margin-bottom:20px}
.ft4a-card h3{font-size:1.35rem;margin:0 0 14px}
.ft4a-grid2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px;align-items:start}
@media (max-width:860px){.ft4a-grid2{grid-template-columns:1fr}}
.ft4a-form p,.ft4a-card form p,#loginform p{margin:0 0 14px}
.ft4a-form label,#loginform label{display:block;font-weight:600;font-size:.92rem;margin-bottom:6px}
.ft4a-form input[type=text],.ft4a-form input[type=email],.ft4a-form input[type=password],.ft4a-form input[type=search],.ft4a-form select,.ft4a-form textarea,#loginform input[type=text],#loginform input[type=password],.ft4a-filter input{width:100%;padding:11px 13px;border-radius:9px;border:1px solid var(--line,#62726a);background:var(--bg,#435149);color:var(--fg,#fff);font:inherit}
.ft4a-form input[type=file]{width:100%;padding:10px;border:1px dashed var(--line,#62726a);border-radius:9px;background:var(--bg,#435149);color:var(--fg,#fff)}
.ft4a-form input:focus,.ft4a-form select:focus,.ft4a-form textarea:focus,#loginform input:focus{outline:2px solid var(--brand,#62dc9e);outline-offset:1px}
#loginform .login-remember label{display:flex;gap:8px;align-items:center;font-weight:500}
#loginform input[type=submit]{height:46px;padding:0 22px;border-radius:10px;border:0;background:var(--brand,#62dc9e);color:var(--brand-ink,#06150d);font:600 .96rem var(--sans,inherit);cursor:pointer}
.ft4a-row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
@media (max-width:600px){.ft4a-row{grid-template-columns:1fr}}
.ft4a-check{display:flex;gap:10px;align-items:flex-start}.ft4a-check input{margin-top:5px}.ft4a-check label{font-weight:500!important}
.ft4a-hp{position:absolute!important;left:-9999px!important}
.ft4a-small{font-size:.88rem;color:var(--muted,#e2e9e4)}
.ft4a-card a:not(.btn){color:#8ef0bd}
.ft4a-msg{border-radius:12px;padding:14px 18px;margin-bottom:20px;font-weight:500}
.ft4a-msg ul{margin:0;padding-left:18px}
.ft4a-ok{background:rgba(98,220,158,.16);border:1px solid rgba(98,220,158,.5)}
.ft4a-err{background:rgba(255,125,120,.16);border:1px solid rgba(255,125,120,.55)}
.ft4a-hello{display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap}
.ft4a-hello h3{margin:0}
.ft4a-actions{display:flex;gap:10px;flex-wrap:wrap}
.ft4a-table{width:100%;border-collapse:collapse;font-size:.95rem}
.ft4a-table th,.ft4a-table td{text-align:left;padding:10px 8px;border-bottom:1px solid var(--line,#62726a)}
.ft4a-table th{font-size:.82rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#e2e9e4)}
.ft4a-pill{display:inline-block;padding:3px 10px;border-radius:999px;font-size:.82rem;font-weight:600}
.ft4a-pill.ok{background:rgba(98,220,158,.2);color:#8ef0bd}.ft4a-pill.wait{background:rgba(255,210,79,.18);color:#ffd24f}
.ft4a-filter{display:flex;gap:10px;margin-bottom:16px;max-width:560px}
.ft4a-chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:28px}
.ft4a-chips a{padding:7px 14px;border-radius:999px;border:1px solid var(--line,#62726a);background:var(--bg-2,#4b5a52);text-decoration:none;font-weight:600;font-size:.92rem}
.ft4a-chips a:hover{border-color:var(--brand,#62dc9e)}
.ft4a-chips a[aria-current]{background:var(--brand,#62dc9e);color:var(--brand-ink,#06150d);border-color:transparent}
.ft4a-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}
@media (max-width:1000px){.ft4a-cards{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:620px){.ft4a-cards{grid-template-columns:1fr}}
.ft4a-ex{display:flex;flex-direction:column;background:#4f5f57;border:1px solid #6a7b72;border-radius:14px;overflow:hidden;box-shadow:0 2px 4px rgba(0,0,0,.18),0 14px 34px rgba(0,0,0,.24)}
.ft4a-ex-pic img,.ft4a-ex-pic svg{display:block;width:100%;aspect-ratio:200/110;object-fit:cover}
.ft4a-ex-pic a{display:block;background:#37843f;overflow:hidden}
.ft4a-ex-pic img.ft4a-prev{height:auto;aspect-ratio:16/11;object-fit:contain;background:#37843f;padding:6px;box-sizing:border-box;transition:transform .2s}
.ft4a-ex-pic a:hover img.ft4a-prev{transform:scale(1.04)}
.ft4a-ex-pic a.ft4a-zoom{cursor:zoom-in}
.phero-full h1,.phero-full p{max-width:none}
.ft4a-ex .ft4a-ex-body.ft4a-ex-row{flex-direction:row;padding:14px 16px;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
.ft4a-ex-row .ft4a-tags{margin:0}
.ft4a-lb{border:0;padding:0;background:transparent;max-width:min(1100px,94vw);max-height:94vh;overflow:visible}
.ft4a-lb::backdrop{background:rgba(8,12,10,.82)}
.ft4a-lb img{display:block;max-width:min(1100px,94vw);max-height:84vh;width:auto;height:auto;border-radius:12px;background:#37843f;padding:10px;box-sizing:border-box;box-shadow:0 20px 60px rgba(0,0,0,.5)}
.ft4a-lb-t{margin:12px 0 0;text-align:center;color:#fff;font-weight:600}
.ft4a-lb-x{position:absolute;top:-16px;right:-16px;width:40px;height:40px;border-radius:50%;border:0;background:#fff;color:#111;font-size:26px;line-height:40px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.4)}
[dir=rtl] .ft4a-lb-x{right:auto;left:-16px}
@media(max-width:600px){.ft4a-lb-x{top:-48px;right:0}}
.vc-b .vc-open{margin:8px 0 0;font-weight:600;font-size:.9rem}
.vc-open a{display:inline-flex;align-items:center;gap:6px;color:var(--brand,#62dc9e);text-decoration:none}
.vc-open a:hover{text-decoration:underline}
.vc-open svg{flex:none}
.ft4a-pop{border:0;padding:0;margin:auto!important;width:min(1400px,96vw);height:92vh;height:92dvh;max-width:none;max-height:none;border-radius:14px;overflow:hidden;background:#26332c;color:#fff;box-shadow:0 20px 60px rgba(0,0,0,.55)}
.ft4a-pop[open]{display:flex;flex-direction:column}
.ft4a-pop::backdrop{background:rgba(8,12,10,.82)}
.ft4a-pop.is-max{width:100vw;height:100vh;height:100dvh;margin:0!important;inset:0;border-radius:0}
.ft4a-pop-bar{display:flex;align-items:center;gap:10px;padding:8px 10px 8px 16px;border-bottom:1px solid rgba(255,255,255,.12)}
.ft4a-pop-t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600}
.ft4a-pop-edit{border:0;background:var(--brand,#62dc9e);color:var(--brand-ink,#06150d);border-radius:8px;padding:8px 14px;font:inherit;font-size:.9rem;font-weight:700;cursor:pointer}
.ft4a-pop-edit[hidden]{display:none}
.ft4a-pop-max{border:1px solid rgba(255,255,255,.35);background:transparent;color:#fff;border-radius:8px;padding:7px 12px;font:inherit;font-size:.9rem;font-weight:600;cursor:pointer}
.ft4a-pop-max:hover{border-color:var(--brand,#62dc9e)}
.ft4a-pop-x{flex:none;width:36px;height:36px;border-radius:50%;border:0;background:#fff;color:#111;font-size:24px;line-height:36px;padding:0;cursor:pointer}
.ft4a-pop-f{flex:1;min-height:0;position:relative;background:#fff}
.ft4a-pop-f iframe{position:absolute;inset:0;width:100%;height:100%;border:0;display:block}
html.ft4a-pop-open{overflow:hidden}
@media(max-width:760px){.ft4a-pop{width:100vw;height:100vh;height:100dvh;margin:0!important;inset:0;border-radius:0}.ft4a-pop-max{display:none}}
.ft4a-ex-pic{position:relative}
.ft4a-anim{position:absolute;top:10px;right:10px;display:inline-flex;align-items:center;gap:6px;padding:5px 10px;border-radius:999px;background:rgba(20,28,24,.82);color:#8ef0bd;font-size:.8rem;font-weight:600;line-height:1;pointer-events:none;box-shadow:0 2px 8px rgba(0,0,0,.3)}
[dir=rtl] .ft4a-anim{right:auto;left:10px}
.ft4a-chips a.ft4a-chip-anim{display:inline-flex;align-items:center;gap:6px}
.ft4a-autoprev{display:flex;align-items:center;gap:12px;margin-top:10px}
.ft4a-autoprev img{width:120px;border-radius:8px;background:#37843f}
.ft4a-ex-body{padding:18px;display:flex;flex-direction:column;gap:8px;flex:1}
.ft4a-ex-body h3{font-size:1.15rem;margin:0;letter-spacing:-.01em}
.ft4a-tags{display:flex;gap:6px;flex-wrap:wrap}
.ft4a-tags span{font-size:.78rem;font-weight:600;padding:3px 9px;border-radius:6px;background:rgba(59,113,245,.18);color:#b3c9ff}
.ft4a-ex details summary{cursor:pointer;font-weight:600;font-size:.92rem;color:#8ef0bd}
.ft4a-ex details div{font-size:.95rem;color:var(--muted,#e2e9e4)}
.ft4a-ex-foot{margin-top:auto;padding-top:6px}
.ft4a-empty{text-align:center;padding:48px 28px}
.ft4a-pages{display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin-top:28px}
.ft4a-gap{min-width:24px;height:38px;display:grid;place-items:center;opacity:.7}
.ft4a-pages a{min-width:38px;height:38px;display:grid;place-items:center;border-radius:9px;border:1px solid var(--line,#62726a);text-decoration:none;font-weight:600}
.ft4a-pages a[aria-current]{background:var(--brand,#62dc9e);color:var(--brand-ink,#06150d)}
</style>
<?php });
